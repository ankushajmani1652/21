import React, { useState, useEffect } from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  Box,
  TextField,
  Typography,
} from "@mui/material";
import { Settings } from "@mui/icons-material";
import { motion } from "framer-motion";

const Buttons = () => {
  const [open, setOpen] = useState(false);
  const [selectedButton, setSelectedButton] = useState(null);
  const [selectedPopupButtons, setSelectedPopupButtons] = useState(true);
  const [textInputValues, setTextInputValues] = useState({}); // State to hold the text input values for buttons 1 and 2

  const buttonConfig = [
    { id: 1, label: "Data Quality Threshold" },
    { id: 2, label: "Range Selection" },
    { id: 3, label: "Archival and Speckle" },
    { id: 4, label: "Minimal NetCDF Configuration" },
  ];

  const popupButtons = {
    1: ["LOG(db)", "SQI", "SIG", "CSR(db)", "Rho"],
    2: [
      "IF1 Start Range",
      "IF1 Stop Range",
      "IF2 Start Range",
      "IF2 Stop Range",
      "IF3 Start Range",
      "IF3 Stop Range",
    ],
    3: [
      "Minimal NetCDF Log",
      "Speckle Filter ID",
      "Speckle Filter 2D",
      "Raw Data Log",
    ],
    4: [
        "ZH",
        "ZV",
        "UfZH",
        "UfZV",
        "RxSigH",
        "RxSigV",
        "SNRH",
        "SNRV",
        "NPH",
        "NPV",
        "VH",
        "VV",
        "VwH",
        "VwV",
        "Zdr",
        "Ldr",
        "Phidp",
        "Rho",
        "Kdp",
        "LogH",
        "LogV",
        "SQIH",
        "SQIV",
        "CCORH",
        "CCORV",
        "SRI",
    ],
  };

  // Load saved state from localStorage on component mount
  // useEffect(() => {
  //   const savedButton = localStorage.getItem("selectedButton");
  //   const savedPopupButtons = JSON.parse(
  //     localStorage.getItem("selectedPopupButtons") || "[]"
  //   );
  //   const savedTextInputValues = JSON.parse(
  //     localStorage.getItem("textInputValues") || "{}"
  //   );

  //   if (savedButton) {
  //     setSelectedButton(Number(savedButton));
  //   }
  //   if (savedPopupButtons) {
  //     setSelectedPopupButtons(savedPopupButtons);
  //   }
  //   if (savedTextInputValues) {
  //     setTextInputValues(savedTextInputValues);
  //   }
  // }, []);

  // Save the state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("selectedButton", selectedButton);
    localStorage.setItem(
      "selectedPopupButtons",
      JSON.stringify(selectedPopupButtons)
    );
    localStorage.setItem("textInputValues", JSON.stringify(textInputValues));
  }, [selectedButton, selectedPopupButtons, textInputValues]);

  const handleClickOpen = (buttonId) => {
    setSelectedButton(buttonId);
    if (buttonId === 4) {
      // For Minimal NetCDF Configuration, select all options by default
      setSelectedPopupButtons(popupButtons[buttonId]); // This selects all options for button 4
    } else {
      setSelectedPopupButtons([]); // Reset selection for other buttons
    }
    setOpen(true);

    // Log the button label instead of the ID
    const buttonLabel = buttonConfig.find(
      (button) => button.id === buttonId
    )?.label;
    console.log("Selected button label:", buttonLabel);
  };
  const handleClose = () => {
    setOpen(false);
    setSelectedPopupButtons([]); // Reset the selected popup buttons when closing the dialog
  };

  const handlePopupButtonClick = (option) => {
    setSelectedPopupButtons((prev) =>
      prev.includes(option)
        ? prev.filter((item) => item !== option)
        : [...prev, option]
    );
  };

  const handleTextInputChange = (option, value) => {
    setTextInputValues((prev) => ({
      ...prev,
      [option]: value,
    }));
  };

  

  const defaultValues = {
    selectedButton: 1, // Default button (for example)
    selectedPopupButtons: ["LOG(db)", "SQI", "SIG", "CSR(db)", "Rho"], // Default selected popup buttons
    textInputValues: {
      "LOG(db)": "1",
      SQI: "1",
      SIG: "-10",
      "CSR(db)": "1",
      Rho: "1.5",
      // Default values for Range Selection
      "IF1 Start Range": "0",
      "IF1 Stop Range": "25",
      "IF2 Start Range": "25",
      "IF2 Stop Range": "50",
      "IF3 Start Range": "50",
      "IF3 Stop Range": "100",
    },
  };
  

  // Function to load default settings from localStorage
  const handleLoadDefault = () => {
    const savedButton = localStorage.getItem("selectedButton");
    const savedPopupButtons = JSON.parse(
      localStorage.getItem("selectedPopupButtons") || "[]"
    );
    const savedTextInputValues = JSON.parse(
      localStorage.getItem("textInputValues") || "{}"
    );
  
    // If no saved values exist, use the default values
    setSelectedButton(
      savedButton ? Number(savedButton) : defaultValues.selectedButton
    );
    setSelectedPopupButtons(
      savedPopupButtons.length > 0
        ? savedPopupButtons
        : defaultValues.selectedPopupButtons
    );
    setTextInputValues({
      ...defaultValues.textInputValues,
      ...savedTextInputValues, // Merge saved values if they exist
    });
  
    console.log("Loaded default values:", {
      selectedButton,
      selectedPopupButtons,
      textInputValues,
    });
  };
  

  // Function to update default settings in localStorage
  const handleUpdateDefault = () => {
    localStorage.setItem("selectedButton", selectedButton);
    localStorage.setItem(
      "selectedPopupButtons",
      JSON.stringify(selectedPopupButtons)
    );
    localStorage.setItem("textInputValues", JSON.stringify(textInputValues));
  };

  const handleSave = () => {
    // Save the selected options and text input values to localStorage
    localStorage.setItem("selectedButton", selectedButton);
    localStorage.setItem(
      "selectedPopupButtons",
      JSON.stringify(selectedPopupButtons)
    );
    localStorage.setItem("textInputValues", JSON.stringify(textInputValues));

    // Log the saved button label instead of the ID
    const buttonLabel = buttonConfig.find(
      (button) => button.id === selectedButton
    )?.label;

    console.log(
      "PopupButtons",
      selectedPopupButtons.length > 0 ? true : false,
      "Value:",
      selectedPopupButtons
    );
    // console.log('textInputValues:', Object.keys(textInputValues).length > 0 ? true : false, 'Value:', textInputValues);

    // Close the dialog after saving
    setOpen(false);
  };

  const handleDeselectAll = () => {
    // Reset the selectedPopupButtons state for Button 4
    setSelectedPopupButtons([]);
    console.log("All options deselected for Minimal NetCDF Configuration");
  };

  return (
    <Grid
      container
      spacing={2}
      alignItems="center"
      justifyContent="flex-start"
      marginTop={5}
    >
      <Grid item xs={12}>
        <Typography
          variant="h4"
          sx={{
            color: "black",
            fontFamily: "'Orbitron', sans-serif",
            textAlign: "center",
            marginBottom: "20px",
          }}
        >
          Weather Radar Signal Processing
        </Typography>
      </Grid>

      {/* Buttons to load and update default */}
      <Grid
        item
        xs={12}
        sx={{
          display: "flex",
          justifyContent: "space-around",
          marginBottom: "20px",
        }}
      >
        <Button
          variant="outlined"
          onClick={handleLoadDefault}
          sx={{ backgroundColor: "#00e0ff", color: "#000" }}
        >

          Load Default
        </Button>
        <Button
          variant="outlined"
          onClick={handleUpdateDefault}
          sx={{ backgroundColor: "#00e0ff", color: "#000" }}
        >
          Update Default
        </Button>
      </Grid>

      <Grid
        item
        xs={12}
        sx={{
          display: "flex",
          justifyContent: "space-around",
          marginBottom: "20px",
        }}
      >
        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
          <Button
            variant="contained"
            sx={{
              fontFamily: "'Orbitron', sans-serif",
              backgroundColor: "#000",
              color: "#fff",
              border: "2px solid transparent",
              padding: "14px 28px",
              width: "200px",
              marginBottom: "12px",
              borderRadius: "12px",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                boxShadow: "0 0 20px #00e0ff",
                borderColor: "#00e0ff",
              },
              ...(selectedButton === 1 && {
                boxShadow: "0 0 25px #00e0ff",
                borderColor: "#00e0ff",
              }),
            }}
            onClick={() => handleClickOpen(1)}
            startIcon={<Settings />}
          >
            Data Quality Threshold
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
          <Button
            variant="contained"
            sx={{
              fontFamily: "'Orbitron', sans-serif",
              backgroundColor: "#000",
              color: "#fff",
              border: "2px solid transparent",
              padding: "14px 28px",
              height: "74px",
              width: "200px",
              marginBottom: "12px",
              borderRadius: "12px",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                boxShadow: "0 0 20px #00e0ff",
                borderColor: "#00e0ff",
              },
              ...(selectedButton === 2 && {
                boxShadow: "0 0 25px #00e0ff",
                borderColor: "#00e0ff",
              }),
            }}
            onClick={() => handleClickOpen(2)}
            startIcon={<Settings />}
          >
            Range Selection
          </Button>
        </motion.div>
      </Grid>

      {/* Second Row: Archival and Speckle, Minimal NetCDF Configuration */}
      <Grid
        item
        xs={12}
        sx={{ display: "flex", justifyContent: "space-around" }}
      >
        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
          <Button
            variant="contained"
            sx={{
              fontFamily: "'Orbitron', sans-serif",
              backgroundColor: "#000",
              color: "#fff",
              border: "2px solid transparent",
              padding: "14px 28px",
              width: "200px",
              marginBottom: "12px",
              borderRadius: "12px",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                boxShadow: "0 0 20px #00e0ff",
                borderColor: "#00e0ff",
              },
              ...(selectedButton === 3 && {
                boxShadow: "0 0 25px #00e0ff",
                borderColor: "#00e0ff",
              }),
            }}
            onClick={() => handleClickOpen(3)}
            startIcon={<Settings />}
          >
            Archival and Speckle
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
          <Button
            variant="contained"
            sx={{
              fontFamily: "'Orbitron', sans-serif",
              backgroundColor: "#000",
              color: "#fff",
              border: "2px solid transparent",
              padding: "14px 28px",
              width: "200px",
              marginBottom: "12px",
              borderRadius: "12px",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                boxShadow: "0 0 20px #00e0ff",
                borderColor: "#00e0ff",
              },
              ...(selectedButton === 4 && {
                boxShadow: "0 0 25px #00e0ff",
                borderColor: "#00e0ff",
              }),
            }}
            onClick={() => handleClickOpen(4)}
            startIcon={<Settings />}
          >
            Minimal NetCDF Configuration
          </Button>
        </motion.div>
      </Grid>

      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            position: "absolute",
            right: 20,
            top: "10%",
            backgroundColor: "#121212",
            border: "2px solid #00e0ff",
            boxShadow: "0 0 25px #00e0ff",
            borderRadius: "15px",
            padding: "20px",
            color: "#fff",
          },
        }}
      >
        {(selectedButton === 1 ||
          selectedButton === 3 ||
          selectedButton === 4) && (
          <DialogTitle
            sx={{
              fontFamily: "'Orbitron', sans-serif",
              color: "#00e0ff",
              textAlign: "center",
            }}
          >
            {buttonConfig.find((b) => b.id === selectedButton)?.label}
          </DialogTitle>
        )}

        <DialogContent>
          {/* Conditionally render Deselect All button only for Button 4 */}
          {selectedButton === 4 && (
            <Box sx={{ textAlign: "center", marginBottom: "20px" }}>
              <Button
                variant="outlined"
                onClick={handleDeselectAll}
                sx={{
                  backgroundColor: "#1a1a1a",
                  color: "#00e0ff",
                  borderRadius: "12px",
                  padding: "8px 20px",
                  "&:hover": {
                    backgroundColor: "#00e0ff",
                    color: "#000",
                  },
                }}
              >
                Deselect All
              </Button>
            </Box>
          )}

          {selectedButton === 2 && (
            <>
              <Typography
                variant="h6"
                sx={{
                  color: "#00e0ff",
                  fontFamily: "'Orbitron', sans-serif",
                  textAlign: "center",
                  marginBottom: "20px",
                  fontWeight: "bold",
                }}
              >
                Range Selection
              </Typography>

              <Grid container spacing={2} justifyContent="center">
                {/* Render 6 TextFields for Range Selection */}
                {[
                  "IF1 Start Range",
                  "IF1 Stop Range",
                  "IF2 Start Range",
                  "IF2 Stop Range",
                  "IF3 Start Range",
                  "IF3 Stop Range",
                ].map((label, index) => (
                  <Grid item xs={12} sm={6} md={6} key={index}>
                    <TextField
                      label={label}
                      variant="outlined"
                      fullWidth
                      value={textInputValues[label] || ""}
                      onChange={(e) =>
                        handleTextInputChange(label, e.target.value)
                      }
                      sx={{
                        marginTop: 0,
                        "& .MuiInputLabel-root": {
                          color: "white", // Set label color to white
                        },
                        "& .MuiOutlinedInput-root": {
                          "&:hover fieldset": {
                            borderColor: "white", // Glowing effect on hover
                          },
                          "&.Mui-focused fieldset": {
                            borderColor: "white", // Border color when focused
                          },
                          padding: "0px",
                        },
                        "& .MuiInputBase-root": {
                          color: "white", // Input text color
                        },
                      }}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}

          <Grid container spacing={2} justifyContent="center">
            {/* Conditionally render the buttons based on selectedButton */}
            {(selectedButton === 1 ||
              selectedButton === 3 ||
              selectedButton === 4) &&
              popupButtons[selectedButton]?.map((option, index) => (
                <Grid item xs={4} key={index}>
                  <motion.div
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handlePopupButtonClick(option)}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      width: "100%",
                      padding: "12px",
                      marginTop: "12px",
                      borderRadius: "25px",
                      textAlign: "center",
                      cursor: "pointer",
                      fontFamily: "'Orbitron', sans-serif",
                      fontSize: "16px",
                      fontWeight: "bold",
                      transition: "all 0.3s ease-in-out",
                      background: selectedPopupButtons.includes(option)
                        ? "#222"
                        : "#1a1a1a",
                      color: "#00e0ff",
                      boxShadow: selectedPopupButtons.includes(option)
                        ? "0 0 15px #00e0ff"
                        : "none",
                    }}
                  >
                    {option}
                    <motion.div
                      animate={{
                        opacity: selectedPopupButtons.includes(option)
                          ? 1
                          : 0.3,
                        scale: selectedPopupButtons.includes(option) ? 1.2 : 1,
                      }}
                      transition={{ duration: 0.3 }}
                      style={{
                        width: "12px",
                        height: "12px",
                        borderRadius: "50%",
                        backgroundColor: "#00e0ff",
                        boxShadow: selectedPopupButtons.includes(option)
                          ? "0 0 10px #00e0ff"
                          : "none",
                        marginLeft: "10px",
                      }}
                    />
                  </motion.div>

                  {/* Conditionally render text boxes for selectedButton 1 */}
                  {selectedButton === 1 && (
                    <TextField
                      label={`Enter value for ${option}`}
                      variant="outlined"
                      fullWidth
                      value={textInputValues[option] || ""}
                      onChange={(e) =>
                        handleTextInputChange(option, e.target.value)
                      }
                      sx={{
                        marginTop: 2,
                        backgroundColor: "#1a1a1a",
                        borderRadius: "10px",
                        "& .MuiInputBase-root": {
                          color: "#00e0ff", // Input text color
                        },
                        "& .MuiOutlinedInput-root": {
                          "&:hover fieldset": {
                            borderColor: "#00e0ff", // Glowing effect on hover
                          },
                        },
                        "& .MuiInputLabel-root": {
                          color: "white", // Change label color to white
                        },
                      }}
                    />
                  )}

                  {/* Conditionally render text boxes for selectedButton 2 */}
                </Grid>
              ))}
          </Grid>
        </DialogContent>

        <DialogActions>
          <Button
            onClick={handleSave}
            color="primary"
            sx={{
              backgroundColor: "#00e0ff",
              color: "#000",
              fontFamily: "'Orbitron', sans-serif",
              padding: "12px 24px",
              borderRadius: "10px",
              boxShadow: "0 4px 10px rgba(0, 224, 255, 0.6)",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                backgroundColor: "#009acd",
                transform: "scale(1.05)",
                boxShadow: "0 6px 15px rgba(0, 156, 205, 0.6)",
              },
              "&:active": {
                transform: "scale(0.98)",
              },
            }}
            
          >
            OK
          </Button>

          <Button
            onClick={handleClose}
            color="primary"
            sx={{
              backgroundColor: "#1a1a1a",
              color: "#fff",
              fontFamily: "'Orbitron', sans-serif",
              padding: "12px 24px",
              borderRadius: "10px",
              boxShadow: "0 4px 10px rgba(255, 255, 255, 0.2)",
              transition: "all 0.3s ease-in-out",
              "&:hover": {
                backgroundColor: "#444444",
                transform: "scale(1.05)",
                boxShadow: "0 6px 15px rgba(255, 255, 255, 0.4)",
              },
              "&:active": {
                transform: "scale(0.98)",
              },
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default Buttons;
