import React, { useState } from 'react';
import { Button, Box, Typography, TextField, Paper, Grid } from '@mui/material';

const SphareCalibration = () => {
  // State hooks for tracking the current mode (Manual or Automatic)
  const [mode, setMode] = useState('');
  const [file, setFile] = useState(null);
  const [isStarted, setIsStarted] = useState(false);

  // Handle file upload
  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  // Handle Start button click
  const handleStart = () => {
    setIsStarted(true);
  };

  // Handle Stop button click
  const handleStop = () => {
    setIsStarted(false);
  };

  return (
    <Box sx={{ padding: 4 }}>
      <Paper elevation={3} sx={{ padding: 4 }}>
        <Typography variant="h4" gutterBottom>
          Sphare Calibration
        </Typography>

        {/* Mode Selection (Manual or Automatic) */}
        <Grid container spacing={2} justifyContent="center">
          <Grid item>
            <Button
              variant="contained"
              color={mode === 'Manual' ? 'primary' : 'default'}
              onClick={() => setMode('Manual')}
              fullWidth
            >
              Manual
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color={mode === 'Automatic' ? 'primary' : 'default'}
              onClick={() => setMode('Automatic')}
              fullWidth
            >
              Automatic
            </Button>
          </Grid>
        </Grid>

        {/* Display the selected mode */}
        {mode && (
          <Typography variant="h6" sx={{ marginTop: 2 }}>
            Selected Mode: {mode}
          </Typography>
        )}

        {/* File Upload (only visible when Manual mode is selected) */}
        {mode === 'Manual' && (
          <Box sx={{ marginTop: 3 }}>
            <TextField
              type="file"
              onChange={handleFileChange}
              fullWidth
              variant="outlined"
              label="Select File"
              inputProps={{ accept: '.txt, .csv, .xlsx' }} // Example file types
              InputLabelProps={{
                shrink: true,
              }}
              sx={{ marginBottom: 2 }}
            />
            {file && (
              <Typography variant="body1" color="textSecondary">
                Selected File: {file.name}
              </Typography>
            )}
          </Box>
        )}

        {/* Start and Stop Buttons */}
        <Grid container spacing={2} justifyContent="center" sx={{ marginTop: 3 }}>
          <Grid item>
            <Button
              variant="contained"
              color="success"
              onClick={handleStart}
              disabled={isStarted || !file}
              fullWidth
            >
              Start
            </Button>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="error"
              onClick={handleStop}
              disabled={!isStarted}
              fullWidth
            >
              Stop
            </Button>
          </Grid>
        </Grid>

        {/* Display status */}
        {isStarted && (
          <Typography variant="h6" color="primary" sx={{ marginTop: 2 }}>
            Calibration in progress...
          </Typography>
        )}
        {!isStarted && file && (
          <Typography variant="h6" sx={{ marginTop: 2 }}>
            Ready to start calibration with the selected file.
          </Typography>
        )}
        {!file && mode === 'Manual' && (
          <Typography variant="body1" color="textSecondary" sx={{ marginTop: 2 }}>
            Please upload a file to start the calibration.
          </Typography>
        )}
      </Paper>
    </Box>
  );
};

export default SphareCalibration;
