// src/components/BoreSightCalibration.js
import React, { useState } from "react";
import {
  Box,
  TextField,
  Button,
  Switch,
  Typography,
  FormControlLabel,
} from "@mui/material";

const BoreSightCalibration = () => {
  // States for Azimuth, Elevation, and configurations
  const [azimuth, setAzimuth] = useState("");
  const [elevation, setElevation] = useState("");

  // Azimuth Configuration
  const [isAzimuthEnabled, setIsAzimuthEnabled] = useState(false);
  const [rpm, setRpm] = useState("");

  // Elevation Configuration
  const [isElevationEnabled, setIsElevationEnabled] = useState(false);

  // Handlers for inputs and toggles
  const handleAzimuthChange = (e) => setAzimuth(e.target.value);
  const handleElevationChange = (e) => setElevation(e.target.value);
  const handleRpmChange = (e) => setRpm(e.target.value);

  const handleAzimuthEnableChange = () =>
    setIsAzimuthEnabled(!isAzimuthEnabled);
  const handleElevationEnableChange = () =>
    setIsElevationEnabled(!isElevationEnabled);

  // Handlers for CW, CCW, and STOP buttons
  const handleAzimuthButtonClick = (direction) => {
    alert(`Azimuth direction: ${direction}`);
  };

  const handleElevationButtonClick = (direction) => {
    alert(`Elevation direction: ${direction}`);
  };

  return (
    <Box sx={{ padding: 3 }}>
      {/* Main Heading */}
      <Typography variant="h4" gutterBottom>
        Boresight Calibration
      </Typography>

      {/* Azimuth Textbox */}
      <Box sx={{ marginBottom: 2 }}>
        <TextField
          label="Azimuth (deg)"
          fullWidth
          value={azimuth}
          onChange={handleAzimuthChange}
        />
      </Box>

      {/* Elevation Textbox */}
      <Box sx={{ marginBottom: 4 }}>
        <TextField
          label="Elevation (deg)"
          fullWidth
          value={elevation}
          onChange={handleElevationChange}
        />
      </Box>

      {/* Azimuth Configuration */}
      <Box
        sx={{
          backgroundColor: "#f4f4f4",
          padding: 3,
          borderRadius: 2,
          marginBottom: 3,
        }}
      >
        <Typography variant="h6" gutterBottom>
          Azimuth Configuration
        </Typography>

        <FormControlLabel
          control={
            <Switch
              checked={isAzimuthEnabled}
              onChange={handleAzimuthEnableChange}
              sx={{
                '& .MuiSwitch-thumb': {
                  backgroundColor: isAzimuthEnabled ? 'green' : 'red', // Green if on, red if off
                },
                '& .MuiSwitch-track': {
                  backgroundColor: isAzimuthEnabled ? 'rgba(131, 250, 131, 0.5)' : 'rgba(255, 0, 0, 0.5)', // Track color changes as well
                },
              }}
            />
          }
          label="Axis Enable"
        />

        <Box sx={{ marginTop: 2 }}>
          <TextField
            label="RPM"
            fullWidth
            value={rpm}
            onChange={handleRpmChange}
            disabled={!isAzimuthEnabled} // Disable RPM input if Axis is not enabled
          />
        </Box>

        {/* Azimuth Direction Buttons */}
        {isAzimuthEnabled && (
          <Box sx={{ display: "flex", gap: 2, marginTop: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleAzimuthButtonClick("CW")}
              sx={{ flexGrow: 1 }}
            >
              CW
            </Button>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => handleAzimuthButtonClick("CCW")}
              sx={{ flexGrow: 1 }}
            >
              CCW
            </Button>
            <Button
              variant="contained"
              onClick={() => handleElevationButtonClick("STOP")}
              sx={{
                flexGrow: 1,
                backgroundColor: "#e35662",
                "&:hover": { backgroundColor: "#d32f2f" },
              }}
            >
              STOP
            </Button>
          </Box>
        )}
      </Box>

      {/* Elevation Configuration */}
      <Box sx={{ backgroundColor: "#f4f4f4", padding: 3, borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom>
          Elevation Configuration
        </Typography>

        <FormControlLabel
          control={
            <Switch
              checked={isElevationEnabled}
              onChange={handleElevationEnableChange}
              sx={{
              '& .MuiSwitch-thumb': {
                backgroundColor: isElevationEnabled ? 'green' : 'red', // Green if on, red if off
              },
              '& .MuiSwitch-track': {
                backgroundColor: isElevationEnabled ? 'rgba(0, 255, 0, 0.5)' : 'rgba(255, 0, 0, 0.5)', // Track color changes as well
              },
            }}
        
            />
            
          }
          label="Axis Enable"
        />
        <Box sx={{ marginTop: 2 }}>
          <TextField
            label="RPM"
            fullWidth
            value={rpm}
            onChange={handleRpmChange}
            disabled={!isAzimuthEnabled} // Disable RPM input if Axis is not enabled
          />
        </Box>

        {/* Elevation Direction Buttons */}
        {isElevationEnabled && (
          <Box sx={{ display: "flex", gap: 2, marginTop: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleElevationButtonClick("UP")}
              sx={{ flexGrow: 1 }}
            >
              UP
            </Button>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => handleElevationButtonClick("DOWN")}
              sx={{ flexGrow: 1 }}
            >
              DOWN
            </Button>
            <Button
              variant="contained"
              onClick={() => handleElevationButtonClick("STOP")}
              sx={{
                flexGrow: 1,
                backgroundColor: "#e35662",
                "&:hover": { backgroundColor: "#d32f2f" },
              }}
            >
              STOP
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default BoreSightCalibration;
