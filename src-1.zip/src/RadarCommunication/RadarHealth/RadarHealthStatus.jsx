import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Container,
  Box,
} from "@mui/material";
import { Link } from "react-router-dom";
import HealthStatus from "../../Servo/LiveData/HealthStatus";

const RadarHealthStatus = () => {
  const [statusType, setStatusType] = useState("Pbit");
  const [selectedParameter, setSelectedParameter] = useState(null);

  // Radar parameters with Soft Alarm added for CBIT
  const parameters = [
    // { name: "Antenna", value: "" },
    // { name: "Horizontal SSPA", value: "" },
    // { name: "Vertical SSPA", value: "" },
    // { name: "Digital RF Subsystem", value: "" },
    // { name: "Power", value: "" },
    { name: "Servo", value: "" }, // Add Servo here
    // { name: "Fan", value: "" },
    // { name: "Soft Alarm", value: "", statusType: "Cbit" }, // Soft Alarm for CBIT
  ];

  const handleParameterClick = (param) => {
    setSelectedParameter(param); // Set the selected parameter to show details
  };

  return (
    <div>
      {/* Navbar */}
      <AppBar position="sticky" sx={{ backgroundColor: "#333" }}>
        <Container maxWidth="xl">
          <Toolbar disableGutters>
            {/* Logo or brand name */}
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              Radar Health Status
            </Typography>

            {/* Navigation buttons */}
            {/* <Box sx={{ display: { xs: "none", md: "flex" }, gap: 2 }}>
              <Button color="inherit" onClick={() => setStatusType("Pbit")}>
                PBIT Status
              </Button>

              <Button color="inherit" onClick={() => setStatusType("Cbit")}>
                CBIT Status
              </Button>

              <Button color="inherit" component={Link} to="/cbitPlot">
                CBIT Plot
              </Button>
              <Button color="inherit" component={Link} to="/offlinePlotting">
                Offline Plotting
              </Button>
            </Box> */}
          </Toolbar>
        </Container>
      </AppBar>

      {/* Radar Parameters Section */}
      <Box sx={{ display: "flex", marginTop: "16px" }}>
        {/* Left Side: List of Parameters */}
        <Box
          sx={{
            backgroundColor: "#f4f4f4", // A more readable color for the background
            padding: "16px",
            borderRadius: "8px",
            maxWidth: "400px", // Set the maximum width to limit the container width
            marginRight: "16px", // Add some space between the parameter list and details box
            overflow: "auto",
            display: "block",
          }}
        >
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "16px",
              color: "#333", // Dark color for text
            }}
          >
            {/* {statusType === "Pbit" ? "PBIT Status" : "CBIT Status"} */}
            Health Status
          </Typography>

          {/* Parameter List */}
          <Box display="flex" flexDirection="column" gap="12px">
            {parameters
              .filter((param) => !param.statusType || param.statusType === statusType) // Show parameters based on selected status type
              .map((param, index) => (
                <Box
                  key={index}
                  onClick={() => handleParameterClick(param)} // Attach click handler
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    background: "#b8dbc4",
                    borderRadius: "8px",
                    padding: "8px 16px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer", // Indicate clickable area
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.2)", // Highlight on hover
                    },
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{
                      fontWeight: "bold",
                      color: "#333", // Dark color for text
                      textTransform: "uppercase",
                      
                    }}
                  >
                    {param.name}
                  </Typography>
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: "medium",
                      color: "#333", // Dark color for text
                    }}
                  >
                    {param.value}
                  </Typography>
                </Box>
              ))}
          </Box>
        </Box>

        {/* Right Side: Parameter Details */}
        <Box
          sx={{
            backgroundColor: "#f4f4f4",
            padding: "16px",
            borderRadius: "8px",
            flex: 1, // This will make the box take remaining space
            display: selectedParameter ? "block" : "none", // Only show if a parameter is selected
            maxHeight: "790px",
            overflowY: "auto",
          }}
        >
          {selectedParameter && selectedParameter.name === "Servo" && <HealthStatus />}
          {/* Add any conditional components for other parameters here */}
          {selectedParameter && selectedParameter.name !== "Servo" && (
            <Typography variant="h6">
              Details for {selectedParameter.name}: {selectedParameter.value}
            </Typography>
          )}
        </Box>
      </Box>
    </div>
  );
};

export default RadarHealthStatus;
