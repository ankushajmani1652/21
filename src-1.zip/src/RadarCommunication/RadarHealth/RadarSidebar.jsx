// Sidebar.js
import React from 'react';
import { Drawer, List, ListItem, ListItemText, Divider, Box } from '@mui/material';
import { Link } from 'react-router-dom';

const Sidebar = ({ open, onClose }) => {
  return (
    <Drawer
      sx={{
        width: 250,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 250,
          boxSizing: 'border-box',
        },
      }}
      anchor="left"
      open={open}
      onClose={onClose}
    >
      <Box sx={{ width: 250 }} role="presentation">
        <List>
          <ListItem button component={Link} to="/pbit/antenna-horizontal">
            <ListItemText primary="Antenna Horizontal" />
          </ListItem>
          <ListItem button component={Link} to="/pbit/sspa-vertical">
            <ListItemText primary="SSPA Vertical" />
          </ListItem>
          <ListItem button component={Link} to="/pbit/digital-rf-subsystem">
            <ListItemText primary="Digital RF Subsystem" />
          </ListItem>
          <ListItem button component={Link} to="/pbit/power">
            <ListItemText primary="Power" />
          </ListItem>
          <ListItem button component={Link} to="/pbit/servo">
            <ListItemText primary="Servo" />
          </ListItem>
          <ListItem button component={Link} to="/pbit/fan">
            <ListItemText primary="FAN" />
          </ListItem>
        </List>
        <Divider />
      </Box>
    </Drawer>
  );
};

export default Sidebar;
