import React, { useState } from "react";
import {
  TextField,
  Button,
  Box,
  Typography,
  Container,
  Slide,
  Snackbar,
  Alert,
} from "@mui/material";
import { useSocket } from "../../SocketContext";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";

const SetMasterAdmin = () => {
  const [formData, setFormData] = useState({
    azimuthMaxAcceleration: "",
    azimuthMaxDeceleration: "",
    azimuthMaxSpeed: "",
    elevationMaxAcceleration: "",
    elevationMaxDeceleration: "",
    elevationMaxSpeed: "",
  });

  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const socket = useSocket();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleWarningClose = () => {
    setWarningOpen(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const showWarning = (message) => {
      setWarningMessage(message);
      setWarningOpen(true);
    };

    if (
      formData.azimuthMaxAcceleration === "" ||
      formData.elevationMaxAcceleration === "" ||
      formData.azimuthMaxSpeed === "" ||
      formData.elevationMaxSpeed === "" ||
      formData.azimuthMaxDeceleration === "" ||
      formData.elevationMaxDeceleration === ""
    ) {
      showWarning("Please enter all values");
    } else {
      socket.emit("setAdminParameters", formData);
      console.log(formData); // Replace with your submission logic
    }
  };

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          p: 4,
          borderRadius: "8px",
          boxShadow: 0,
          backgroundColor: "#fff",
        }}
      >
        <Typography variant="h4" gutterBottom fontWeight="bold" fontFamily= "'Times New Roman', serif" // Font for the label
        >
          Set Master Admin Parameters
        </Typography>
        <form
          onSubmit={handleSubmit}
          style={{ width: "100%", fontWeight: "bold" }}
        >
          <TextField
            fullWidth
            label="Azimuth Max Acceleration"
            type="number"
            name="azimuthMaxAcceleration"
            value={formData.azimuthMaxAcceleration}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}
          />
          <TextField
            fullWidth
            label="Azimuth Max Deceleration"
            type="number"
            name="azimuthMaxDeceleration"
            value={formData.azimuthMaxDeceleration}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <TextField
            fullWidth
            label="Azimuth Max Speed"
            type="number"
            name="azimuthMaxSpeed"
            value={formData.azimuthMaxSpeed}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <TextField
            fullWidth
            label="Elevation Max Acceleration"
            type="number"
            name="elevationMaxAcceleration"
            value={formData.elevationMaxAcceleration}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <TextField
            fullWidth
            label="Elevation Max Deceleration"
            type="number"
            name="elevationMaxDeceleration"
            value={formData.elevationMaxDeceleration}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <TextField
            fullWidth
            label="Elevation Max Speed"
            type="number"
            name="elevationMaxSpeed"
            value={formData.elevationMaxSpeed}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1rem", // Label font size
                fontFamily: "'Times New Roman', serif",
                color: "black", // Label color is black by default
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}
          />

          <Button
            type="submit"
            variant="contained"
            color="primary"
            sx={{ mt: 3 ,fontFamily: "'Times New Roman', serif" }}
            fullWidth
            // Font for the label

          >
            Submit
          </Button>
        </form>

        <Snackbar
          open={warningOpen}
          autoHideDuration={6000}
          onClose={handleWarningClose}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          TransitionComponent={(props) => <Slide {...props} direction="down" />}
        >
          <Alert
            onClose={handleWarningClose}
            severity="warning"
            sx={{
              width: "100%",
              backgroundColor: "#ffcc00",
              color: "#1a1a1a",
              fontWeight: "bold",
              fontSize: "1.2rem",
              boxShadow: "0 4px 15px rgba(0, 0, 0, 0.5)",
              border: "2px solid #ff9800",
            }}
            icon={
              <WarningAmberIcon
                fontSize="large"
                sx={{ marginRight: 1, color: "#ff9800" }}
              />
            }
          >
            {warningMessage}
          </Alert>
        </Snackbar>
      </Box>
    </Container>
  );
};

export default SetMasterAdmin;
