import React, { useState } from "react";
import {
  TextField,
  Button,
  Box,
  Typography,
  Container,
  Slide,
  Snackbar,
  Alert,
} from "@mui/material";
import { useSocket } from "../../SocketContext";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";

const BiasFactorSetting = () => {
  const [formData, setFormData] = useState({
    azimuthBias: "",
    elevationBias: "",
  });

  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const socket = useSocket();

  const showWarning = (message) => {
    setWarningMessage(message);
    setWarningOpen(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (formData.azimuthBias === "" || formData.elevationBias === "") {
      showWarning("Please enter all values");
    } else {
      socket.emit("setEncoderBias", formData);
      console.log(formData); // You can replace this with actual submission logic
    }
  };

  const handleFactorySettings = (e) => {
    e.preventDefault();
    socket.emit("factorySettings");
  };

  const handleWarningClose = () => {
    setWarningOpen(false);
  };

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          p: 4,
          borderRadius: "8px",
          boxShadow: 0,
          backgroundColor: "#fff",
        }}
      >
        <Typography variant="h4" gutterBottom fontWeight="bold" fontFamily= "'Times New Roman', serif"
 >
          Bias Settings
        </Typography>
        <form onSubmit={handleSubmit} style={{ width: "100%" }}>
          <TextField
            fullWidth
            label="Azimuth Encoder Bias"
            type="number"
            name="azimuthBias"
            value={formData.azimuthBias}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <TextField
            fullWidth
            label="Elevation Encoder Bias"
            type="number"
            name="elevationBias"
            value={formData.elevationBias}
            onChange={handleChange}
            margin="normal"
            InputLabelProps={{
              style: {
                fontWeight: "bold",
                fontSize: "1.2rem",
                fontSize: "1rem",
                fontFamily: "'Times New Roman', serif",
                color: "black",
              },
            }}
            InputProps={{ style: { fontSize: "1.03rem", fontFamily: "'Times New Roman', serif",
            } }}          />
          <Button
            type="submit"
            variant="contained"
            color="primary"
            sx={{ mt: 3 ,fontFamily: "'Times New Roman', serif"  }}
            fullWidth
          >
            Submit Bias Settings
          </Button>

          <Typography
            variant="h5"
            gutterBottom
            fontWeight="bold"
            marginTop="40px"
            textAlign="center"
            fontFamily= "'Times New Roman', serif" 
          >
            Factory Settings
          </Typography>
          <Button
            variant="contained"
            onClick={handleFactorySettings}
            sx={{
              mt: 0,
              backgroundColor: "#37373d", // Custom color
              "&:hover": {
                backgroundColor: "#3f3f3f", // Darker color on hover
              },
              fontFamily: "'Times New Roman', serif" 
            }}
            fullWidth
          >
            Restore Default Values
          </Button>
        </form>

        <Snackbar
          open={warningOpen}
          autoHideDuration={6000}
          onClose={handleWarningClose}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          TransitionComponent={(props) => <Slide {...props} direction="down" />}
        >
          <Alert
            onClose={handleWarningClose}
            severity="warning"
            sx={{
              width: "100%",
              backgroundColor: "#ffcc00",
              color: "#1a1a1a",
              fontWeight: "bold",
              fontSize: "1.2rem",
              boxShadow: "0 4px 15px rgba(0, 0, 0, 0.5)",
              border: "2px solid #ff9800",
            }}
            icon={
              <WarningAmberIcon
                fontSize="large"
                sx={{ marginRight: 1, color: "#ff9800" }}
              />
            }
          >
            {warningMessage}
          </Alert>
        </Snackbar>
      </Box>
    </Container>
  );
};

export default BiasFactorSetting;
