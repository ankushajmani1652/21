import React, { useState } from 'react';
import './Bias_Factory_Setting.css'; 

const Bias_Factory_Setting = ({ onSubmitBias, onRestoreDefaults }) => {
    const [azimuthBias, setAzimuthBias] = useState('');
    const [azimuthEncoderBias, setAzimuthEncoderBias] = useState('');
    const [elevationBias, setElevationBias] = useState('');
    const [elevationEncoderBias, setElevationEncoderBias] = useState('');

    const handleBiasSubmit = (e) => {
        e.preventDefault();
        const biasData = {
            azimuthBias,
            azimuthEncoderBias,
            elevationBias,
            elevationEncoderBias,
        };
        onSubmitBias(biasData); // Send the data to the server
    };

    const handleRestoreDefaults = () => {
        onRestoreDefaults(); // Trigger restoring default values
    };

    return (
        <div className="settings-page">
            <h1>Bias and Factor Settings</h1>

            <section className="bias-settings">
                <h2>Bias Settings</h2>
                <form onSubmit={handleBiasSubmit}>
                    <div className="form-group">
                        <label htmlFor="azimuthBias">Change Azimuth Bias:</label>
                        <input
                            type="number"
                            id="azimuthBias"
                            value={azimuthBias}
                            onChange={(e) => setAzimuthBias(e.target.value)}
                            placeholder="Enter azimuth bias"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="azimuthEncoderBias">Azimuth Encoder Bias:</label>
                        <input
                            type="number"
                            id="azimuthEncoderBias"
                            value={azimuthEncoderBias}
                            onChange={(e) => setAzimuthEncoderBias(e.target.value)}
                            placeholder="Enter azimuth encoder bias"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="elevationBias">Change Elevation Bias:</label>
                        <input
                            type="number"
                            id="elevationBias"
                            value={elevationBias}
                            onChange={(e) => setElevationBias(e.target.value)}
                            placeholder="Enter elevation bias"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="elevationEncoderBias">Elevation Encoder Bias:</label>
                        <input
                            type="number"
                            id="elevationEncoderBias"
                            value={elevationEncoderBias}
                            onChange={(e) => setElevationEncoderBias(e.target.value)}
                            placeholder="Enter elevation encoder bias"
                        />
                    </div>

                    <button type="submit" className="btn-submit">
                        Submit Bias Settings
                    </button>
                </form>
            </section>

            <section className="factor-settings">
                <h2>Factor Settings</h2>
                <button onClick={handleRestoreDefaults} className="btn-restore">
                    Restore Default Values
                </button>
            </section>
        </div>
    );
};

export default Bias_Factory_Setting
