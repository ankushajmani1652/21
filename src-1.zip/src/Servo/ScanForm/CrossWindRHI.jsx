import React, { useState } from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"; // Import necessary components

import {
  Box,
  Typography,
  TextField,
  Button,
  Tooltip,
  Snackbar,
  Alert,
} from "@mui/material";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const CrossWindRHI = ({ onSubmit, ackMessage, ackOpen, onAckClose,socket }) => {
  const [startAngle, setStartAngle] = useState();
  const [stopAngle, setStopAngle] = useState();
  const [elevationSpeed, setElevationSpeed] = useState("");
  const [windAngle, setWindAngle] = useState("");
  const [numElevationSteps, setNumElevationSteps] = useState();
  const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
  const [backTrackingChecked, setBackTrackingChecked] = useState(false);
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const [windAngleDetection, setWindAngleDetection] = useState(""); // State for dropdown

  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };
  const handleWindAngleDetectionChange = (event) => {
    setWindAngleDetection(event.target.value);
  };



  const handleElevationStartChange = ( value) => {
        
    const formattedValue =parseFloat(parseFloat(value).toFixed(2));// Format to 2 decimal places
   
    if (value < 0.00 || value > 180.00) {
        showWarning('Elevation angle must be between 0° and 180.00°.');
        return;
    }


    setStartAngle(formattedValue);
};



  const handleElevationSpeedChange = (value) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));
    if (value < 0 || value > 1.5) {
      showWarning('Elevation Speed must be between 0 and 1.5');
      return;
    }

    setElevationSpeed(numericValue);
  };



const handleRemoteWindAngleChange = (value) => {
  const values = parseFloat(parseFloat(value).toFixed(2));
  if (value < 0 || value > 360) {
    showWarning("Stop angle must be between 0° and 360°.");
  } else {
    setWindAngle(values);
  }
};


  const handleElevationStopChange = ( value) => {
        
    const formattedValues =parseFloat(parseFloat(value).toFixed(2));// Format to 2 decimal places

if (value < 0.00 || value > 180.00) {
  showWarning('Elevation angle must be between 0° and 180.00°.');
  return;
}


    setStopAngle(formattedValues);
};



  const handleSubmit = (event) => {
    if (event) event.preventDefault(); // Prevent default form submission
    

   
    let errors = []; // Collect all validation errors
  
    
    
    if (startAngle === undefined || startAngle === "" || startAngle < 0 || startAngle > 360) {
      errors.push("Start Angle is required and must be between 0° and 360°.");
    }
  
    
    if (stopAngle === undefined || stopAngle === "" || stopAngle < 0 || stopAngle > 360) {
      errors.push("Stop Angle is required and must be between 0° and 360°.");
    }
  
    if (elevationSpeed === undefined || elevationSpeed === "" || elevationSpeed <= 0) {
      errors.push("Elevation Speed is required and must be a positive value.");
    }
  
    
    if (windAngle === undefined || windAngle === "" || windAngle < 0 || windAngle > 360) {
      errors.push("Wind Angle must be between 0° and 360°.");
    }
  
   
    // if (numElevationSteps === undefined || numElevationSteps === "" || numElevationSteps <= 0) {
    //   errors.push("Number of Elevation Steps must be a positive value.");
    // }
  
   
    if (buzzerBypassChecked === undefined) {
      errors.push("Buzzer ByPass must be true or false.");
    }
  
   
    if (backTrackingChecked === undefined) {
      errors.push("Back Tracking must be true or false.");
    }
  
    
    if (windAngleDetection === undefined) {
      errors.push("Wind Angle Detection must be true or false.");
    }
  
    
    if (errors.length > 0) {
      showWarning("Please enter all values"); 
     
      return; 
    }

    
    // If no errors, proceed with form submission
    const formData = {
      scanType: "crosswind",
      elevationStartAngle: startAngle,
      elevationEndAngle: stopAngle,
      elevationSpeed: elevationSpeed,
      remoteWindAngle: windAngle,
      numElevationSteps: numElevationSteps,
      buzzerBypass: buzzerBypassChecked,
      backTracking: backTrackingChecked,
      windAngleDetection: windAngleDetection,
    };
  

    // Emit the form data to the socket
    socket.emit("crossAlongWindRHI", formData);
  
    // Log form data to the console (optional)
    console.log("Form Data Submitted:", formData);
  
    
    // onSubmit(formData);
  };
  
  
  const handleWarningClose = () => {
    setWarningOpen(false);
};
  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "#fff",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom></Typography>

      {/* Elevation Start and Stop Angle */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Start Angle:
          </Typography>
          <TextField
            type="number"
            value={startAngle}
            onChange={(e) =>
              handleElevationStartChange(
               
                e.target.value
                
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
            Range: 0° - 180°
          </Typography>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Stop Angle:
          </Typography>
          <TextField
            type="number"
            value={stopAngle}
            onChange={(e) =>
              handleElevationStopChange(
               
                e.target.value
             
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: "right",color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
            Range: 0° - 180°
          </Typography>
        </Box>
      </Box>

      {/* Elevation Speed */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Elevation Speed:
        </Typography>
        <TextField
          type="number"
          value={elevationSpeed}
          onChange={(e) =>
            handleElevationSpeedChange(
               e.target.value
              
            )
          }
          fullWidth
          inputProps={{ min: "", max:  1.5}}
          sx={{
            input: { color: "black",fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 0 - 1.5
        </Typography>
      </Box>

      {/* Remote Wind Angle */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Remote Wind Angle:
        </Typography>
        <TextField
          type="number"
          value={windAngle}
          onChange={(e) =>
            handleRemoteWindAngleChange(
           
              e.target.value
              
            )
          }
          fullWidth
          inputProps={{ min: 0, max: 360 }}
          sx={{
            input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right",color: "black", fontWeight:"bold" ,fontFamily: "'Times New Roman', serif"}}>
          Range: 0° - 360°
        </Typography>
      </Box>
      <Box sx={{ flex: 1, marginBottom: 3, marginTop: 3 }}>
        <Tooltip title="Select wind angle detection method" arrow>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Wind Angle Detection:
          </Typography>
        </Tooltip>
        <FormControl fullWidth>
          <Select
            value={windAngleDetection}
            onChange={handleWindAngleDetectionChange}
            displayEmpty
            renderValue={(selected) => {
              if (!selected) {
                return "Select a Method"; // Placeholder text
              }
              return selected;
            }}
            sx={{
              color: "black",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              fontWeight:"bold"
              ,fontFamily: "'Times New Roman', serif"
            }}
          >
            <MenuItem value="Remote" sx={{fontFamily:"'Times New Roman', serif"}}>Remote</MenuItem>
            <MenuItem value="Servo" sx={{fontFamily:"'Times New Roman', serif"}}>Servo</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Number of Elevation Steps */}
      <Box sx={{ display: "flex", alignItems: "center", marginBottom: 3 }}>
  <Typography variant="h5" sx={{ marginRight: 2, fontWeight: "bold" ,color: "black" ,fontFamily: "'Times New Roman', serif"}}>
    Number of Elevation Steps:
  </Typography>
  <Typography variant="h6" sx={{ color: "#00bcd4", fontWeight: "bold" }}>
    70
  </Typography>
</Box>


      {/* Buzzer By-pass and Back Tracking */}
      <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
        {/* <Button
          variant={buzzerBypassChecked ? "contained" : "outlined"}
          onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
          sx={{
            backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
            color: buzzerBypassChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
          }}
        >
          {buzzerBypassChecked
            ? "Buzzer By-pass: Enabled"
            : "Buzzer By-pass: Disabled"}
        </Button>
        <Button
          variant={backTrackingChecked ? "contained" : "outlined"}
          onClick={() => setBackTrackingChecked(!backTrackingChecked)}
          sx={{
            backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
            color: backTrackingChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
          }}
        >
          {backTrackingChecked
            ? "Back Tracking: Enabled"
            : "Back Tracking: Disabled"}
        </Button> */}

<Button
    variant={buzzerBypassChecked ? "contained" : "outlined"}
    onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
    sx={{
      backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
      color: buzzerBypassChecked ? "#fff" : "#00bcd4",
      "&:hover": {
        backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
        color: "#fff",
      },
      flex: 1,
      display: "block", 
       minWidth: "200px"
   ,fontFamily: "'Times New Roman', serif"
      }}
  >
    Buzzer By-Pass
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
      {buzzerBypassChecked ? "Enabled" : "Disabled"}
    </Typography>
  </Button>

  <Button
    variant={backTrackingChecked ? "contained" : "outlined"}
    onClick={() => setBackTrackingChecked(!backTrackingChecked)}
    sx={{
      backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
      color: backTrackingChecked ? "#fff" : "#00bcd4",
      "&:hover": {
        backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
        color: "#fff",
      },
      flex: 1,
      display: "block", // Ensures the content wraps
       minWidth: "200px"
 ,fontFamily: "'Times New Roman', serif"
      }}
  >
    Back Tracking
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
      {backTrackingChecked ? "Enabled" : "Disabled"}
    </Typography>
  </Button>

      </Box>

      {/* Submit Button */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          gap: 2,
          marginTop: 2,
        }}
      >
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
          ,fontFamily: "'Times New Roman', serif"
          }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
         
            flex: 1 // Adjusts width proportionally
         ,fontFamily: "'Times New Roman', serif"
          }}
        >
          Send
        </Button>
      </Box>

      {/* Snackbar for Warnings */}
      <Snackbar
    open={warningOpen}
    autoHideDuration={6000}
    onClose={handleWarningClose}
    anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
    TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
>
    <Alert
        onClose={handleWarningClose}
        severity="warning"
        sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
        }}
        icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
    >
        {warningMessage}
    </Alert>
</Snackbar>
    </Box>
  );
};

export default CrossWindRHI;
