import React, { useState } from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"; // Import necessary components

import {
  Box,
  Typography,
  TextField,
  Button,
  Tooltip,
  Snackbar,
  Alert,
} from "@mui/material";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const BoundaryLayerRHI = ({ onSubmit, ackMessage, ackOpen, onAckClose,socket }) => {
  const [startAngle, setStartAngle] = useState("");
  const [stopAngle, setStopAngle] = useState("");
  const [elevationSpeed, setElevationSpeed] = useState("");
  const [windAngle, setWindAngle] = useState("");
  const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
  const [backTrackingChecked, setBackTrackingChecked] = useState(false);
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const [windAngleDetection, setWindAngleDetection] = React.useState("");
  const [numAzimuth, setNumAzimuth] = useState(""); // Number of elevations

  const [numRHI, setNumRHI] = useState(""); // Number of RHI
  const [numAzimuthSteps, setNumAzimuthSteps] = useState(""); // Number of Azimuth Steps
  const [azimuthAngles, setAzimuthAngles] = useState([]); // Array for azimuth angles
  
  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };
  
  const handleWindAngleDetectionChange = (event) => {
    setWindAngleDetection(event.target.value);
  };

  const handleInputChange = (setter, value, min, max, message) => {
    const numericValue = parseInt(value);
    const isValidDecimal = /^\d+(\.\d{0,2})?$/.test(value); // Regex to allow up to 2 decimal places
  
    if (!isValidDecimal || numericValue < min || numericValue > max || isNaN(numericValue)) {
      showWarning(message);
      setter("min"); // Set to the minimum if invalid
    } else {
      setter(value); // Keep the valid value
    }
  };

  const handleAzimuthStepsChange = (value) => {
    handleInputChange(
      setNumAzimuthSteps,
      value,
      "",
      45,
      "Number of Azimuth Steps must be between 1 and 45."
    );
  
    const steps = parseInt(value, 10);
    if (steps >= 1 && steps <= 45) {
      const updatedAzimuthAngles = Array(steps).fill(""); // Reset the array with empty values
      setAzimuthAngles(updatedAzimuthAngles);
    }
  };
  
  const handleAzimuthAngleChange = (index, value) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));

    // Check if the value is within the valid range (0 - 360)
    if (numericValue >= 0 && numericValue <= 360) {
      const newAngles = [...azimuthAngles];
      newAngles[index] = numericValue; // Update the specific angle
      setAzimuthAngles(newAngles);
    } else {
      // If value is out of range, show a warning and reset the value
      showWarning("Azimuth Angle must be between 0° and 360°.");
      const newAngles = [...azimuthAngles];
      newAngles[index] = ""; // Reset the angle to empty if invalid
      setAzimuthAngles(newAngles);
    }
  };

  const handleElevationSpeedChange = (value) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));
    if (value < 0 || value > 1.5) {
      showWarning('Elevation Speed must be between 0 and 1.5');
      return;
    }

    setElevationSpeed(numericValue);
  };

  

  const handleNumAzimuthChange = (event) => {
    const num = parseInt(event.target.value, 10);
    if (isNaN(num) || num < 0 || num > 36) {
      showWarning("Number of elevations must be between 0 and 36.");
      setNumAzimuth(num < 0 || isNaN(num) ? "" : 36); // Clamp the value within range
    } else {
      setNumAzimuth(num);
      setAzimuthAngles(Array(num).fill(0)); // Initialize elevation angles to 0
    }
  };

  const handleSubmit = (event) => {
    if (event) event.preventDefault(); // Prevent default form submission
  
    let errors = []; // Collect all validation errors
  
    
    if (startAngle === "" || startAngle < 0 || startAngle > 360) {
      errors.push("Start Angle is required and must be between 0° and 360°.");
    }
  
    
    if (stopAngle === "" || stopAngle < 0 || stopAngle > 360) {
      errors.push("Stop Angle is required and must be between 0° and 360°.");
    }
  
   
    if (elevationSpeed === "" || elevationSpeed <= 0) {
      errors.push("Elevation Speed is required and must be a positive value.");
    }
  
    
    if (windAngleDetection === undefined) {
      errors.push("Wind Angle Detection must be specified.");
    }
  
   
    if (buzzerBypassChecked === undefined) {
      errors.push("Buzzer Bypass must be true or false.");
    }
  
  
    if (backTrackingChecked === undefined) {
      errors.push("Back Tracking must be true or false.");
    }
  
   
    if (numRHI === "" || numRHI <= 0) {
      errors.push("Number of RHI Sets must be a positive value.");
    }
  
   
    if (windAngle === "" || windAngle < 0 || windAngle > 360) {
      errors.push("Wind Angle must be between 0° and 360°.");
    }
  
   
    if (numAzimuthSteps === "" || numAzimuthSteps <= 0) {
      errors.push("Number of Azimuth Steps must be a positive value.");
    }
  
    
    if (azimuthAngles.some(angle => angle === "" || angle < 0 || angle > 360)) {
      errors.push("All Azimuth Angles must be between 0° and 360°.");
    }
  
    // If there are any validation errors, show them
    if (errors.length > 0) {
      showWarning("Please enter all values"); 
      return;
    }
  
    // If no errors, proceed with form submission
    const formData = {
      elevationStartAngle: startAngle,
      elevationEndAngle: stopAngle,
      elevationSpeed: elevationSpeed,
      windAngleDetection,
      buzzerBypass: buzzerBypassChecked,
      backTracking: backTrackingChecked,
      noOfRHISets: numRHI,
      remoteWindAngle: windAngle,
      noOfAzimuthSteps: numAzimuthSteps,
      azimuthAngles, // Include Azimuth Angles
    };
  
    // Emit the form data to the socket
    socket.emit("boundaryLayer", formData);
  
    // Log form data to the console (optional)
    console.log("Form Data Submitted:", formData);
  
    // Optionally, you can also call onSubmit to send the data to the parent component
    // onSubmit(formData);
  };
  
  const handleWarningClose = () => {
    setWarningOpen(false);
};

  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "#fff",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom></Typography>

      {/* Elevation Start and Stop Angle */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Start Angle:
          </Typography>
          <TextField
            type="number"
            value={startAngle}
            onChange={(e) =>
              handleInputChange(
                setStartAngle,
                e.target.value,
                "",
                180,
                "Start angle must be between 0° and 180°."
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180  }}
            sx={{
              input: { color: "black",fontWeight:"bold"  ,fontFamily: "'Times New Roman', serif"
              },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
                
              },
            }}
          />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
            Range: 0° - 180°
          </Typography>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif"> 
            Elevation Stop Angle:
          </Typography>
          <TextField
            type="number"
            value={stopAngle}
            onChange={(e) =>
              handleInputChange(
                setStopAngle,
                e.target.value,
                "",
                180,
                "Stop angle must be between 0° and 180°."
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold" ,fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
            Range: 0° - 180°
          </Typography>
        </Box>
      </Box>

      {/* Elevation Speed */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Elevation Speed:
        </Typography>
        <TextField
  type="number"
  value={elevationSpeed}
  onChange={(e) =>
    handleElevationSpeedChange(
    
      e.target.value
     
    )
  }
  fullWidth
  inputProps={{
    step: "0.01", // Allow steps of 0.01
    min: "0",
    max: "1.5",
  }}
  sx={{
    input: { color: "black",fontFamily: "'Times New Roman', serif" ,fontWeight:"bold" },
    "& .MuiOutlinedInput-root fieldset": {
      borderColor: "#00bcd4",
    },
    "&:hover .MuiOutlinedInput-root fieldset": {
      borderColor: "#00bcd4",
    },
  }}
/>

        
      </Box>

      {/* Remote Wind Angle */}
      <Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Remote Wind Angle:
        </Typography>
        <TextField
          type="number"
          value={windAngle}
          onChange={(e) =>
            handleInputChange(
              setWindAngle,
              e.target.value,
              "",
              360,
              "Wind angle must be between 0° and 360°."
            )
          }
          fullWidth
          inputProps={{ min: 0, max: 360 }}
          sx={{
            input: { color: "black",fontWeight:"bold" ,fontFamily: "'Times New Roman', serif"},
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 0° - 360°
        </Typography>
      </Box>
      <Box sx={{ flex: 1, marginBottom: 3, marginTop: 3 }}>
        <Tooltip title="Select wind angle detection method" arrow>
          <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Wind Angle Detection:
          </Typography>
        </Tooltip>
        <FormControl fullWidth>
  <Select
    value={windAngleDetection}
    onChange={handleWindAngleDetectionChange}
    displayEmpty
    renderValue={(selected) => {
      if (!selected) {
        return "Select a Method"; // Placeholder text
      }
      return selected;
    }}
    sx={{
      color: "black",
      "& .MuiOutlinedInput-notchedOutline": {
        borderColor: "#00bcd4",
      },
      "&:hover .MuiOutlinedInput-notchedOutline": {
        borderColor: "#00bcd4",
      },
      fontWeight:"bold"
      , fontWeight:"bold",fontFamily: "'Times New Roman', serif"
    }}
  >
    <MenuItem value="Remote" sx={{fontFamily:"'Times New Roman', serif"}}>Remote</MenuItem>
    <MenuItem value="Servo" sx={{fontFamily:"'Times New Roman', serif"}}>Servo</MenuItem>
  </Select>
</FormControl>

      </Box>

      {/* Number of Elevation Steps */}

<Box sx={{ marginBottom: 3 }}>
  <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
    Number of RHI:
  </Typography>
  <TextField
    type="number"
    value={numRHI}
    onChange={(e) =>
      handleInputChange(
        setNumRHI,
        e.target.value,
        "",
        5,
        "Number of RHI must be between 1 and 5."
      )
    }
    fullWidth
    inputProps={{ min: 1, max: 5 }}
    sx={{
      input: { color: "black",fontWeight:"bold",fontFamily: "'Times New Roman', serif" },
      "& .MuiOutlinedInput-root fieldset": {
        borderColor: "#00bcd4",
      },
      "&:hover .MuiOutlinedInput-root fieldset": {
        borderColor: "#00bcd4",
      },
    }}
  />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
    Range: 1 - 5
  </Typography>
</Box>

{/* Number of Azimuth Steps */}
<Box sx={{ marginBottom: 3 }}>
        <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
          Number of Azimuth Steps:
        </Typography>
        <TextField
          type="number"
          value={numAzimuthSteps}
          onChange={(e) => handleAzimuthStepsChange(e.target.value)}
          fullWidth
          inputProps={{ min: 1, max: 45 }}
          sx={{
            input: { color: "black",fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
            "& .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
            "&:hover .MuiOutlinedInput-root fieldset": {
              borderColor: "#00bcd4",
            },
          }}
        />
        <Typography variant="body2" sx={{ textAlign: "right" ,color: "black", fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          Range: 1 - 45
        </Typography>
      </Box>

      {/* Azimuth Angles */}
      {/* Azimuth Angles */}
{Array.from({ length: numAzimuthSteps }).map((_, index) => (
  <Box
    key={index}
    sx={{
      marginBottom: 3,
      display: "flex",
      justifyContent: "space-between",
    }}
  >
    <Box sx={{ width: "100%" }}>
      <Typography variant="h5" gutterBottom color="black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
        Azimuth Angle {index + 1}:
      </Typography>
      <TextField
  value={azimuthAngles[index] || ""}
  onChange={(e) => handleAzimuthAngleChange(index, e.target.value)}
  type="number"
  fullWidth
  inputProps={{
    min: "", // Set minimum value
    max: 360, // Set maximum value
  }}
  sx={{
    input: { color: "black" ,fontWeight:"bold",fontFamily: "'Times New Roman', serif"},
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#00bcd4",
      },
      "&:hover fieldset": {
        borderColor: "#00bcd4",
      },
    },
  }}
/>

    </Box>
  </Box>
))}


      

      {/* Buzzer By-pass and Back Tracking */}
      <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
        <Button
          variant={buzzerBypassChecked ? "contained" : "outlined"}
          onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
          sx={{
            backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
            color: buzzerBypassChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            , fontWeight:"bold",fontFamily: "'Times New Roman', serif"          }}
        >Buzzer By-pass:
                    <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 , fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          
          {buzzerBypassChecked
            ? " Enabled"
            : " Disabled"}
                      </Typography>
            
        </Button>
        <Button
          variant={backTrackingChecked ? "contained" : "outlined"}
          onClick={() => setBackTrackingChecked(!backTrackingChecked)}
          sx={{
            backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
            color: backTrackingChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            , fontWeight:"bold",fontFamily: "'Times New Roman', serif"          }}
        >Back Tracking: 
                    <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 , fontWeight:"bold",fontFamily: "'Times New Roman', serif"}}>
          
          {backTrackingChecked
            ? "Enabled"
            : " Disabled"}
                      </Typography>
            
        </Button>
      </Box>


      {/* Submit Button */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          gap: 2,
          marginTop: 2,
        }}
      >
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
, fontWeight:"bold",fontFamily: "'Times New Roman', serif"
          }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: "#00bcd4",
            "&:hover": {
              backgroundColor: "#0097a7",
            },
            flex: 1 // Adjusts width proportionally
         , fontWeight:"bold",fontFamily: "'Times New Roman', serif"
          }}
        >
          Send
        </Button>
      </Box>

      {/* Snackbar for Warnings */}
      <Snackbar
    open={warningOpen}
    autoHideDuration={6000}
    onClose={handleWarningClose}
    anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
    TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
>
    <Alert
        onClose={handleWarningClose}
        severity="warning"
        sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
        }}
        icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
    >
        {warningMessage}
    </Alert>
</Snackbar>
    </Box>
  );
};

export default BoundaryLayerRHI;
