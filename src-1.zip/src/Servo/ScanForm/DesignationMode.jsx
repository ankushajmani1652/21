import React, { useState } from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material"; // Import necessary components

import {
  Box,
  Typography,
  TextField,
  Button,
  Tooltip,
  Snackbar,
  Alert,
} from "@mui/material";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const DesignationMode = ({ onSubmit, ackMessage, ackOpen, onAckClose,socket }) => {
  const [azimuthDesignateAngle, setAzimuthDesignateAngle] = useState("");
  const [azimuthAxisSpeed, setAzimuthAxisSpeed] = useState("");
  const [elevationDesignateAngle, setElevationDesignateAngle] = useState("");
  const [elevationAxisSpeed, setElevationAxisSpeed] = useState("");
  
  // Initialize the missing state variables
  const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false); // Correctly define this state
  const [backTrackingChecked, setBackTrackingChecked] = useState(false); // Correctly define this state
  
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const [designatType, setdesignatType] = useState(""); // State for dropdown

  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };
  const handledesignatTypeChange = (event) => {
    setdesignatType(event.target.value);
  };

  const handleInputChange = (setter, value, min, max, message) => {
    const numericValue = parseFloat(parseFloat(value).toFixed(2));
    if (numericValue < min || numericValue > max || isNaN(numericValue)) {
      showWarning(message);
      setter(min); // Set to the minimum if invalid
    } else {
      setter(numericValue);
    }
  };

  const handleAzimuthSpeedChange = (value) => {
   
    if (value < 0 || value > 4) {
        showWarning('Azimuth Scan Speed must be between 0 and 4');
        return;
    }
const newSpeed=parseFloat(parseFloat(value).toFixed(2));
   
    setAzimuthAxisSpeed(newSpeed);
};

const handleElevationSpeedChange = (value) => {
   
  if (value < 0 || value > 2) {
      showWarning('Azimuth Scan Speed must be between 0 and 2');
      return;
  }
const newSpeed=parseFloat(parseFloat(value).toFixed(2));
 
  setElevationAxisSpeed(newSpeed);
};

  const handleSubmit = (event) => {
    if (event) event.preventDefault();

    let errors = [];

    if (azimuthDesignateAngle === undefined || azimuthDesignateAngle === "" || azimuthDesignateAngle < -180 || azimuthDesignateAngle > 180) {
        errors.push("Azimuth Angle is required and must be between -180° and 180°.");
    }

    if (azimuthAxisSpeed === undefined || azimuthAxisSpeed === "" || azimuthAxisSpeed <= 0) {
        errors.push("Azimuth Speed is required and must be a positive value.");
    }

    if (elevationDesignateAngle === undefined || elevationDesignateAngle === "" || elevationDesignateAngle < -90 || elevationDesignateAngle > 90) {
        errors.push("Elevation Angle is required and must be between -90° and 90°.");
    }

    if (elevationAxisSpeed === undefined || elevationAxisSpeed === "" || elevationAxisSpeed <= 0) {
        errors.push("Elevation Speed is required and must be a positive value.");
    }

    if (buzzerBypassChecked === undefined) {
        errors.push("Azimuth Enable must be true or false.");
    }

    if (backTrackingChecked === undefined) {
        errors.push("Elevation Enable must be true or false.");
    }

    if (designatType === undefined || designatType === "") {
        errors.push("Designate Type is required.");
    }

    if (errors.length > 0) {
      showWarning("Please enter all values"); 
        return;
    }

    const formData = {
        azimuthAngle: azimuthDesignateAngle,
        azimuthSpeed: azimuthAxisSpeed,
        elevationAngle: elevationDesignateAngle,
        elevationSpeed: elevationAxisSpeed,
        azimuthEnable: buzzerBypassChecked,
        elevationEnable: backTrackingChecked,
        designateType: designatType
    };

    socket.emit("designate-mode", formData);
    console.log("Form Data Submitted:", formData);
};

  const handleWarningClose = () => {
    setWarningOpen(false);
};
  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "#fff",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom>
        {/* Title or Instructions */}
      </Typography>

      {/* Dropdown for wind angle detection */}
      <Box sx={{ flex: 1, marginBottom: 3, marginTop: 3 }}>
        <Tooltip title="Select wind angle detection method" arrow>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Select Designate Type
          </Typography>
        </Tooltip>
        <FormControl fullWidth>
          <Select
            value={designatType}
            onChange={handledesignatTypeChange}
            displayEmpty
            renderValue={(selected) => {
              if (!selected) {
                return "Select type"; // Placeholder text
              }
              return selected;
            }}
            sx={{
              color: "black",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: "#00bcd4",
              },
              fontWeight:"bold"
              , fontFamily: "'Times New Roman', serif"
            }}
          >
            <MenuItem value="Single" sx={{fontFamily:"'Times New Roman', serif"}}>Single Designate</MenuItem>
            <MenuItem value="Command" sx={{fontFamily:"'Times New Roman', serif"}}>Command Designate</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Azimuth Designate and Axis Speed */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Azimuth Designate Angle:
          </Typography>
          <TextField
            type="number"
            value={azimuthDesignateAngle}
            onChange={(e) =>
              handleInputChange(
                setAzimuthDesignateAngle,
                e.target.value,
                "",
                360,
                "Azimuth designate angle must be between 0° and 360°."
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
           <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
                      Range: 0° - 360°
                  </Typography>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Azimuth Axis Speed
          </Typography>
          <TextField
            type="number"
            value={azimuthAxisSpeed}
            onChange={(e) =>
              handleAzimuthSpeedChange(
                e.target.value
              
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black", fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
          <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
                      Range: 0 - 4
                  </Typography>
        </Box>
      </Box>

      {/* Elevation Designate and Axis Speed */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Designate Angle:
          </Typography>
          <TextField
            type="number"
            value={elevationDesignateAngle}
            onChange={(e) =>
              handleInputChange(
                setElevationDesignateAngle,
                e.target.value,
                "",
                180,
                "Elevation designate angle must be between 0° and 180°."
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
           <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
                      Range: 0° - 180°
                  </Typography>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" gutterBottom color= "black" fontWeight="bold" fontFamily= "'Times New Roman', serif">
            Elevation Axis Speed
          </Typography>
          <TextField
            type="number"
            value={elevationAxisSpeed}
            onChange={(e) =>
              handleElevationSpeedChange(
                
                e.target.value
             
              )
            }
            fullWidth
            inputProps={{ min: 0, max: 180 }}
            sx={{
              input: { color: "black",fontWeight:"bold" , fontFamily: "'Times New Roman', serif"},
              "& .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
              "&:hover .MuiOutlinedInput-root fieldset": {
                borderColor: "#00bcd4",
              },
            }}
          />
           <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:"bold",fontFamily: "'Times New Roman', serif" }}>
                    Range: 0 - 2
                </Typography>
        </Box>
        
      </Box>

      {/* Buzzer By-pass and Back Tracking */}
      <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
      <Button
    variant={buzzerBypassChecked ? "contained" : "outlined"}
    onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
    sx={{
      backgroundColor: buzzerBypassChecked ? "#00bcd4" : "transparent",
      color: buzzerBypassChecked ? "#fff" : "#00bcd4",
      "&:hover": {
        backgroundColor: buzzerBypassChecked ? "#0097a7" : "#00bcd4",
        color: "#fff",
      },
      flex: 1,
      display: "block", // Ensures the content wraps
       minWidth: "200px"
       ,fontFamily: "'Times New Roman', serif"
    }}
  >
    Azimuth Axis
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
      {buzzerBypassChecked ? "Enabled" : "Disabled"}
    </Typography>
  </Button>

  <Button
    variant={backTrackingChecked ? "contained" : "outlined"}
    onClick={() => setBackTrackingChecked(!backTrackingChecked)}
    sx={{
      backgroundColor: backTrackingChecked ? "#00bcd4" : "transparent",
      color: backTrackingChecked ? "#fff" : "#00bcd4",
      "&:hover": {
        backgroundColor: backTrackingChecked ? "#0097a7" : "#00bcd4",
        color: "#fff",
      },
      flex: 1,
      display: "block", // Ensures the content wraps
       minWidth: "200px"
       ,fontFamily: "'Times New Roman', serif"
    }}
  >
    Elevation Axis
          <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
      {backTrackingChecked ? "Enabled" : "Disabled"}
    </Typography>
  </Button>

      </Box>

      {/* Submit Button */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, marginTop: 2 }}>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: '#00bcd4',
            '&:hover': {
              backgroundColor: '#0097a7',
            },
            flex: 1
            ,fontFamily: "'Times New Roman', serif" // Adjusts width proportionally
          }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          sx={{
            backgroundColor: '#00bcd4',
            '&:hover': {
              backgroundColor: '#0097a7',
            },
            flex: 1
            ,fontFamily: "'Times New Roman', serif" // Adjusts width proportionally
          }}
        >
          Send
        </Button>
      </Box>

      {/* Snackbar for Warnings */}
       <Snackbar
       open={warningOpen}
       autoHideDuration={6000}
       onClose={handleWarningClose}
       anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
       TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
   >
       <Alert
           onClose={handleWarningClose}
           severity="warning"
           sx={{
               width: '100%',
               backgroundColor: '#ffcc00', // Vibrant yellow for visibility
               color: '#1a1a1a', // Dark text for better contrast
               fontWeight: 'bold',
               fontSize: '1.2rem', // Larger font size
               boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
               border: '2px solid #ff9800', // Border for emphasis
           }}
           icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
       >
           {warningMessage}
       </Alert>
   </Snackbar>
    </Box>
  );
};

export default DesignationMode;
