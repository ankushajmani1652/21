import React, { useState } from 'react';
import {
    Button,
    Box,
    Typography,
    Slider,
    TextField,
    Tooltip,
    Snackbar,
    Alert,
} from '@mui/material';
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const AzimuthScanForm = ({ onSubmit, ackMessage, ackOpen, onAckClose,socket }) => {
    const [azimuthStartAngle, setStartAngle] = useState("");
    const [azimuthEndAngle, setStopAngle] = useState("");
    const [buzzerBypassChecked, setBuzzerBypassChecked] = useState(false);
    const [backTrackingChecked, setBackTrackingChecked] = useState(false);
    const [noOfElevations, setNumElevation] = useState(""); // Number of elevations
    const [elevationAngles, setElevationAngles] = useState([""]); // Elevation angles array
    const [azimuthScanSpeed, setAzimuthScanSpeed] = useState([]); // Azimuth scan speeds
    const [warningOpen, setWarningOpen] = useState(false);
    const [warningMessage, setWarningMessage] = useState('');


    const showWarning = (message) => {
        setWarningMessage(message);
        setWarningOpen(true);
    };

    // const handleStartAngleChange = (event) => {
    //     const value = parseFloat(event.target.value, 10);
    //     if (value < 0 || value > 360) {
    //       showWarning("Start angle must be between 0° and 360°.");
    //     } else {
    //       setStartAngle(value);
    //     }
    //   };

    // const handleStopAngleChange = (event) => {
    //     const value = parseFloat(event.target.value, 10);

    //     if (/^\d*\.?\d{0,2}$/.test(value)) {
    //         const numericValue = parseFloat(value);
    //           // Ensure the value is within range
    //           if (value == "" || (numericValue >= -2.00 && numericValue <= 182.00)) {
    //             setStopAngle(numericValue);
    //          } else {
    //            showWarning("Elevation Stop angle must be between 0° and 360°.");
    //         }
    //     } 
    //     // if (value < 0 || value > 360) {
    //     //     showWarning('Stop angle must be between 0° and 360°.');
    //     // } else {
    //     //     setStopAngle(value);
    //     // }
    // };



    const handleStartAngleChange = (event) => {
        // let value = event.target.value;
        
        // // Allow an empty string to handle backspace
        // if (value === "") {
        //   setStartAngle(value); // Allow empty input when backspacing
        //   return;
        // }
      
        // // Regular expression for up to two decimal places
        // const regex = /^-?\d+(\.\d{0,2})?$/;
      
        // // Check if the value matches the regex pattern (up to two decimal places)
        // if (regex.test(value)) {
        //   setStartAngle(value); // Update state with valid value
        // }
        const value = parseFloat(parseFloat(event.target.value).toFixed(2));
        //const value = parseFloat(event.target.value, 10);
        if (value < 0 || value > 360) {
            showWarning('Start angle must be between 0° and 360°.');
        } else {
            setStartAngle(value);
        }
      };
      
      const handleStopAngleChange = (event) => {

        const value = parseFloat(parseFloat(event.target.value).toFixed(2));
        //const value = parseFloat(event.target.value, 10);
        if (value < 0 || value > 360) {
            showWarning('Start angle must be between 0° and 360°.');
        } else {
            setStopAngle(value);
        }

        // let value = event.target.value;
      
        // // Allow an empty string to handle backspace
        // if (value === "") {
        //   setStopAngle(value); // Allow empty input when backspacing
        //   return;
        // }
      
        // // Regular expression for up to two decimal places
        // const regex = /^-?\d+(\.\d{0,2})?$/;
      
        // // Check if the value matches the regex pattern (up to two decimal places)
        // if (regex.test(value)) {
        //   setStopAngle(value); // Update state with valid value
        // }
      };
      
    const handleElevationChange = (index, value) => {
        const formattedValue = parseFloat(value).toFixed(2); // Format to 2 decimal places
        const newAngles = [...elevationAngles];
    
        if (value < -2.00 || value > 182.00) {
            showWarning('Elevation angle must be between -2.00° and 182.00°.');
            return;
        }
    
        newAngles[index] = value <= 182.00 ? parseFloat(formattedValue) : ""; // Ensure value is within the limit
        setElevationAngles(newAngles);
    };
    
    const handleScanSpeedChange = (index, value) => {
        const newSpeeds = [...azimuthScanSpeed];
        if (value < 0 || value > 6) {
            showWarning('Azimuth Scan Speed must be between 0 and 6');
            return;
        }
        newSpeeds[index] = parseFloat(parseFloat(value).toFixed(2));; // Update azimuth scan speed for each elevation
        setAzimuthScanSpeed(newSpeeds);
    };

    const handleNumElevationChange = (event) => {
        const num = parseInt(event.target.value, 10);
        if (isNaN(num) || num < 0 || num > 60) {
            showWarning('Number of elevations must be between 0 and 60.');
            setNumElevation(num < 0 || isNaN(num) ? "" : 60); // Clamp the value within range
        } else {
            setNumElevation(num);
            setElevationAngles(Array(num).fill("")); // Initialize elevation angles to 0
            setAzimuthScanSpeed(Array(num).fill("")); // Initialize scan speeds to 0
        }
    };

    const handleSubmit = (event) => {
        if (event) event.preventDefault(); 

        let errors = [];


        
        if (azimuthStartAngle === "" || azimuthStartAngle < 0 || azimuthStartAngle > 360) {
            errors.push("Start Angle is required and must be between 0° and 360°.");
        }
    
       
        if (!noOfElevations || noOfElevations < 1 || noOfElevations > 60) {
            errors.push("Number of elevations must be between 1 and 60.");
        }
    
        if (elevationAngles.some(angle => angle === "" || angle < -2.00 || angle > 182.00)) {
            errors.push("All elevation angles must be between -2.00° and 182.00°.");
        }
    
        if (azimuthScanSpeed.some(speed => speed === "" || speed < 0 || speed > 25.5)) {
            errors.push("All azimuth scan speeds must be between 0 and 25.5.");
        }
    
        if (errors.length > 0) {
            showWarning("Please enter all values"); 
            return;
        }

        const formData = {
            scanType:"az",
            azimuthStartAngle,
            azimuthEndAngle,
            buzzerBypass: buzzerBypassChecked,
            backTracking: backTrackingChecked,
            noOfElevations:noOfElevations,
            elevationAngles: elevationAngles,
            azimuthScanSpeeds: azimuthScanSpeed,
            
        };


        socket.emit("volumeAzScan",formData);
        console.log(`Sending Volume/Az Form Data to servo ${formData}`);
        
        //onSubmit(formData); // Send data to parent (Desktop)p)
    };
    const handleWarningClose = () => {
        setWarningOpen(false);
    };

    return (
        <Box
            sx={{
                backgroundColor: '#f7f7eb',
                color: '#fff',
                padding: 4,
                borderRadius: 2,
                maxWidth: 600,
                margin: '0 auto',
                boxShadow: '0 4px 10px rgba(0, 0, 0, 0.5)',
            }}
        >
            <Typography variant="h5" gutterBottom>
                {/* Azimuth Scan */}
            </Typography>

            {/* Start Angle Slider */}
            <Box
    sx={{
        display: 'flex',
        justifyContent: 'space-between',
        gap: 2, // Adds spacing between the text boxes
        marginBottom: 3,
    }}
>
    {/* Azimuth Start Angle Input */}
    <Box sx={{ flex: 1 }}>
                    <Tooltip title="Set the starting angle for the scan" arrow>
                        <Typography variant="h5" gutterBottom color= "black" fontWeight='bold'fontFamily= "'Times New Roman', serif">
                            Azimuth Start Angle:
                        </Typography>
                    </Tooltip>
                    <TextField
                        type="number"
                        value={azimuthStartAngle}
                        onChange={handleStartAngleChange}
                        fullWidth
                        inputProps={{
                            min: 0,
                            max: 360,
                        }}
                        
                        sx={{
                            input: { color: 'black', fontWeight:"bold", fontFamily: "'Times New Roman', serif" },
                            '& .MuiOutlinedInput-root': {
                                '& fieldset': {
                                    borderColor: '#00bcd4',
                                },
                                '&:hover fieldset': {
                                    borderColor: '#00bcd4',
                                },
                            },
                        }}
                    />
                    <Typography variant="body2" sx={{ textAlign: 'right',color: "black" , fontWeight:'bold',fontFamily: "'Times New Roman', serif"}}>
                        Range: 0° - 360°
                    </Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                    <Tooltip title="Set the stopping angle for the scan" arrow>
                        <Typography variant="h5" gutterBottom color= "black" fontWeight='bold'fontFamily= "'Times New Roman', serif" >
                            Azimuth Stop Angle:
                        </Typography>
                    </Tooltip>
                    <TextField
                        type="number"
                        value={azimuthEndAngle}
                        onChange={handleStopAngleChange}
                        fullWidth
                        inputProps={{
                            min: 0,
                            max: 360,
                        }}
                        sx={{
                            input: { color: 'black', fontWeight:"bold" , fontFamily: "'Times New Roman', serif" },
                            '& .MuiOutlinedInput-root': {
                                '& fieldset': {
                                    borderColor: '#00bcd4',
                                },
                                '&:hover fieldset': {
                                    borderColor: '#00bcd4',
                                },
                            },
                        }}
                    />
                    <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:'bold' ,fontFamily: "'Times New Roman', serif"  }}>
                        Range: 0° - 360°
                    </Typography>
                </Box>
</Box>


            

            

            {/* Buzzer By-pass and Back Tracking Buttons */}
            <Box sx={{ marginBottom: 3, display: 'flex', justifyContent: 'space-between', gap: 2 }}>
                <Button
                    variant={buzzerBypassChecked ? 'contained' : 'outlined'}
                    onClick={() => setBuzzerBypassChecked(!buzzerBypassChecked)}
                    sx={{
                        backgroundColor: buzzerBypassChecked ? '#00bcd4' : 'transparent',
                        color: buzzerBypassChecked ? '#fff' : '#00bcd4',
                        '&:hover': {
                            backgroundColor: buzzerBypassChecked ? '#0097a7' : '#00bcd4',
                            color: '#fff',
                        },
                        flex: 1,
                        display: "block", // Ensures the content wraps
                        minWidth: "200px"
                        ,fontFamily: "'Times New Roman', serif"                   }}
                >Buzzer By-pass:
                              <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
                    
                    {buzzerBypassChecked ? ' Enabled' : ' Disabled'}
                        </Typography>
              
                </Button>
                <Button
                    variant={backTrackingChecked ? 'contained' : 'outlined'}
                    onClick={() => setBackTrackingChecked(!backTrackingChecked)}
                    sx={{
                        backgroundColor: backTrackingChecked ? '#00bcd4' : 'transparent',
                        color: backTrackingChecked ? '#fff' : '#00bcd4',
                        '&:hover': {
                            backgroundColor: backTrackingChecked ? '#0097a7' : '#00bcd4',
                            color: '#fff',
                        },
                        flex: 1
                        ,fontFamily: "'Times New Roman', serif",
                        display: "block", // Ensures the content wraps
                        minWidth: "200px"                    }}
                        
                >Back Tracking:
                              <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
                    
                    {backTrackingChecked ? ' Enabled' : 'Disabled'}
                              </Typography>
                    
                </Button>
            </Box>

                        {/* Number of Elevations Input */}

            <Box sx={{ marginBottom: 3 }}>
                <Tooltip title="Enter the number of elevation angles" arrow>
                    <Typography variant="h5" gutterBottom color= "black" fontWeight='bold' fontFamily= "'Times New Roman', serif">
                        Number of Elevations:
                    </Typography>
                </Tooltip>
                <TextField
                    type="number"
                    value={noOfElevations}
                    onChange={handleNumElevationChange}
                    fullWidth
                    inputProps={{
                        min: 0,
                        max: 60, // Limit the number of elevation angles
                    }}
                    sx={{
                        input: { color: 'black', fontWeight:"bold" , fontFamily: "'Times New Roman', serif" },
                        '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                                borderColor: '#00bcd4',
                            },
                            '&:hover fieldset': {
                                borderColor: '#00bcd4',
                            },
                        },
                    }}
                />
                 <Typography variant="body2" sx={{ textAlign: 'right',color: "black",fontWeight:'bold',fontFamily: "'Times New Roman', serif" }}>
                        Range: 1 - 60
                    </Typography>
            </Box>
            {/* Elevation Angles and Azimuth Scan Speeds Inputs */}
            {Array.from({ length: noOfElevations }).map((_, index) => (
    <Box key={index} sx={{ marginBottom: 3, display: 'flex', justifyContent: 'space-between' }}>
        {/* Elevation Angle Input */}
        <Box sx={{ width: '48%' }}>
            <Tooltip title={`Set elevation angle ${index + 1}`} arrow>
                <Typography variant="body1" gutterBottom fontFamily= "'Times New Roman', serif"fontWeight="bold">
                    Elevation Angle {index + 1}: 
                </Typography>
            </Tooltip>
            <TextField
                value={elevationAngles[index]}
                onChange={(event) => handleElevationChange(index, event.target.value)}
                type="number"
                fullWidth
                inputProps={{
                    min: -2.00,
                    max: 182.00,
                }}
                sx={{
                    input: { color: 'black', fontWeight:"bold", fontFamily: "'Times New Roman', serif"  },
                    '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                            borderColor: '#00bcd4',
                        },
                        '&:hover fieldset': {
                            borderColor: '#00bcd4',
                        },
                    },
                }}
            />
           
        </Box>

        {/* Azimuth Scan Speed Input */}
        <Box sx={{ width: '48%' }}>
            <Tooltip title={`Set azimuth scan speed for elevation ${index + 1}`} arrow>
                <Typography variant="body1" gutterBottom fontFamily= "'Times New Roman', serif" fontWeight="bold">
                    Azimuth Scan Speed {index + 1}: 
                </Typography>
            </Tooltip>
            <TextField
                value={azimuthScanSpeed[index]}
                onChange={(event) => handleScanSpeedChange(index, event.target.value)}
                type="number"
                fullWidth
                inputProps={{
                    min: 0,
                    max: 10,
                }}
                sx={{
                    input: { color: 'black', fontWeight:"bold", fontFamily: "'Times New Roman', serif"  },
                    '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                            borderColor: '#00bcd4',
                        },
                        '&:hover fieldset': {
                            borderColor: '#00bcd4',
                        },
                    },
                }}
            />
           
        </Box>
    </Box>
))}


            {/* Submit Button */}
             <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, marginTop: 2 }}>
                <Button
                    variant="contained"
                    onClick={handleSubmit}
                    sx={{
                        backgroundColor: '#00bcd4',
                        '&:hover': {
                            backgroundColor: '#0097a7',
                        },
                        flex: 1, // Adjusts width proportionally
                        fontFamily: "'Times New Roman', serif" 

                    }}
                >
                    OK
                </Button>
                <Button
                    variant="contained"
                    onClick={handleSubmit}
                    sx={{
                        backgroundColor: '#00bcd4',
                        '&:hover': {
                            backgroundColor: '#0097a7',
                        },
                        flex: 1, // Adjusts width proportionally
                        fontFamily: "'Times New Roman', serif" 

                    }}
                >
                    Send
                </Button>
            </Box>
            

            {/* Snackbar for Acknowledgment */}
            <Snackbar
    open={warningOpen}
    autoHideDuration={6000}
    onClose={handleWarningClose}
    anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
    TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
>
    <Alert
        onClose={handleWarningClose}
        severity="warning"
        sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
        }}
        icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
    >
        {warningMessage}
    </Alert>
</Snackbar>
        </Box>
    );
};

export default AzimuthScanForm;
