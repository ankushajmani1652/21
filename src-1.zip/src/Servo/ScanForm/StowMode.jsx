import React, { useState } from "react";
import {
  Button,
  Box,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import Slide from '@mui/material/Slide';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const StowMode = ({ onSubmit, ackMessage, ackOpen, onAckClose,socket }) => {
  const [autoStowModeChecked, setAutoStowModeChecked] = useState(false);
  const [manualStowModeChecked, setManualStowModeChecked] = useState(false);
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const showWarning = (message) => {
    setWarningOpen(false); // Close it first
    setTimeout(() => {
      setWarningMessage(message);
      setWarningOpen(true); // Re-open after closing
    }, 100); // Small delay ensures state updates properly
  };

  const handleSubmit = () => {
    if (!autoStowModeChecked && !manualStowModeChecked) {
      showWarning("Please select at least one mode before proceeding.");
      return;
    }
    
    let mode;

    
    if(autoStowModeChecked){
      mode='auto'
    } else{
      mode='manual'
    }

    // const formData = {
    //   autoStowMode: autoStowModeChecked,
    //   manualStowMode: manualStowModeChecked,

    // };

    const formData={
      mode
    }

    socket.emit("zenith/stowScan",(formData));
    //onSubmit(formData); // Send data to parent
  };

  const handleWarningClose = () => {
    setWarningOpen(false);
  };

  const handleAutoStowToggle = () => {
    setAutoStowModeChecked(!autoStowModeChecked);
    if (!autoStowModeChecked) {
      setManualStowModeChecked(false); // Disable Manual Stow Mode
    }
  };

  const handleManualStowToggle = () => {
    setManualStowModeChecked(!manualStowModeChecked);
    if (!manualStowModeChecked) {
      setAutoStowModeChecked(false); // Disable Auto Stow Mode
    }
  };
  
  
  return (
    <Box
      sx={{
        backgroundColor: "#f7f7eb",
        color: "black",
        padding: 4,
        borderRadius: 2,
        maxWidth: 600,
        margin: "0 auto",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.5)",
      }}
    >
      <Typography variant="h5" gutterBottom fontWeight="bold" fontFamily= "'Times New Roman', serif">
        Stow Mode
      </Typography>

      {/* Auto Stow and Manual Stow Buttons */}
      <Box
        sx={{
          marginBottom: 3,
          display: "flex",
          justifyContent: "space-between",
          gap: 2
        }}
      >
        <Button
          variant={autoStowModeChecked ? "contained" : "outlined"}
          onClick={handleAutoStowToggle} // Toggling Auto Stow Mode
          
          sx={{
            backgroundColor: autoStowModeChecked ? "#00bcd4" : "transparent",
            color: autoStowModeChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: autoStowModeChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"          }}
        >Auto Stow Mode:
                  <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}>
        
          {autoStowModeChecked
            ? " Enabled"
            : " Disabled"}
                      </Typography>
            
        </Button>
        <Button
          variant={manualStowModeChecked ? "contained" : "outlined"}
          onClick={handleManualStowToggle} // Toggling Manual Stow Mode
          sx={{
            backgroundColor: manualStowModeChecked ? "#00bcd4" : "transparent",
            color: manualStowModeChecked ? "#fff" : "#00bcd4",
            "&:hover": {
              backgroundColor: manualStowModeChecked ? "#0097a7" : "#00bcd4",
              color: "#fff",
            },
            flex: 1,
            display: "block", // Ensures the content wraps
            minWidth: "200px"
            ,fontFamily: "'Times New Roman', serif"          }}
        >Manual Stow Mode:
                    <Typography variant="h5" fontWeight="bold" sx={{ textAlign: "center", marginTop: 1,fontFamily: "'Times New Roman', serif" }}>
          
          {manualStowModeChecked
            ? " Enabled"
            : "Disabled"}
                      </Typography>
            
        </Button>
      </Box>

      {/* Submit Button */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, marginTop: 2 }}>
                            <Button
                                variant="contained"
                                onClick={handleSubmit}
                                sx={{
                                    backgroundColor: '#00bcd4',
                                    '&:hover': {
                                        backgroundColor: '#0097a7',
                                    },
                                    flex: 1 // Adjusts width proportionally
                                ,fontFamily: "'Times New Roman', serif"
                                  }}
                            >
                                OK
                            </Button>
                            <Button
                                variant="contained"
                                onClick={handleSubmit}
                                sx={{
                                    backgroundColor: '#00bcd4',
                                    '&:hover': {
                                        backgroundColor: '#0097a7',
                                    },
                                    flex: 1 // Adjusts width proportionally
                                ,fontFamily: "'Times New Roman', serif"
                                  }}
                            >
                                Send
                            </Button>
                        </Box>
                        
      {/* Snackbar for Warnings */}
      <Snackbar
    open={warningOpen}
    autoHideDuration={6000}
    onClose={handleWarningClose}
    anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Center it at the top
    TransitionComponent={(props) => <Slide {...props} direction="down" />} // Slide down animation
>
    <Alert
        onClose={handleWarningClose}
        severity="warning"
        sx={{
            width: '100%',
            backgroundColor: '#ffcc00', // Vibrant yellow for visibility
            color: '#1a1a1a', // Dark text for better contrast
            fontWeight: 'bold',
            fontSize: '1.2rem', // Larger font size
            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)', // Add shadow for depth
            border: '2px solid #ff9800', // Border for emphasis
        }}
        icon={<WarningAmberIcon fontSize="large" sx={{ marginRight: 1, color: '#ff9800' }} />} // Custom warning icon
    >
        {warningMessage}
    </Alert>
</Snackbar>
    </Box>
  );
};

export default StowMode;
