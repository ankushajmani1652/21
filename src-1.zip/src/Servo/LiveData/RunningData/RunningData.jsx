

import React, { useState, useEffect } from "react";
import {
  Box,
  Grid,
  Button,
  Card,
  CardContent,
  Typography,
  Tabs,
  Tab,
} from "@mui/material";
import RotatingMotor from "../../../subsystem/RotatingMoter/RotatingMotor";
import UpDown from "../../../subsystem/RotatingMoter/UpDown";
import { useSocket } from "../../../SocketContext";
import { useRunningDataListener, useRunningDataStore } from "../../../store";


// Dashboard Component
const RunningData = () => {
  const [activeScan, setActiveScan] = useState("azimuth"); // Manage selected scan type
  const [angle, setAngle] = useState(0);
  const [angleError, setAngleError] = useState(5);
  const [motorRunning, setMotorRunning] = useState(false);
  const [motorDirectionCW, setMotorDirectionCW] = useState(true);
  const [motorDirectionCCW, setMotorDirectionCCW] = useState(false);
  const [encoderData, setEncoderStatus] = useState(false);
  const [driveErrorStop, setDriveErrorStop] = useState(true);
  const [drivePowerStatus, setDrivePowerStatus] = useState(false);
  const [driveTemperature, setDriveTemperature] = useState(25); // Initial temperature for Drive
  const [heatSinkTemperature, setHeatSinkTemperature] = useState(45); // Initial temperature for Heat Sink

 


  const runningData=useRunningDataStore((state)=>state.runningData);

  useRunningDataListener();


  const [responseValues, setResponseValues] = useState({
    systemData: {
      time: null,
      emmStatus: {
        radomeEStopSwitch1: false,
        radomeDoorSwitch: false,
        radomeEStopSwitch2: false,
        servoPanelEStop: false,
        azDriveError: false,
        elDriveError: false,
        systemReady: false,
        systemEnabled: false,
      },
      operationParameters: {
        radomeEStopSwitch1: false,
        radomeDoorSwitch: false,
        radomeEStopSwitch2: false,
        servoPanelEStop: false,
        azDriveError: false,
        elDriveError: false,
        systemReady: false,
        systesymEnabled: false,
      },
      syncSignalsStatus: false,
      operationMode: 0,
      scanType: 0,
      runningElevationScanNo: 0,
      runningAzimuthScanNo: 0,
      dataReady: false,
      azimuthDwellSignalLastCycleCount: 0,
      azimuthDwellSignalRunningCycleCount: 0,
      elevationDwellSignalLastCycleCount: 0,
      elevationDwellSignalRunningCycleCount: 0,
      servoPanelIncomePowerSupplyStatus: false,
    },
    azimuth: {
      encoderData: 0,
      angleError: 0,
      runningSpeed: 0,
      commandSpeed: 0,
      speedError: 0,
      runningCurrent: 0,
      busVoltage: 0,
      motorRunning: false,
      motorDirection: false,
      brakeCurrent: 0,
      driveAuxPower: 0,
      driveTemperature: 0,
      heatSinkTemperature: 0,
      driveErrorCount: 0,
      driveErrorID1: 0,
      driveErrorID2: 0,
      driveErrorID3: 0,
      rcToServoCommunicationFault: false,
      testStopReason: 0,
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        azimuthPowerOn: false,
        azimuthSTO: false,
      },
    },
    elevation: {
      encoderData: 0,
      angleError: 0,
      runningSpeed: 0,
      commandSpeed: 0,
      speedError: 0,
      runningCurrent: 0,
      busVoltage: 0,
      motorRunning: false,
      motorDirection: false,
      brakeCurrent: 0,
      driveAuxPower: 0,
      driveTemperature: 0,
      heatSinkTemperature: 0,
      driveErrorCount: 0,
      driveErrorID1: 0,
      driveErrorID2: 0,
      driveErrorID3: 0,
      limitsStatus: {
        elevationUpDirSoftLimit: false,
        elevationUpDirPreLimit: false,
        elevationUpDirFinalLimit: false,
        elevationDnDirSoftLimit: false,
        elevationDnDirPreLimit: false,
        elevationDnDirFinalLimit: false,
      },
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        drivePowerRelay: false,
        elevationSTO: false,
      },
      operationModeState: 0,
      scanCompletionFlags: 0,
    },
  });


  const socket = useSocket();
  const getButtonColor = (value) => {


    if (value == null) {
      return "#ebb5b5"; // Default color
    }
    return value === true ? "#b8ebb5" : "#ebb5b5";
  };


  const handleChange = (event, newValue) => {
    setActiveScan(newValue);
  };

  // Function to generate random data for the chart
 

  const testRunningStatus = {
    motorRunning: responseValues.azimuth?.runningStatus?.motorRunning,
    motorDirectionCW: responseValues.azimuth?.runningStatus?.motorDirectionCW, // Should rotate Counter-Clockwise
  };


  const [azimuthParameters, setParameterValues] = useState([
    {
      title: "Azimuth Running Current",
      values: [responseValues?.azimuth?.runningCurrent], // Updated with commandedSpeed from responseValues.azimuth
      unit: "A",
    },
    {
      title: "Azimuth Bus Voltage",
      values: [null],
      unit: "V",
    },

    {
      title: "Azimuth Auxiliary Power",
      values: [null],
      unit: "A",
    },
    { title: "Azimuth Angle Error", values: [null], unit: "°" },
    { title: "Azimuth Encoder Data", values: [null], unit: "counts" },
  ]);


  const [elevationParameters, setElevationParameters] = useState([
    {
      title: "Elevation Running Current",
      values: responseValues?.elevation?.runningCurrent, // Updated with commandedSpeed from responseValues.azimuth
      unit: "A",
    },
    {
      title: "Elevation Bus Voltage",
      values: [null],
      unit: "V",
    },

    {
      title: "Elevation Auxiliary Power",
      values: [null],
      unit: "A",
    },
    { title: "Elevation Angle Error", values: [null], unit: "°" },
    { title: "Elevation Encoder Data", values: [null], unit: "counts" },
  ]);

  // Determine the parameter set based on the active scan type
  const parameterValues =
    activeScan === "azimuth" ? azimuthParameters : elevationParameters;



  // useEffect(() => {
  //   socket.on("runningData", (data) => {
  //     console.log(`Received Running Data: ${JSON.stringify(data)}`);

  //     setResponseValues(data);

  //   })
  // }, [socket]);



  useEffect(()=>{
    if(runningData){
      setResponseValues(runningData);
    }
  },[runningData])

  useEffect(() => {
    const updateParameterValues = (scanType) => {
      let updatedParameters = [];
      if (scanType === "azimuth") {
        updatedParameters = azimuthParameters.map((param) => {
          if (param.title === "Azimuth Running Current") {
            return { ...param, values: [responseValues.azimuth.runningCurrent] };
          } else if (param.title === "Azimuth Bus Voltage") {
            return { ...param, values: [responseValues.azimuth.busVoltage] };
          } else if (param.title === "Azimuth Auxiliary Power") {
            return { ...param, values: [responseValues.azimuth.driveAuxPower] };
          } else if (param.title === "Azimuth Angle Error") {
            return { ...param, values: [responseValues.azimuth.angleError] };
          } else if (param.title === "Azimuth Encoder Data") {
            return { ...param, values: [responseValues.azimuth.encoderData] };
          }
          return param;
        });
      } else if (scanType === "elevation") {
        updatedParameters = elevationParameters.map((param) => {
          if (param.title === "Elevation Running Current") {
            return { ...param, values: [responseValues.elevation.runningSpeed] };
          } else if (param.title === "Elevation Bus Voltage") {
            return { ...param, values: [responseValues.elevation.busVoltage] };
          } else if (param.title === "Elevation Auxiliary Power") {
            return { ...param, values: [responseValues.elevation.driveAuxPower] };
          } else if (param.title === "Elevation Angle Error") {
            return { ...param, values: [responseValues.elevation.angleError] };
          } else if (param.title === "Elevation Encoder Data") {
            return { ...param, values: [responseValues.elevation.encoderData] };
          }
          return param;
        });

      }
      setParameterValues(updatedParameters);
      setElevationParameters(updatedParameters);
    };

    updateParameterValues(activeScan); // Update parameters based on active scan

  }, [responseValues, activeScan]);

  return (
    <Box sx={{ padding: 2, backgroundColor: "" }}>
      {/* Tabs to switch between scans */}
      <Tabs
        value={activeScan}
        onChange={handleChange}
        centered
        sx={{
          marginBottom: 2,
          ".MuiTab-root": {
            fontWeight: "bold",
            fontFamily: "'Times New Roman', serif",
            color: "#1976d2",
            "&:hover": {
              color: "black",
            },
          },
          ".MuiTabs-indicator": {
            backgroundColor: "#1976d2",
          },
          
          // fontFamily: "'Times New Roman', serif" ,

        }}
      >
        <Tab label="Azimuth Datalog" value="azimuth" />
        <Tab label="Elevation Datalog" value="elevation" />
      </Tabs>

      {/* Top Section: Summary Boxes */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        {parameterValues.map((param, index) => (
          <Grid item xs={6} sm={2.4} key={param.title}>
            <Card
              sx={{
                boxShadow: 2,
                borderRadius: 2,
                padding: 1,
                background: `linear-gradient(45deg, ${index % 2 === 0 ? "#42a5f5" : "#66bb6a"
                  }, #81c784)`,
                height: "100%",
              }}
            >
              <CardContent>
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: "bold", color: "white",fontFamily: "'Times New Roman', serif"  }}
                  gutterBottom
                >
                  {param.title}
                </Typography>
                <Typography
                  variant="h3"
                  sx={{
                    fontWeight: "bold",
                    color: "#ffffff",
                    fontFamily: "'Times New Roman', serif"
                  }}
                >
                  {param.values[0] !== null ? param.values.join(" / ") : "..."}{" "}
                  {param.unit}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Bottom Section: Graphs */}
      <Grid container spacing={2}>
        {/* Speed Error Bar Chart */}
        <Grid item xs={12} sm={6} md={3}>
          <Card
            sx={{
              boxShadow: 2,
              borderRadius: 2,
              height: "90%",
              marginTop: "5%",
            }}
          >
            <CardContent>
              <Typography
                variant="subtitle1"
                sx={{ fontWeight: "bold" }}
                gutterBottom
                fontFamily= "'Times New Roman', serif" 
              >
                {activeScan === "azimuth"
                  ? "Azimuth Axis Running Status"
                  : "Elevation Axis Running Status"}
              </Typography>
              {/* Display Speed Data */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  padding: 3.5,
                  borderRadius: 2,
                  backgroundColor: "#f5f5f5",
                  boxShadow: 2,
                  width: "100%",
                  maxWidth: "500px", // Optional: To control the width of the container
                }}
              >
                {/* Commanded Speed */}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 2, // Adds space between items
                    padding: 1,
                    backgroundColor: "#ff7043", // orange
                    borderRadius: 1,
                    boxShadow: 1,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white"  ,fontFamily: "'Times New Roman', serif" ,
                    }}
                  >
                    Commanded Speed
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white",fontFamily: "'Times New Roman', serif" ,}}
                  >
                    <span style={{ fontSize: "1.25rem" }}>
                      {activeScan === "azimuth"
                        ? `${responseValues.azimuth.commandSpeed} rpm`
                        : `${responseValues.elevation.commandSpeed} rpm`}                  </span>
                  </Typography>
                </Box>

                {/* Running Speed */}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 2,
                    padding: 1,
                    backgroundColor: "#42a5f5", // blue
                    borderRadius: 1,
                    boxShadow: 1,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white" ,fontFamily: "'Times New Roman', serif" ,}}
                  >
                    Running Speed
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white",fontFamily: "'Times New Roman', serif" , }}
                  >
                    <span style={{ fontSize: "1.25rem" }}>
                      {activeScan === "azimuth"
                        ? `${responseValues.azimuth.runningSpeed} rpm`
                        : `${responseValues.elevation.runningSpeed} rpm`}                     </span>
                  </Typography>
                </Box>

                {/* Speed Error */}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: 1,
                    backgroundColor: "#66bb6a", // green
                    borderRadius: 1,
                    boxShadow: 1,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white" ,fontFamily: "'Times New Roman', serif" ,}}
                  >
                    Speed Error
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{ fontWeight: "bold", color: "white" ,fontFamily: "'Times New Roman', serif" ,}}
                  >
                    <span style={{ fontSize: "1.25rem" }}>
                      {activeScan === "azimuth"
                        ? `${responseValues.azimuth.speedError} rpm`
                        : `${responseValues.elevation.speedError} rpm`}                     </span>
                  </Typography>
                </Box>
              </Box>

              {/* Optionally, you can add charts like SpeedErrorBarChart here */}
              {/* <SpeedErrorBarChart /> */}
            </CardContent>
          </Card>
        </Grid>

        {/* Needle Angle Indicator */}
        <Grid item xs={12} sm={6} md={3}>
          <Card
            sx={{
              boxShadow: 2,
              borderRadius: 2,
              height: "90%",
              marginTop: "5%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-around",
            }}
          >
            <Typography
              variant="subtitle1"
              sx={{ fontWeight: "bold" }}
              gutterBottom
              marginTop="1.8%"
              marginLeft="2.5%"
              fontFamily= "'Times New Roman', serif" 

            >
              {activeScan === "azimuth"
                ? "Azimuth Angle Analysis"
                : "Elevation Angle Analysis"}
            </Typography>
            <CardContent>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: {
                    xs: "column",
                    md: "row",
                    marginBottom: "14%",
                  },
                  justifyContent: "space-around",
                  alignItems: "center",
                  gap: { xs: 2, md: 0 },
                }}
              >
                {/* Angle Error Dial */}
                <Box
                  sx={{
                    width: "150px",
                    height: "150px",
                    borderRadius: "50%",
                    background: `radial-gradient(circle at center, white 50%, red 100%)`,
                    position: "relative",
                    boxShadow:
                      "inset 0 5px 15px rgba(255, 255, 255, 0.2), 0 10px 20px rgba(0, 0, 0, 0.3)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {/* Needle */}
                  <Box
                    sx={{
                      width: "2px",
                      height: "60px",
                      backgroundColor: "red",
                      position: "absolute",
                      top: "20px",
                      transform: `rotate(${angleError}deg)`, // Dynamic angle error
                      transformOrigin: "50% 100%", // Adjust the rotation point to the bottom of the needle
                      boxShadow: "0px 0px 10px rgba(255, 0, 0, 0.5)",
                    }}
                  />
                  {/* Center Pin */}
                  <Box
                    sx={{
                      width: "12px",
                      height: "12px",
                      borderRadius: "50%",
                      backgroundColor: "lightgrey",
                      border: "2px solid red",
                      boxShadow: "0 5px 10px rgba(0, 0, 0, 0.5)",
                      position: "absolute",
                    }}
                  />

                  <Typography
                    sx={{
                      position: "absolute",
                      bottom: "-30px",
                      color: "red",
                      fontWeight: "600",
                      fontFamily: "'Times New Roman', serif"
                    }}
                    
                  >
                    {activeScan === "azimuth"
                      ? `${responseValues.azimuth.angleError}°`
                      : `${responseValues.elevation.angleError}°`}
                  </Typography>

                  <Typography
                    sx={{
                      position: "absolute",
                      bottom: "-50px", // Adjust the positioning as needed
                      color: "red",
                      fontWeight: "bold",
                      fontSize: "14px",
                      fontFamily: "'Times New Roman', serif" 

                    }}
                    
                  >
                    Angle Error
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card
            sx={{
              boxShadow: 2,
              borderRadius: 2,
              height: "90%",
              marginTop: "5%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-around",
            }}
          >
            <CardContent>
              <Typography
                variant="subtitle1"
                sx={{ fontWeight: "bold" }}
                gutterBottom
                fontFamily= "'Times New Roman', serif" 

              >
                {activeScan === "azimuth"
                  ? "Azimuth Motor Running & Direction Status "
                  : "Elevation Motor Running & Direction Status"}
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: {
                    xs: "column",
                    md: "row",
                    marginBottom: "14%",
                  },
                  justifyContent: "space-around",
                  alignItems: "center",
                  gap: { xs: 2, md: 0 },
                }}
              >
                {activeScan === "azimuth" ? (
                  <RotatingMotor runningStatus={testRunningStatus} />
                ) : (
                  <UpDown motorRunning={responseValues.elevation.motorRunning} motorDirection={responseValues.elevation.motorDirection} />
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* <Grid item xs={12} sm={6} md={3}>
          {activeScan === "azimuth" ? <RotatingMotor /> : <UpDown />}
        </Grid> */}

        <Grid item xs={12} sm={6} md={3}>
          <Card
            sx={{
              boxShadow: 2,
              borderRadius: 2,
              height: "90%",
              marginTop: "5%",
              display: "flex",
              justifyContent: "space-between",
              padding: 2,
            }}
          >
            <Typography
              variant="subtitle1"
              sx={{ fontWeight: "bold", textAlign: "center", marginBottom: 2 }}
              gutterBottom
            ></Typography>

            {/* Thermometer Containers */}
            <Grid container spacing={2} sx={{ width: "100%" }}>
              {/* Drive Temperature Thermometer (Left) */}
              <Grid
                item
                xs={6}
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: "bold" }}
                  gutterBottom
                  fontFamily= "'Times New Roman', serif" 

                >
                  Drive Temp{" "}
                </Typography>

                {/* Thermometer Shape */}
                <Box
                  sx={{
                    width: 50,
                    height: 180,
                    background:
                      "linear-gradient(to top, #f44336 0%, #ffeb3b 100%)", // Red to Yellow Gradient
                    borderRadius: "30px",
                    position: "relative",
                    display: "flex",
                    flexDirection: "column-reverse",
                    justifyContent: "flex-end",
                  }}
                >
                  {/* Temperature Level */}
                  <Box
                    sx={{
                      width: "100%",
                      height: `${65}%`, // Example value for 65°C
                      backgroundColor: "",
                      borderRadius: "30px 30px 0 0",
                    }}
                  />
                </Box>

                <Typography
                  sx={{ fontWeight: "bold", color: "green", marginTop: 1 ,fontFamily: "'Times New Roman', serif" }}
                >
                  {activeScan === "azimuth"
                    ? `${responseValues.azimuth.driveTemperature}°C`
                    : `${responseValues.elevation.driveTemperature}°C`}
                </Typography>
              </Grid>

              {/* Heat Sink Temperature Thermometer (Right) */}
              <Grid
                item
                xs={6}
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: "bold" }}
                  gutterBottom
                  fontFamily= "'Times New Roman', serif" 

                >
                  Heat Sink Temp{" "}
                </Typography>

                {/* Thermometer Shape */}
                <Box
                  sx={{
                    width: 50,
                    height: 180,
                    background:
                      "linear-gradient(to top, #4caf50 0%, #ffeb3b 100%)", // Green to Yellow Gradient
                    borderRadius: "30px",
                    position: "relative",
                    display: "flex",
                    flexDirection: "column-reverse",
                    justifyContent: "flex-end",
                  }}
                >
                  {/* Temperature Level */}
                  <Box
                    sx={{
                      width: "100%",
                      height: `${55}%`, // Example value for 55°C
                      backgroundColor: "",
                      borderRadius: "30px 30px 0 0",
                    }}
                  />
                </Box>

                <Typography
                  sx={{ fontWeight: "bold", color: "green", marginTop: 1 ,fontFamily: "'Times New Roman', serif"}}
                >
                  {activeScan === "azimuth"
                    ? `${responseValues.azimuth.heatSinkTemperature}°C`
                    : `${responseValues.elevation.heatSinkTemperature}°C`}
                </Typography>
              </Grid>
            </Grid>
          </Card>
        </Grid>

        {/* Random Axis running status Example */}

        <Grid container spacing={2}>
          {/* Add your components for the third row here */}

          {/* Another component in third row */}

          {/* Another example with different chart */}
          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 2,
                borderRadius: 2,
                height: "90%",
                marginTop: "0.5%",
                padding: 2,
                marginLeft: 2,
              }}
            >
              <Typography
                variant="subtitle1"
                sx={{ fontWeight: "bold", marginBottom: 2 }}
                gutterBottom
              ></Typography>
              <CardContent>
                <Grid container spacing={2}>
                  {/* Left Section */}
                  <Grid item xs={6}>
                    <Typography
                      variant="subtitle1"
                      sx={{ fontWeight: "bold" }}
                      gutterBottom
                      marginTop="-15%"
                      fontFamily= "'Times New Roman', serif" 

                    >
                      {activeScan === "azimuth"
                        ? "Azimuth Axis Digital Input Status"
                        : "Elevation Axis Digital Input Status "}
                    </Typography>
                    <Grid item xs={4} display="flex" justifyContent="center">
                      <Button
                        variant="contained"
                        sx={{
                          backgroundColor: getButtonColor(
                            activeScan === "azimuth"
                              ? responseValues.azimuth?.digitalInputs?.controlInhibit
                              : responseValues.elevation?.digitalInputs?.controlInhibit
                          ),
                          color: "black",
                          borderRadius: "50%",
                          width: 80,
                          height: 80,
                          marginTop: 0,
                          padding: 5,
                          marginLeft: 15,
                          fontFamily: "'Times New Roman', serif",
                          fontWeight: "bold",
                        }}
                      >
                        Drive Control Inhibit
                      </Button>

                    </Grid>

                    <Grid item xs={4} display="flex" justifyContent="center">
                      <Button
                        variant="contained"
                        sx={{
                          backgroundColor: getButtonColor(
                            activeScan === "azimuth" ? (responseValues.azimuth?.digitalInputs?.driveSTO1Status)
                              : (responseValues.elevation?.digitalInputs?.driveSTO1Status)
                          ),
                          color: "black",
                          borderRadius: "50%", // Make button circular
                          width: 80, // Adjust the size of the button
                          height: 80, // Same height and width to keep it circular
                          marginTop: 5,
                          padding: 5,
                          marginLeft: 15,
                          fontFamily: "'Times New Roman', serif",
                          fontWeight: "bold",
                        }}
                      >
                        Drive STO1 Status
                      </Button>
                    </Grid>
                  </Grid>

                  {/* Right Section */}
                  <Grid item xs={6}>
                    <Typography
                      variant="subtitle1"
                      sx={{
                        fontWeight: "bold",

                        fontFamily: "'Times New Roman', serif" 
                      }}
                      gutterBottom
                      marginTop="-15%"
                      
                    >
                      {activeScan === "azimuth"
                        ? " Axis Digital Output Status"
                        : " Axis Digital Output Status "}
                    </Typography>
                    <Grid item xs={4} display="flex" justifyContent="center">
                      <Button
                        variant="contained"
                        sx={{
                          backgroundColor: getButtonColor(
                            activeScan === "azimuth"
                              ? responseValues.azimuth?.digitalOutputs?.azimuthPowerOn
                              : responseValues.elevation?.digitalOutputs?.drivePowerRelay // Assuming correct key
                          ),
                          color: "black",
                          borderRadius: "50%", // Make button circular
                          width: 80, // Adjust the size of the button
                          height: 80, // Same height and width to keep it circular
                          marginTop: 0,
                          padding: 5,
                          marginLeft: 15,
                          fontFamily: "'Times New Roman', serif",
                          fontWeight: "bold",
                        }}
                      >
                        {activeScan === "azimuth"
                          ? "Azimuth Power On"
                          : "Drive Power Contactor "}
                      </Button>

                    </Grid>
                    <Grid item xs={4} display="flex" justifyContent="center">
                      <Button
                        variant="contained"
                        sx={{
                          backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.digitalOutputs?.azimuthSTO)
                            : (responseValues.elevation?.digitalOutputs?.elevationSTO)),
                          color: "black",
                          borderRadius: "50%", // Make button circular
                          width: 80, // Adjust the size of the button
                          height: 80, // Same height and width to keep it circular
                          marginTop: 5,
                          padding: 5,
                          marginLeft: 15,
                          fontFamily: "'Times New Roman', serif",
                          fontWeight: "bold",
                        }}
                      >
                        Drive STO Enable Relay
                      </Button>
                    </Grid>{" "}
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Card
              sx={{
                boxShadow: 2,
                borderRadius: 2,
                height: "90%",
                marginTop: "0%",
              }}
            >
              <CardContent>
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: "bold" }}
                  gutterBottom
                  fontFamily= "'Times New Roman', serif" 

                >
                  {activeScan === "azimuth"
                    ? "Azimuth Axis Running Status"
                    : "Elevation Axis Running Status "}
                </Typography>

                {/* Using Grid to organize buttons in rows with 3 buttons per row */}
                <Grid container spacing={2} justifyContent="center">
                  {/* Row 1 */}
                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{
                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.motorRunning)
                          : (responseValues.elevation?.runningStatus?.motorRunning)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        marginTop: 3,
                        fontFamily: "'Times New Roman', serif",
                        fontWeight: "bold",
                      }}
                    >
                      Motor Running
                    </Button>
                  </Grid>

                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{

                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.motorDirectionCW)
                          : (responseValues.elevation?.runningStatus?.motorDirectionCW)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        marginTop: 3,
                        fontWeight: "bold",
                        fontFamily: "'Times New Roman', serif",
                      }}
                    >
                      Motor Direction CW
                    </Button>
                  </Grid>

                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{

                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.motorDirectionCCW)
                          : (responseValues.elevation?.runningStatus?.motorDirectionCCW)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        marginTop: 3,
                        fontWeight: "bold",
                        fontFamily: "'Times New Roman', serif",
                      }}
                    >
                      Motor Direction CCW
                    </Button>
                  </Grid>

                  {/* Row 2 */}
                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{

                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.encoderStatus)
                          : (responseValues.elevation?.runningStatus?.encoderStatus)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        fontFamily: "'Times New Roman', serif",
                        fontWeight: "bold",
                      }}
                    >
                      Encoder Status
                    </Button>
                  </Grid>

                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{

                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.driveErrorStop)
                          : (responseValues.elevation?.runningStatus?.driveErrorStop)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        fontFamily: "'Times New Roman', serif",
                        fontWeight: "bold",
                      }}
                    >
                      Drive Error Stop
                    </Button>
                  </Grid>

                  <Grid item xs={4} display="flex" justifyContent="center">
                    <Button
                      variant="contained"
                      sx={{

                        backgroundColor: getButtonColor(activeScan === "azimuth" ? (responseValues.azimuth?.runningStatus?.drivePowerStatus)
                          : (responseValues.elevation?.runningStatus?.drivePowerStatus)),
                        color: "black",
                        borderRadius: "50%", // Make button circular
                        width: 80, // Adjust the size of the button
                        height: 80, // Same height and width to keep it circular
                        fontFamily: "'Times New Roman', serif",
                        fontWeight: "bold",
                      }}
                    >
                      Drive Power Status
                    </Button>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            {activeScan === "azimuth" && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  {/* Azimuth data content here */}
                  <Typography variant="h6"></Typography>
                  {/* Your Azimuth-specific content can be added here */}
                </Grid>
              </Grid>
            )}

            {activeScan === "elevation" && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  {/* Elevation data content here */}

                  <Card
                    sx={{
                      boxShadow: 2,
                      borderRadius: 2,
                      height: "95%",
                      marginTop: "0%",
                    }}
                  >
                    <CardContent>
                      <Typography
                        variant="subtitle1"
                        sx={{
                          fontWeight: "bold",
                          fontFamily: "'Times New Roman', serif",
                        }}
                        gutterBottom
                      >
                        Limit Status
                      </Typography>
                      <Grid container spacing={2} justifyContent="center">
                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationUpDirSoftLimit
                              ),
                              color: "black",
                              borderRadius: "50%",
                              width: 80,
                              height: 80,
                              marginTop: 3,
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}
                          >
                            Up Dir Soft Limit
                          </Button>
                        </Grid>
                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationUpDirPreLimit
                              ),
                              color: "black",
                              borderRadius: "50%",
                              width: 80,
                              height: 80,
                              marginTop: 3,
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}

                          >
                            Up Dir Pre Limit
                          </Button>
                        </Grid>
                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationUpDirFinalLimit
                              ),

                              color: "black",
                              borderRadius: "50%",
                              width: 80,
                              height: 80,
                              marginTop: 3,
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}

                          >
                            Up Dir Final Limit
                          </Button>
                        </Grid>
                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationDnDirSoftLimit
                              ),
                              color: "black",
                              borderRadius: "50%", // Make button circular
                              width: 80, // Adjust the size of the button
                              height: 80, // Same height and width to keep it circular
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}
                          >
                            Dn Dir Soft Limit
                          </Button>
                        </Grid>

                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationDnDirPreLimit
                              ),
                              color: "black",
                              borderRadius: "50%", // Make button circular
                              width: 80, // Adjust the size of the button
                              height: 80, // Same height and width to keep it circular
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}
                          >
                            Dn Dir Pre Limit
                          </Button>
                        </Grid>

                        <Grid
                          item
                          xs={4}
                          display="flex"
                          justifyContent="center"
                        >
                          <Button
                            variant="contained"
                            sx={{
                              backgroundColor: getButtonColor(
                                responseValues.elevation?.limitsStatus?.elevationDnDirFinalLimit
                              ),
                              color: "black",
                              borderRadius: "50%", // Make button circular
                              width: 80, // Adjust the size of the button
                              height: 80, // Same height and width to keep it circular
                              fontWeight: "bold",
                              fontFamily: "'Times New Roman', serif",
                            }}

                          >
                            Dn Dir Final Limit
                          </Button>
                        </Grid>

                        {/* Additional content for elevation can go here */}
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Grid>
    </Box >
  );
};

export default RunningData;
