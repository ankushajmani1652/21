// import React, { useState, useEffect } from 'react';
// import { Box, Typography, List, ListItem, Paper, TextField } from '@mui/material';
// import './HealthStatus.css';  // Optional: add custom CSS if needed
// import { useSocket } from '../../SocketContext';

// const HealthStatus = () => {
//   // State to store data from server
//   const [systemHealthData, setSystemHealthData] = useState({});
//   const [azimuthHealthData, setAzimuthHealthData] = useState({});
//   const [elevationHealthData, setElevationHealthData] = useState({});
//   const socket=useSocket();

//   useEffect(() => {
//     // Mock data fetch for demonstration (replace with actual server call)
//     const fetchHealthData = async () => {
     
//       let payload;
//       socket.on("healthStatus",(data)=>{
//         payload=data.healthStatusPayload;


//         console.log(payload);
        
//       })
      
//       // Replace these with actual API calls
//       setSystemHealthData({
//         timeMilliseconds: "",
//         timeSeconds: "",
//         timeMinutes: "",
//         timeHours: "",
//         dateDay: "",
//         dateMonth: '',
//         dateYear: "",
//         systemEMMStatus: '',
//         systemOperationParams: '',
//         systemSyncSignalsStatus: '',
//         powerSupplyStatus: '',
//       });

//       setAzimuthHealthData({
//         auxiliaryPower: '',
//         busVoltage: '',
//         heatSinkTemperature: '',
//         brakeCurrent: '',
//         driveError: '',
//       });

//       setElevationHealthData({
//         auxiliaryPower: '',
//         busVoltage: '',
//         heatSinkTemperature: '',
//         brakeCurrent: '',
//         driveError: '',
//       });
//     };

//     fetchHealthData();
//   }, []);

//   return (
//     <Box display="flex" justifyContent="space-between" gap={2} p={2}>
//       {/* System Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           System Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Milliseconds</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeMilliseconds || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Seconds</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeSeconds || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Minutes</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeMinutes || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Hours</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeHours || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Day</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateDay || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Month</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateMonth || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Year</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateYear || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System EMM Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemEMMStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System Operation Parameters</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemOperationParams || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System Sync Signals Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemSyncSignalsStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Servo Panel Income Power Supply Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.powerSupplyStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>

//       {/* Azimuth Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           Azimuth Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Auxiliary Power</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.auxiliaryPower || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Bus Voltage</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.busVoltage || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Heat Sink Temperature</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.heatSinkTemperature || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Az_Brake_Current</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.brakeCurrent || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
          
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 1</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 2</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 3</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Running Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Digital Input</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Digital Output</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>

//       {/* Elevation Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           Elevation Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Auxiliary Power</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.auxiliaryPower || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Bus Voltage</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.busVoltage || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Heat Sink Temperature</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.heatSinkTemperature || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Brake Current</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.brakeCurrent || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
          
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 1</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 2</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 3</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Limits Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Running Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Digital Input</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Digital Output</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>
//     </Box>
//   );
// };

// export default HealthStatus;



















// import React, { useState, useEffect } from 'react';
// import { Box, Typography, List, ListItem, Paper, TextField } from '@mui/material';
// import './HealthStatus.css';  // Optional: add custom CSS if needed
// import { useSocket } from '../../SocketContext';




// const HealthStatus = () => {
  
//   const [systemHealthData, setSystemHealthData] = useState({
//     timeMilliseconds: '',
//     timeSeconds: '',
//     timeMinutes: '',
//     timeHours: '',
//     dateDay: '',
//     dateMonth: '',
//     dateYear: '',
//     systemEMMStatus: '',
//     systemOperationParams: '',
//     systemSyncSignalsStatus: '',
//     powerSupplyStatus: '',
//   });

//   const [azimuthHealthData, setAzimuthHealthData] = useState({
//     auxiliaryPower: '',
//     busVoltage: '',
//     heatSinkTemperature: '',
//     brakeCurrent: '',
//     driveError: '',
//   });

//   const [elevationHealthData, setElevationHealthData] = useState({
//     auxiliaryPower: '',
//     busVoltage: '',
//     heatSinkTemperature: '',
//     brakeCurrent: '',
//     driveError: '',
//   });

//   const socket = useSocket();

//   useEffect(() => {
//     socket.on('healthStatus', (data) => {
//       // const payload = data.healthStatusPayload;
      
      
//       const payload =data;
//       console.log('Received Health Status');
//       console.log(payload);
  
//       setSystemHealthData({
//         timeMilliseconds: payload.timeStamp.timeMilliSec || '',
//         timeSeconds: payload.timeStamp.timeSec || '',
//         timeMinutes: payload.timeStamp.timeMin || '',
//         timeHours: payload.timeStamp.timeHour || '',
//         dateDay: payload.timeStamp.dateDay || '',
//         dateMonth: payload.timeStamp.dateMonth || '',
//         dateYear: payload.timeStamp.dateYear || '',
//         systemEMMStatus: payload.systemEMMStatus || '',
//         systemOperationParams: payload.systemOperationParameters || '',
//         systemSyncSignalsStatus: payload.systemSyncSignalStatus || '',
//         powerSupplyStatus: payload.servoPanelIncomePowerSupplyStatus ? 'Operational' : 'Not Operational',
//       });
  
//       setAzimuthHealthData({
//         auxiliaryPower: payload.azimuthStatus.auxPower || '',
//         busVoltage: payload.azimuthStatus.busVoltage || '',
//         heatSinkTemperature: payload.azimuthStatus.heatSinkTemp || '',
//         brakeCurrent: payload.azimuthStatus.brakeCurrent || '',
//         driveError: payload.azimuthStatus.driveError || '',
//       });
  
//       setElevationHealthData({
//         auxiliaryPower: payload.elevationStatus.auxPower || '',
//         busVoltage: payload.elevationStatus.busVoltage || '',
//         heatSinkTemperature: payload.elevationStatus.heatSinkTemp || '',
//         brakeCurrent: payload.elevationStatus.brakeCurrent || '',
//         driveError: payload.elevationStatus.driveError || '',
//       });
//     });
  
//     // Cleanup listener when the component unmounts or the socket changes
//     return () => {
//       socket.off('healthStatus');
//     };
//   }, [socket]);
  

//   return (
//     <Box display="flex" justifyContent="space-between" gap={2} p={2}>
//       {/* System Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           System Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Milliseconds</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeMilliseconds || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Seconds</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeSeconds || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Minutes</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeMinutes || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>TIME Hours</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.timeHours || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Day</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateDay || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Month</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateMonth || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>DATE Year</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.dateYear || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System EMM Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemEMMStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System Operation Parameters</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemOperationParams || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>System Sync Signals Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.systemSyncSignalsStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Servo Panel Income Power Supply Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={systemHealthData.powerSupplyStatus || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>

//       {/* Azimuth Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           Azimuth Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Auxiliary Power</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.auxPower || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Bus Voltage</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.busVoltage || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Heat Sink Temperature</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.heatSinkTemperature || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Az_Brake_Current</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.brakeCurrent || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
          
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 1</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 2</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>AZ Drive Error ID 3</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Running Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Digital Input</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Azimuth Digital Output</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>

//       {/* Elevation Health Section */}
//       <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
//         <Typography variant="h4" gutterBottom>
//           Elevation Health
//         </Typography>
//         <List>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Auxiliary Power</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.auxPower || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Bus Voltage</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.busVoltage || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Heat Sink Temperature</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.heatSinkTemperature || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Brake Current</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={elevationHealthData.brakeCurrent || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
          
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 1</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 2</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>El Drive Error ID 3</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Limits Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Running Status</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Digital Input</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>

//           <ListItem sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <span>Elevation Digital Output</span>
//             <TextField
//               variant="outlined"
//               size="small"
//               value={azimuthHealthData.driveError || ''}
//               InputProps={{
//                 readOnly: true,
//               }}
//               sx={{ width: 100 }}
//             />
//           </ListItem>
//         </List>
//       </Paper>
//     </Box>
//   );
// };

// export default HealthStatus;









import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Grid,
} from "@mui/material";
import { useSocket } from "../../SocketContext";
import { useHealthStatusListener, useHealthStore } from "../../store";

const HealthStatus = () => {

  const [systemHealthData, setSystemHealthData] = useState({});
  const [azimuthStatus, setAzimuthHealthData] = useState({});
  const [elevationStatus, setElevationHealthData] = useState({});
  const [currentTime, setCurrentTime] = useState({});
  const [openPopup, setOpenPopup] = useState(false); // State for opening/closing the popup
  const [selectedParameter, setSelectedParameter] = useState(""); // State for selected parameter's info
  const [motorRunning, setMotorRunning] = useState(true);
  const [motorDirectionCW, setMotorDirectionCW] = useState(true);
  const [motorDirectionCCW, setMotorDirectionCCW] = useState(false);
  const [encoderStatus, setEncoderStatus] = useState(false);
  const [driveErrorStop, setDriveErrorStop] = useState(true);
  const [drivePowerStatus, setDrivePowerStatus] = useState(false);
  const [openDialog, setOpenDialog] = useState(null);






  const healthStatus = useHealthStore((state) => state.healthStatus);

  useHealthStatusListener();


  const [responseValues, setResponseValues] = useState({
    timeStamp: {
      timeMilliSec: null,
      time: null,
    },
    systemEMMStatus: {
      radomeEStopSwitch1: false,
      radomeDoorSwitch: false,
      radomeEStopSwitch2: false,
      servoPanelEStop: false,
      azDriveError: false,
      elDriveError: false,
      systemReady: false,
      systemEnabled: false,
    },
    systemOperationParameters: {
                    mode:false,
      localModeOperating:false,
     remoteModeOperating:false,
              manualMode:false,
           designateMode:false,
              volumeScan:false,
            azSectorScan:false,
            elSectorScan:false
    },
    systemSyncSignalStatus: null,
    servoPanelIncomePowerSupplyStatus: null,
    spareModificationUsed: {
      highWindSpeed: false,
      frontDoorInterlock: false,
      backDoorInterlock: false,
      internalVibrationMonitor: false,
      antennaCoolingUnit: false,
      stowLockEnable: false,
    },
    azimuthStatus: {
      auxPower: false,
      busVoltage: null,
      heatSinkTemp: null,
      brakeCurrent: null,
      driveError: false,
      driveErrorID1: null,
      driveErrorID2: null,
      driveErrorID3: null,
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
        microswitchHandCranking: false,
        azimuthStowLock: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        azimuthPowerOn: false,
        azimuthEnable: false,
        azimuthSTO: false,
      },
    },
    elevationStatus: {
      auxPower: false,
      busVoltage: null,
      heatSinkTemp: null,
      brakeCurrent: null,
      driveError: false,
      driveErrorID1: null,
      driveErrorID2: null,
      driveErrorID3: null,
      limitsStatus: {
        elevationUpDirSoftLimit: false,
        elevationUpDirPreLimit: false,
        elevationUpDirFinalLimit: false,
        elevationDnDirSoftLimit: false,
        elevationDnDirPreLimit: false,
        elevationDnDirFinalLimit: false,
      },
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
        microswitchHandCranking: false,
        elevationStowLock: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        elevationPowerOn: false,
        elevationEnable: false,
        elevationSTO: false,
      },
    },
  });
  
  useEffect(() => {
    if (healthStatus) {
      setResponseValues(healthStatus); // Update the state with healthStatus from the store
    }
  }, [healthStatus]); // Only return when healthStatus from the store changes



  

 

  const Azparameters = [
    {
      name: "Azimuth Auxilary Power",
      value: responseValues?.azimuthStatus?.auxPower || "Loading...",
    },
    {
      name: "Azimuth Bus Voltage",
      value: responseValues?.azimuthStatus?.busVoltage || "Loading...",
    },
    {
      name: "AZ Heat Sink Temperature",
      value: responseValues?.azimuthStatus?.heatSinkTemp || "Loading...",
    },
    {
      name: "AZ Brake Current",
      value: responseValues?.azimuthStatus?.brakeCurrent || "Loading...",
    },
    { 
      name: "AZ Drive Error", 
      value: responseValues?.azimuthStatus?.driveError 
    },
    {
      name: "AZ Drive Error ID 1",
      value: responseValues?.azimuthStatus?.driveErrorID1 || "Loading...",
    },
    {
      name: "AZ Drive Error ID 2",
      value: responseValues?.azimuthStatus?.driveErrorID2 || "Loading...",
    },
    {
      name: "AZ Drive Error ID 3",
      value: responseValues?.azimuthStatus?.driveErrorID3 || "Loading...",
    },
    {
      name: "Az Running Status",
      value:"See Details",
    
    },
    {
      name: "Az Digital Input",
      value:"See Details",

    
    },
    {
      name: "Az Digital Output",
      value:"See Details",

     
    },
  ];
  

  const Elparameters = [
    {
      name: "Elevation Auxilary Power",
      value: responseValues?.elevationStatus?.auxPower || "Loading...",
    },
    {
      name: "Elevation Bus Voltage",
      value: responseValues?.elevationStatus?.busVoltage || "Loading...",
    },
    {
      name: "EL Heat Sink Temperature",
      value: responseValues?.elevationStatus?.heatSinkTemp || "Loading...",
    },
    {
      name: "EL Break Current",
      value: responseValues?.elevationStatus?.brakeCurrent || "Loading...",
    },
    {
      name: "EL Drive Error",
      value: responseValues?.elevationStatus?.driveError ,
    },
    {
      name: "EL Drive Error ID 1",
      value: responseValues?.elevationStatus?.driveErrorID1 || "Loading...",
    },
    {
      name: "EL Drive Error ID 2",
      value: responseValues?.elevationStatus?.driveErrorID2 || "Loading...",
    },
    {
      name: "EL Drive Error ID 3",
      value: responseValues?.elevationStatus?.driveErrorID3 || "Loading...",
    },
    {
      name: "EL Limit Status",
      value:"See Details",

    
    },
    {
      name: "EL Running Status",
      value:"See Details",

      
    },
    {
      name: "EL Digital Input",
      value:"See Details",

      
    },
    {
      name: "EL Digital Output",
      value:"See Details",

    },
  ];

  const handleOpenPopup = (paramName) => {
    setSelectedParameter(paramName); // Set the selected parameter name or any other info you want
    setOpenPopup(true); // Open the popup
  };

  const handleClosePopup = () => {
    setOpenPopup(false); // Close the popup
    setSelectedParameter(""); // Clear the selected parameter
  };

  const getButtonColor = (value) => {
    return value === true ? "#b8ebb5" : "#ebb5b5";
  };

  const handleOpenDialog = (dialogType) => {
    setOpenDialog(dialogType);
  };

  const handleCloseDialog = () => {
    setOpenDialog(null);
  };

 
 
  return (
    <Box display="flex" flexDirection="column" gap={2} p={2}>
      {/* Time and Date Section */}
      <Paper
        elevation={3}
        sx={{ p: 3, mb: 2, borderRadius: "8px", boxShadow: 3 }}
      >
        <Typography
          variant="h4"
          sx={{
            fontWeight: "bold",
            textAlign: "center",
            marginBottom: "6px",
            fontFamily: "'Times New Roman', serif", // Font for the label

          }}
        >
          Servo Health Status
        </Typography>

        {/* Time Section */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={2}
        >
          <Box display="flex" gap={3}>
          <Typography variant="h6" sx={{ fontWeight: 'bold', marginBottom: 1, marginLeft: 1, marginTop: 1, backgroundColor: "" ,                          fontFamily: "'Times New Roman', serif", // Font for the label
}}>
 {/* {responseValues.timeStamp.time ? (
    new Date(responseValues.timeStamp.time).toLocaleString('en-US', {
      weekday: 'short', // Abbreviated day (e.g., 'Mon')
      year: 'numeric',  // Full year (e.g., '2025')
      month: '2-digit', // Two-digit month (e.g., '03')
      day: '2-digit',   // Two-digit day (e.g., '03')
      hour: '2-digit',  // Two-digit hour (e.g., '09')
      minute: '2-digit',// Two-digit minute (e.g., '52')
      hour12: true      // 12-hour format with AM/PM
    }).replace(',', '') // Remove comma from default format
  ) : 'Loading...'} */}
</Typography>
          </Box>
        </Box>

        {/* Date Section (Formatted as 20-02-2025) */}
        {/* <Typography
          variant="h6"
          sx={{ fontWeight: "bold", color: "text.secondary" }}
        >
          {`${currentTime.day}-${currentTime.month}-${currentTime.year}`}
        </Typography> */}

        <Box display="flex" justifyContent="flex-end" mt={-5} mb={2}  
 >
          <Button
            variant="contained"
            sx={{fontFamily: "'Times New Roman', serif" }}
            color= {responseValues?.servoPanelIncomePowerSupplyStatus===true?"success":"error"}
            onClick={() => handleOpenDialog("servoPanelStatus")}
            
          >
            Servo Panel Income Power Supply Status
          </Button>
        </Box>
        <Box display="flex" gap={2} mt={1}>
          <Button
            variant="contained"
            color="primary"
            sx={{ flex: 1, fontFamily: "'Times New Roman', serif", // Font for the label
            }}
            onClick={() => handleOpenDialog("emmStatus")}
            
          >
            System EMM Status
          </Button>
          <Button
            variant="contained"
            color="secondary"
            sx={{ flex: 1 , fontFamily: "'Times New Roman', serif",}}
            onClick={() => handleOpenDialog("operationParameter")}
          >
            System Operation Parameter
          </Button>
          <Button
            variant="contained"
            color="error"
            sx={{ flex: 1, fontFamily: "'Times New Roman', serif", }}
            onClick={() => handleOpenDialog("syncSignalStatus")}
          >
            System Sync Signal Status
          </Button>
          <Button
            variant="contained"
            color="primary"
            sx={{ flex: 1 , fontFamily: "'Times New Roman', serif",}}
            onClick={() => handleOpenDialog("modificationUsed")}
          >
            Modification Used
          </Button>

          {/* Dialog for System EMM Status */}
          <Dialog open={openDialog === "emmStatus"} onClose={handleCloseDialog}>
            <DialogTitle sx={{fontFamily:"'Times New Roman', serif"}}>System EMM Status</DialogTitle>
            <DialogContent>
              <Grid container spacing={2} justifyContent="center">
                {/* Row 1 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.radomeEStopSwitch1),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setMotorRunning(!motorRunning)}
                  >
                    Radome EStop Switch_1
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.radomeDoorSwitch),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
        
                  >
                    Radom Door Switch
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.radomeEStopSwitch2),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                  >
                    Radome EStop Switch_2
                    </Button>
                    {/* <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(motorDirectionCCW),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 80, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      marginLeft: "10px",
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    System Enabled
                  </Button> */}
                </Grid>

                {/* Row 2 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.servoPanelEStop),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                  >
                    Servo Panel E_Stop
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.azDriveError),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                 
                  >
                    Az Drive Error
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemEMMStatus?.elDriveError),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    EL Drive Error
                  </Button>
                  {/* <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(drivePowerStatus),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 80, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    System Ready
                  </Button> */}
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
            <Button onClick={handleCloseDialog} color="primary" sx={{fontFamily:"'Times New Roman', serif"}}>
            Close
              </Button>
              {/* <Button onClick={handleCloseDialog} color="secondary">
                Save
              </Button> */}
            </DialogActions>
          </Dialog>

          {/* Dialog for System Operation Parameter */}
          <Dialog
            open={openDialog === "operationParameter"}
            onClose={handleCloseDialog}
          >
            <DialogTitle sx={{fontFamily:"'Times New Roman', serif"}}>System Operation Parameter</DialogTitle>
            <DialogContent>
              <Grid container spacing={2} justifyContent="center">
                {/* Row 1 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.mode),

                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setMotorRunning(!motorRunning)}
                  >
                    Mode
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.localModeOperating),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                    onClick={() => setMotorDirectionCW(!motorDirectionCW)}
                  >
                    Local Mode Operating
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.remoteModeOperating),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                    onClick={() => setMotorDirectionCCW(!motorDirectionCCW)}
                  >
                    Remote Mode Operating
                  </Button>
                </Grid>

                {/* Row 2 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.manualMode),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setEncoderStatus(!encoderStatus)}
                  >
                    Manual Mode
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.designateMode),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDriveErrorStop(!driveErrorStop)}
                  >
                    Designate Mode
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.volumeScan),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    Volume Scan
                  </Button>
                </Grid>


                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.azSectorScan),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    Azimuth Sector Scan
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(responseValues?.systemOperationParameters?.elSectorScan),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000,                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    Elevation Sector Scan 
                  </Button>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
            <Button onClick={handleCloseDialog} color="primary" sx={{fontFamily:"'Times New Roman', serif"}}>
            Close
              </Button>
              {/* <Button onClick={handleCloseDialog} color="secondary">
                Save
              </Button> */}
            </DialogActions>
          </Dialog>

          {/* Dialog for System Sync Signal Status */}
          <Dialog
            open={openDialog === "syncSignalStatus"}
            onClose={handleCloseDialog}
          >
            <DialogTitle sx={{fontFamily:"'Times New Roman', serif"}}>System Sync Signal Status</DialogTitle>
            <DialogContent>
              <Grid container spacing={2} justifyContent="center">
                {/* Row 1 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(motorRunning),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setMotorRunning(!motorRunning)}
                  >
                    Heart_Beat
                  </Button>
                </Grid>

                
              </Grid>
            </DialogContent>
            <DialogActions>
            <Button onClick={handleCloseDialog} color="primary" sx={{fontFamily:"'Times New Roman', serif"}}>
            Close
              </Button>
              {/* <Button onClick={handleCloseDialog} color="secondary">
                Save
              </Button> */}
            </DialogActions>
          </Dialog>

          {/* Dialog for Modification Used */}
          <Dialog
            open={openDialog === "modificationUsed"}
            onClose={handleCloseDialog}
          >
            <DialogTitle sx={{fontFamily:"'Times New Roman', serif"}}>Modification Used</DialogTitle>
            <DialogContent>
              <Grid container spacing={2} justifyContent="center">
                {/* Row 1 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(motorRunning),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setMotorRunning(!motorRunning)}
                  >
                    High Wind Spees
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(motorDirectionCW),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                    onClick={() => setMotorDirectionCW(!motorDirectionCW)}
                  >
                  Front Door Interlock for Instrumentation-box
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(motorDirectionCCW),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      marginTop: 3,
                      fontWeight: "bold",
                      fontFamily: "'Times New Roman', serif",
                    }}
                    onClick={() => setMotorDirectionCCW(!motorDirectionCCW)}
                  >
                  Back Door Interlock for Instrumentation-box
                  </Button>
                </Grid>

                {/* Row 2 */}
                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(encoderStatus),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setEncoderStatus(!encoderStatus)}
                  >
                    Internal Vibration Monitor Interlock
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(driveErrorStop),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDriveErrorStop(!driveErrorStop)}
                  >
                    Antenna Cooling Unit Interlock
                  </Button>
                </Grid>

                <Grid item xs={4} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: getButtonColor(drivePowerStatus),
                      color: "black",
                      borderRadius: "50%", // Make button circular
                      width: 1000, // Adjust the size of the button
                      height: 80, // Same height and width to keep it circular
                      fontFamily: "'Times New Roman', serif",
                      fontWeight: "bold",
                    }}
                    onClick={() => setDrivePowerStatus(!drivePowerStatus)}
                  >
                    Stow-Lock 
                  </Button>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog} color="primary" sx={{fontFamily:"'Times New Roman', serif"}}>
                Close
              </Button>
              {/* <Button onClick={handleCloseDialog} color="secondary">
                Save
              </Button> */}
            </DialogActions>
          </Dialog>
        </Box>

        {/* Dialog for System Operation Parameter */}

        {/* Dialog for System Sync Signal Status */}
      </Paper>

      {/* System Data - Horizontal Layout */}
      <Box
        display="flex"
        justifyContent="space-between"
        gap={3}
        marginTop="-10px"
      >
        {/* Azimuth Health Section */}
        <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "6px",
              // color: theme.palette.text.primary,
              fontFamily: "'Times New Roman', serif", // Font for the label

            }}
          >
            Azimuth Health Status
          </Typography>
          <Box sx={{ padding: "6px", borderRadius: "8px" }}>
            <Box display="flex" flexDirection="column" gap="22px">
              {Azparameters.map((param, index) => (
                <Box
                  key={index}
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    background: "rgba(255, 255, 255, 0.1)",
                    borderRadius: "8px",
                    padding: "1px 6px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.2)",
                    },
                  }}
                  onClick={() => {
                    // Trigger the popup for specific parameters
                    if (param.name === "Az Running Status") {
                      handleOpenPopup(
                        <Grid container spacing={2} justifyContent="center">
                          {/* Row 1 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.azimuthStatus?.runningStatus?.motorRunning),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                            
                            >
                              Motor Running
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.azimuthStatus?.runningStatus?.motorDirectionCW),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                             
                            >
                              Motor Direction CW
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                getButtonColor(responseValues?.azimuthStatus?.runningStatus?.motorDirectionCCW),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                            
                            >
                              Motor Direction CCW
                            </Button>
                          </Grid>

                          {/* Row 2 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.azimuthStatus?.runningStatus?.encoderStatus),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                           
                            >
                              Encoder Status
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.azimuthStatus?.runningStatus?.driveErrorStop),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                            
                            >
                              Drive Error Stop
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                getButtonColor(responseValues?.azimuthStatus?.runningStatus?.drivePowerStatus),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                             
                            >
                              Drive Power Status
                            </Button>
                          </Grid>
                        </Grid>
                      );
                    }

                    if (param.name === "Az Digital Input") {
                      handleOpenPopup(
                        <Grid container spacing={4} justifyContent="center">
                          {/* Row 1 */}

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.azimuthStatus?.digitalInputs?.controlInhibit),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                          
                            >
                              Drive Control Inhibit
                            </Button>
                          </Grid>
                          
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                getButtonColor(responseValues?.azimuthStatus?.digitalInputs?.driveSTO1Status),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                            
                            >
                              Drive STO1 Status
                              </Button>
                          </Grid>

                 
                        </Grid>
                      );
                    }

                    if (param.name === "Az Digital Output") {
                      handleOpenPopup(
                        <Grid container spacing={10} justifyContent="center">
                          {/* Row 1 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:       getButtonColor(responseValues?.azimuthStatus?.digitalOutputs?.azimuthPowerOn),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                            >
                              Azimuth Power ON
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                getButtonColor(responseValues?.azimuthStatus?.digitalOutputs?.azimuthSTO),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                             
                            >
                             Drive STO Enable Relay
                            </Button>
                          </Grid>

                          

                          {/* Row 2 */}
                          
                        </Grid>
                      );
                    }

                    // if (param.name === "") {
                    //   handleOpenPopup(
                    //     <Grid container spacing={2} justifyContent="center">
                    //       {/* Row 1 */}
                    //       <Grid
                    //         item
                    //         xs={4}
                    //         display="flex"
                    //         justifyContent="center"
                    //       >
                    //         <Button
                    //           variant="contained"
                    //           sx={{
                    //             backgroundColor: getButtonColor(""),
                    //             color: "black",
                    //             borderRadius: "50%", // Make button circular
                    //             width: 80, // Adjust the size of the button
                    //             height: 80, // Same height and width to keep it circular
                    //             marginTop: 5,
                    //             padding: 5,
                    //             marginLeft: -5,
                    //             fontFamily: "'Times New Roman', serif",
                    //             fontWeight: "bold",
                    //           }}
                    //           onClick={() => setMotorDirectionCCW("")}
                    //         >
                    //           Azimuth Power ON
                    //         </Button>
                    //       </Grid>
                    //       <Grid
                    //         item
                    //         xs={4}
                    //         display="flex"
                    //         justifyContent="center"
                    //       >
                    //         <Button
                    //           variant="contained"
                    //           sx={{
                    //             backgroundColor: getButtonColor(""),
                    //             color: "black",
                    //             borderRadius: "50%", // Make button circular
                    //             width: 80, // Adjust the size of the button
                    //             height: 80, // Same height and width to keep it circular
                    //             marginTop: 5,
                    //             padding: 5,
                    //             marginLeft: 5,
                    //             fontFamily: "'Times New Roman', serif",
                    //             fontWeight: "bold",
                    //           }}
                    //           onClick={() => setMotorDirectionCCW("")}
                    //         >
                    //           Drive STO Enable Relay
                    //         </Button>
                    //       </Grid>{" "}
                    //     </Grid>
                    //   );
                    // }
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{ fontWeight: "bold", textTransform: "uppercase", fontFamily: "'Times New Roman', serif"  }}
                  >
                    {param.name}
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: "medium", fontFamily: "'Times New Roman', serif" }}>
                    {param.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Paper>

        <Dialog open={openPopup} onClose={handleClosePopup}>
          <DialogTitle>{}</DialogTitle>
          <DialogContent>
            <Typography variant="body1">
              {/* You can customize the content of the popup as needed */}
              {/* Information about {selectedParameter} */}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClosePopup} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>

        {/* Elevation Health Section */}
        <Paper elevation={3} sx={{ p: 2, flex: 1 }}>
          <Typography
            variant="h4"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "6px",
              // color: theme.palette.text.primary,
              fontFamily: "'Times New Roman', serif", // Font for the label

            }}
          >
            Elevation Health Status
          </Typography>
          <Box sx={{ padding: "6px", borderRadius: "8px" }}>
            <Box display="flex" flexDirection="column" gap="22px">
              {Elparameters.map((param, index) => (
                <Box
                  key={index}
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    background: "rgba(255, 255, 255, 0.1)",
                    borderRadius: "8px",
                    padding: "1px 6px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.2)",
                    },
                  }}
                  onClick={() => {
                    // Trigger the popup for specific parameters
                    if (param.name === "EL Running Status") {
                      handleOpenPopup(
                        <Grid container spacing={2} justifyContent="center">
                          {/* Row 1 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.runningStatus?.motorRunning),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                           
                            >
                              Motor Running
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                     
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.runningStatus?.motorDirectionCW),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                           
                            >
                              Motor Direction CW
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                             
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.runningStatus?.motorDirectionCCW),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                              onClick={() =>
                                setMotorDirectionCCW(!motorDirectionCCW)
                              }
                            >
                              Motor Direction CCW
                            </Button>
                          </Grid>

                          {/* Row 2 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.runningStatus?.encoderStatus),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                          
                            >
                              Encoder Status
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.runningStatus?.motorDirectionCCW),

                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                              onClick={() => setDriveErrorStop(!driveErrorStop)}
                            >
                              Drive Error Stop
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.elevationStatus?.runningStatus?.drivePowerStatus),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontFamily: "'Times New Roman', serif",
                                fontWeight: "bold",
                              }}
                              onClick={() =>
                                setDrivePowerStatus(!drivePowerStatus)
                              }
                            >
                              Drive Power Status
                            </Button>
                          </Grid>
                        </Grid>
                      );
                    }

                    if (param.name === "EL Digital Input") {
                      handleOpenPopup(
                        <Grid container spacing={4} justifyContent="center">
                          {/* Row 1 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.elevationStatus?.digitalInputs?.controlInhibit),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                             
                            >
                              Drive Control Inhibit
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.elevationStatus?.digitalInputs?.driveSTO1Status),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                            
                            >
                              Drive STO1 Status
                            </Button>
                          </Grid>
                        </Grid>
                      );
                    }

                    if (param.name === "EL Digital Output") {
                      handleOpenPopup(
                        <Grid
                          container
                          spacing={4}
                          justifyContent="center"
                          padding="5"
                        >
                          {/* Row 1 */}
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                            padding="5"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.elevationStatus?.digitalOutputs?.elevationPowerOn),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                              onClick={() => setMotorDirectionCCW("")}
                            >
                              Elevation Power ON
                            </Button>
                          </Grid>
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor:
                                  getButtonColor(responseValues?.elevationStatus?.digitalOutputs?.elevationSTO),
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 400, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                              onClick={() => setMotorDirectionCCW("")}
                            >
                              Drive STO Enable Relay
                            </Button>
                          </Grid>{" "}
                        </Grid>
                      );
                    }

                    if (param.name === "EL Limit Status") {
                      handleOpenPopup(
                        <Grid container spacing={2} justifyContent="center">
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationUpDirSoftLimit),
                                // responseValues.driveErrorStop
                                color: "black",
                                borderRadius: "50%",
                                width: 80,
                                height: 80,
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
  
                            >
                              Up Dir Soft Limit
                            </Button>
                          </Grid>
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationUpDirPreLimit),
                                // responseValues.driveErrorStop
                                color: "black",
                                borderRadius: "50%",
                                width: 80,
                                height: 80,
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                            
                            >
                              Up Dir Pre Limit
                            </Button>
                          </Grid>
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationUpDirFinalLimit),
                                // responseValues.driveErrorStop

                                color: "black",
                                borderRadius: "50%",
                                width: 80,
                                height: 80,
                                marginTop: 3,
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                              
                            >
                              Up Dir Final Limit
                            </Button>
                          </Grid>
                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationDnDirSoftLimit),
                                // responseValues.driveErrorStop
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                            
                            >
                              Dn Dir Soft Limit
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationDnDirPreLimit),
                                // responseValues.driveErrorStop
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                           
                            >
                              Dn Dir Pre Limit
                            </Button>
                          </Grid>

                          <Grid
                            item
                            xs={4}
                            display="flex"
                            justifyContent="center"
                          >
                            <Button
                              variant="contained"
                              sx={{
                                backgroundColor: getButtonColor(responseValues?.elevationStatus?.limitsStatus?.elevationDnDirFinalLimit),
                                // responseValues.driveErrorStop
                                color: "black",
                                borderRadius: "50%", // Make button circular
                                width: 80, // Adjust the size of the button
                                height: 80, // Same height and width to keep it circular
                                fontWeight: "bold",
                                fontFamily: "'Times New Roman', serif",
                              }}
                           
                            >
                              Dn Dir Final Limit
                            </Button>
                          </Grid>

                          {/* Additional content for elevation can go here */}
                        </Grid>
                      );
                    }
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    sx={{ fontWeight: "bold", textTransform: "uppercase", fontFamily: "'Times New Roman', serif"  }}
                  >
                    {param.name}
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: "medium", fontFamily: "'Times New Roman', serif" }}>
                    {param.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Paper>

        <Dialog open={openPopup} onClose={handleClosePopup}>
          <DialogTitle>{}</DialogTitle>
          <DialogContent>
            <Typography variant="body1">
              {/* You can customize the content of the popup as needed */}
               {selectedParameter}
            </Typography>
          </DialogContent>
      
        </Dialog>
      </Box>
    </Box>
  );
};

export default HealthStatus;















