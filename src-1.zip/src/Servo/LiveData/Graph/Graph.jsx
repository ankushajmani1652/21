import React from 'react'

const Graph = () => {
  return (
    <div>
      
    </div>
  )
}

export default Graph
