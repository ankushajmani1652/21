import React, { useState, useEffect } from "react";
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  FormControl,
  InputLabel,
  TextField,
  Select,
  MenuItem,
  Button,
  Snackbar,
  Slide,
  Alert,
} from "@mui/material";
import { useSocket } from "../../SocketContext";
import { ValueScope } from "ajv/dist/compile/codegen";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";

// Dashboard Component
const ServoResponse = () => {
  const [activeScan, setActiveScan] = useState("azimuth"); // Manage selected scan type
  const [chartData, setChartData] = useState([]);
  const [angle, setAngle] = useState(0);
  const [angleError, setAngleError] = useState(5);

  const handleChange = (event, newValue) => {
    setActiveScan(newValue);
  };

  const socket = useSocket();

  const [showSnackbar, setShowSnackbar] = useState(false);
  const [ackMessage, setAckMessage] = useState(""); // State for acknowledgment messages
  const [warningOpen, setWarningOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");
  const [azimuthParameterValues, setAzimuthParameterValues] = useState([
    { title: "Datalog Enable", value: "" },
    { title: "Running Current", value: "" },
    { title: "Overshoot", value: "" },
    { title: "Bandwidth", value: "" },
    { title: "Encoder Data", value: "" },
    { title: "Commanded Speed", value: "" },
    { title: "Running Speed", value: "" },
    { title: "Speed Error", value: "" },
    { title: "Commanded Angle", value: "" },
    { title: "Angle Error", value: "" },
    { title: "Rise Time", value: "" },
    { title: "Settling Time", value: "" },
    { title: "Max Velocity", value: "" },
    { title: "Max Acceleration", value: "" },
  ]);

  const [elevationParameterValues, setlevationParameterValues] = useState([
    { title: "Datalog Enable", value: "" },
    { title: "Running Current", value: "" },
    { title: "Overshoot", value: "" },
    { title: "Bandwidth", value: "" },
    { title: "Encoder Data", value: "" },
    { title: "Commanded Speed", value: "" },
    { title: "Running Speed", value: "" },
    { title: "Speed Error", value: "" },
    { title: "Commanded Angle", value: "" },
    { title: "Angle Error", value: "" },
    { title: "Rise Time", value: "" },
    { title: "Settling Time", value: "" },
    { title: "Max Velocity", value: "" },
    { title: "Max Acceleration", value: "" },
  ]);
  const showWarning = (message) => {
    setWarningMessage(message);
    setWarningOpen(true);
  };

  const handleWarningClose = () => {
    setWarningOpen(false);
  };
  const [showResponse, setShowResponse] = useState("");
  useEffect(() => {
    const handleStepResponse = (data) => {
      setShowResponse(true);
      console.log(`Received Step Response Data: ${JSON.stringify(data)}`);

      setAzimuthParameterValues((prevValues) =>
        prevValues.map((param) => ({
          ...param,
          value:
            data?.azimuthData?.[convertAzTitleToKey(param.title)] ??
            param.value,
        }))
      );

      setlevationParameterValues((prevValues) =>
        prevValues.map((param) => ({
          ...param,
          value:
            data?.elevationData?.[convertElTitleToKey(param.title)] ??
            param.value,
        }))
      );
    };

    if (socket) {
      socket.on("stepResponse", handleStepResponse);
    } else {
      console.error("Socket is undefined!");
    }

    return () => {
      socket.off("stepResponse", handleStepResponse);
    };
  }, [socket]);

  // Function to map titles to corresponding data keys
  const convertAzTitleToKey = (title) => {
    const keyMap = {
      "Datalog Enable": "azimuthDatalogEnabled",
      "Running Current": "azimuthRunningCurrent",
      Overshoot: "azimuthOvershootPct",
      Bandwidth: "azimuthBandwidth",
      "Encoder Data": "azimuthEncoderData",
      "Commanded Speed": "azimuthCommandSpeed",
      "Running Speed": "azimuthRunningSpeed",
      "Speed Error": "azimuthSpeedError",
      "Commanded Angle": "azimuthAngle",
      "Angle Error": "azimuthAngleError",
      "Rise Time": "azimuthRiseTimeSecs",
      "Settling Time": "azimuthSettlingTimeSecs",
      "Max Velocity": "azimuthMeasuredMaxVelocityRpm",
      "Max Acceleration": "azimuthMeasuredMaxAccelerationDegSec2",
    };

    return keyMap[title.trim()] || null;
  };

  const convertElTitleToKey = (title) => {
    const keyMap = {
      "Datalog Enable": "elevationDatalogEnable",
      "Running Current": "elevationRunningCurrent",
      Overshoot: "elevationOvershootPct",
      Bandwidth: "elevationBandwidth",
      "Encoder Data": "elevationEncoderData",
      "Commanded Speed": "elevationCommandSpeed",
      "Running Speed": "elevationRunningSpeed",
      "Speed Error": "elevationSpeedError",
      "Commanded Angle": "elevationCommandedAngle",
      "Angle Error": "elevationAngleError",
      "Rise Time": "elevationRiseTimeSecs",
      "Settling Time": "elevationSettlingTimeSecs",
      "Max Velocity": "elevationMeasuredMaxVelocity",
      "Max Acceleration": "elevationMeasuredMaxAcceleration",
    };

    return keyMap[title.trim()] || null;
  };

  const [AZparameters, setAZparameters] = useState([
    { name: "Azimuth Velocity", value: "" },
    { name: "Azimuth Acceleration", value: "" },
    { name: "Azimuth Deacceleration", value: "" },
    { name: "Azimuth Mode", value: "" },
    { name: "Azimuth Start/Stop", value: "" },
    { name: "Azimuth Start Angle", value: "" },
    { name: "Azimuth End Angle", value: "" },
    { name: "Sampling Interval", value: "" },
    { name: "Azimuth Enable", value: "" },
    { name: "AZ Steady State Time", value: "" },
    { name: "AZ Steady State Error", value: "" },
  ]);

  const [ELparameters, setELparameters] = useState([
    { name: "Elevation Velocity", value: "" },
    { name: "Elevation Acceleration", value: "" },
    { name: "Elevation Deacceleration ", value: "" },
    { name: "Elevation Mode", value: "" },
    { name: "Elevation Start/Stop", value: "" },
    { name: "Elevation Start Angle", value: "" },
    { name: "Elevation End Angle", value: "" },
    { name: "Elevation Enable", value: "" },
    { name: "EL Steady State Time", value: "" },
    { name: "EL Steady State Error", value: "" },
  ]);

  // Function to close the dialog
  const handleValueChange = (paramName, newValue, type) => {
    if (type === "AZ") {
      const updatedParameters = AZparameters.map((param) =>
        param.name === paramName ? { ...param, value: newValue } : param
      );
      setAZparameters(updatedParameters);
    } else if (type === "EL") {
      const updatedParameters = ELparameters.map((param) =>
        param.name === paramName ? { ...param, value: newValue } : param
      );
      setELparameters(updatedParameters);
    }
  };

  const sendData = (e) => {
    e.preventDefault();
    const payload = {
      azimuthVelocity: AZparameters.find(
        (param) => param.name === "Azimuth Velocity"
      )?.value,
      azimuthAcceleration: AZparameters.find(
        (param) => param.name === "Azimuth Acceleration"
      )?.value,
      azimuthDeceleration: AZparameters.find(
        (param) => param.name === "Azimuth Deceleration"
      )?.value,
      azimuthMode: AZparameters.find((param) => param.name === "Azimuth Mode")
        ?.value,
      azimuthStartStop: AZparameters.find(
        (param) => param.name === "Azimuth Start/Stop"
      )?.value,
      azimuthStartAngle: AZparameters.find(
        (param) => param.name === "Azimuth Start Angle"
      )?.value,
      azimuthEndAngle: AZparameters.find(
        (param) => param.name === "Azimuth End Angle"
      )?.value,
      elevationVelocity: ELparameters.find(
        (param) => param.name === "Elevation Velocity"
      )?.value,
      elevationAcceleration: ELparameters.find(
        (param) => param.name === "Elevation Acceleration"
      )?.value,
      elevationDeceleration: ELparameters.find(
        (param) => param.name === "Elevation Deceleration"
      )?.value,
      elevationMode: ELparameters.find(
        (param) => param.name === "Elevation Mode"
      )?.value,
      elevationStartStop: ELparameters.find(
        (param) => param.name === "Elevation Start/Stop"
      )?.value,
      elevationStartAngle: ELparameters.find(
        (param) => param.name === "Elevation Start Angle"
      )?.value,
      elevationEndAngle: ELparameters.find(
        (param) => param.name === "Elevation End Angle"
      )?.value,
      samplingInterval: AZparameters.find(
        (param) => param.name === "Sampling Interval"
      )?.value,
      azimuthEnable: AZparameters.find(
        (param) => param.name === "Azimuth Enable"
      )?.value,
      azimuthSteadyStateTime: AZparameters.find(
        (param) => param.name === "AZ Steady State Time"
      )?.value,
      azimuthSteadyStateError: AZparameters.find(
        (param) => param.name === "AZ Steady State Error"
      )?.value,
      elevationEnable: ELparameters.find(
        (param) => param.name === "Elevation Enable"
      )?.value,
      elevationSteadyStateTime: ELparameters.find(
        (param) => param.name === "EL Steady State Time"
      )?.value,
      elevationSteadyStateError: ELparameters.find(
        (param) => param.name === "EL Steady State Error"
      )?.value,
    };

    const invalidKeys = Object.keys(payload).filter(
      (key) => payload[key] === null || payload[key] === ""
    );

    if (invalidKeys.length > 0) {
      showWarning("Please enter all values");
    } else {
      console.log(payload); // You can now send this payload to your API or perform other actions.
      socket.emit("stepResponse", payload);
    }
  };

  return (
    <Box sx={{ padding: 2, backgroundColor: "", width: "auto" }}>
      {/* Tabs to switch between scans */}
      <Grid container spacing={1} sx={{ height: "100vh", overflow: "auto" }}>
        <Box
          sx={{
            padding: "20px",
            borderRadius: "8px",
            overflowY: "auto", // Allow scrolling
            height: "100%",
          }}
        >
          <Typography
            variant="h3"
            sx={{
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: "20px",
              color: "#333",
              fontFamily: "'Times New Roman', serif",
            }}
          >
            Enter Data
          </Typography>

          <Grid container spacing={1}>
            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  padding: "12px",
                  backgroundColor: "#f2f2e9",
                  borderRadius: "8px",
                  maxHeight: "calc(100vh - 200px)", // Restrict height
                  overflowY: "auto", // Allow scrolling if content exceeds height
                }}
              >
                <Typography
                  variant="h5"
                  sx={{
                    fontWeight: "bold",
                    textAlign: "center",
                    marginBottom: "12px",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  Azimuth Step
                </Typography>
                {/* Parameter List */}
                <Box display="flex" flexDirection="column" gap="12px">
                  {AZparameters.map((param, index) => (
                    <Box
                      key={index}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        background: "rgba(255, 255, 255, 0.1)",
                        borderRadius: "8px",
                        padding: "1px 6px",
                        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                        cursor: "pointer",
                        "&:hover": {
                          backgroundColor: "rgba(255, 255, 255, 0.2)",
                        },
                      }}
                    >
                      <Typography
                        variant="subtitle1"
                        sx={{
                          fontWeight: "bold",
                          textTransform: "uppercase",
                          fontFamily: "'Times New Roman', serif",
                        }}
                      >
                        {param.name}
                      </Typography>

                      {/* Handling different input types */}
                      {param.name === "Azimuth Mode" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            Select
                          </InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Mode"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "AZ"
                              )
                            }
                            sx={{ fontFamily: "'Times New Roman', serif" }} // Apply the font to Select
                          >
                            <MenuItem
                              value="Velocity"
                              sx={{ fontFamily: "'Times New Roman', serif" }}
                            >
                              Velocity
                            </MenuItem>
                            <MenuItem
                              value="Position"
                              sx={{ fontFamily: "'Times New Roman', serif" }}
                            >
                              Position
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "Azimuth Velocity" ? (
                        <TextField
                          label="Enter value (0-6)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 6) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Azimuth Start Angle" ||
                        param.name === "Azimuth End Angle" ? (
                        <TextField
                          label="Enter angle (0-360)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 360) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Sampling Interval" ? (
                        <TextField
                          label="Enter value (0-1000)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 1000) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Azimuth Enable" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel>Select</InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Select"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "AZ"
                              )
                            }
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            <MenuItem
                              value="Enable"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Enable{" "}
                            </MenuItem>
                            <MenuItem
                              value="Disable"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Disable
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "Azimuth Start/Stop" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel>Select</InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Select"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "AZ"
                              )
                            }
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            <MenuItem
                              value="Start"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Start
                            </MenuItem>
                            <MenuItem
                              value="Stop"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Stop
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "Az Steady State Time" ? (
                        <TextField
                          label="Enter value (0-1000)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 1000) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "AZ Steady State Error" ? (
                        <TextField
                          label="Enter value (0-15)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 15) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : (
                        <TextField
                          label="Enter value"
                          variant="outlined"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            // Ensure only numbers are allowed
                            if (/^\d*\.?\d*$/.test(newValue)) {
                              handleValueChange(param.name, newValue, "AZ");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px", // Adjust padding to fine-tune height
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      )}
                    </Box>
                  ))}
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  padding: "12px",
                  backgroundColor: "#f2f2e9",
                  borderRadius: "8px",
                  maxHeight: "calc(100vh - 200px)", // Restrict height
                  overflowY: "auto", // Allow scrolling if content exceeds height
                }}
              >
                <Typography
                  variant="h5"
                  sx={{
                    fontWeight: "bold",
                    textAlign: "center",
                    marginBottom: "12px",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  Elevation Step
                </Typography>
                {/* Parameter List */}
                <Box display="flex" flexDirection="column" gap="12px">
                  {ELparameters.map((param, index) => (
                    <Box
                      key={index}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        background: "rgba(255, 255, 255, 0.1)",
                        borderRadius: "8px",
                        padding: "1.5px 6px",
                        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                        cursor: "pointer",
                        "&:hover": {
                          backgroundColor: "rgba(255, 255, 255, 0.2)",
                        },
                      }}
                    >
                      <Typography
                        variant="subtitle1"
                        sx={{
                          fontWeight: "bold",
                          textTransform: "uppercase",
                          fontFamily: "'Times New Roman', serif",
                        }}
                      >
                        {param.name}
                      </Typography>
                      {param.name === "Elevation Mode" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel>Select</InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Mode"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "EL"
                              )
                            }
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            <MenuItem
                              value="Velocity"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Velocity
                            </MenuItem>
                            <MenuItem
                              value="Position"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Position
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "Elevation Velocity" ? (
                        <TextField
                          label="Enter value (0-6)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 6) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Elevation Start Angle" ||
                        param.name === "Elevation End Angle" ? (
                        <TextField
                          label="Enter angle (0-90)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 90) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Sampling Interval" ? (
                        <TextField
                          label="Enter value (0-1000)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 1000) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "Elevation Enable" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel>Select</InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Select"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "EL"
                              )
                            }
                            
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            <MenuItem
                              value="Enable"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Enable
                            </MenuItem>
                            <MenuItem
                              value="Disable"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Disable
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "Elevation Start/Stop" ? (
                        <FormControl sx={{ minWidth: 100 }}>
                          <InputLabel>Select</InputLabel>
                          <Select
                            value={param.value || ""} // Ensure that a value is always passed
                            label="Select"
                            onChange={(e) =>
                              handleValueChange(
                                param.name,
                                e.target.value,
                                "EL"
                              )
                            }
                            sx={{ fontFamily: "'Times New Roman', serif" }}
                          >
                            <MenuItem
                              value="Start"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Start
                            </MenuItem>
                            <MenuItem
                              value="Stop"
                              sx={{ fontFamily: "Times New Roman, serif" }}
                            >
                              Stop
                            </MenuItem>
                          </Select>
                        </FormControl>
                      ) : param.name === "EL Steady State Time" ? (
                        <TextField
                          label="Enter value (0-1000)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 1000) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },

                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : param.name === "EL Steady State Error" ? (
                        <TextField
                          label="Enter value (0-15)"
                          variant="outlined"
                          type="number"
                          value={param.value || ""}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            if (newValue >= 0 && newValue <= 15) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px",
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      ) : (
                        <TextField
                          label="Enter value"
                          variant="outlined"
                          value={param.value}
                          onChange={(e) => {
                            const newValue = e.target.value;
                            // Ensure only numbers are allowed
                            if (/^\d*\.?\d*$/.test(newValue)) {
                              handleValueChange(param.name, newValue, "EL");
                            }
                          }}
                          sx={{
                            width: "100px",
                            marginLeft: "10px",
                            "& .MuiInputBase-root": {
                              height: "50px", // Adjust this value to reduce height
                              fontFamily: "'Times New Roman', serif",
                            },
                            "& .MuiOutlinedInput-input": {
                              padding: "8px", // Adjust padding to fine-tune height
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                          InputLabelProps={{
                            style: {
                              // fontWeight: "bold",
                              fontSize: "0.8rem", // Label font size
                              fontFamily: "'Times New Roman', serif",
                              color: "black", // Label color is black by default
                            },
                          }}
                          InputProps={{
                            style: {
                              fontSize: "1rem",
                              fontFamily: "'Times New Roman', serif",
                            },
                          }}
                        />
                      )}
                    </Box>
                  ))}
                </Box>
              </Box>
            </Grid>
          </Grid>
          <Box sx={{ textAlign: "center", marginTop: "-10px" }}>
            <Button
              variant="contained"
              color="primary"
              sx={{ mt: 2, fontFamily: "'Times New Roman', serif" }}
              onClick={sendData}
            >
              Send Data
            </Button>
          </Box>
        </Box>

        {/* Right Section: Tabs and Content */}
        {showResponse && (
          <Grid item xs={12} md={7}>
            <Typography
              variant="h3"
              sx={{
                fontWeight: "bold",
                textAlign: "center",
                marginBottom: "20px",
                color: "#333",
                fontFamily:"'Times New Roman', serif"
              }}
            >
              Servo Response
            </Typography>

            {/* Top Section: Summary Boxes */}
            <Grid container spacing={2} sx={{ mb: 2 }}>
              {/* Azimuth Step Response */}
              <Grid item xs={12} md={6}>
                <Box
                  sx={{
                    backgroundColor: "#e3f2fd",
                    padding: 2,
                    borderRadius: 2,
                  }}
                >
                  <Typography variant="h6" sx={{ fontWeight: "bold", mb: 2, fontFamily:"'Times New Roman', serif" }}>
                    Azimuth Step Response
                  </Typography>
                  <Grid container spacing={2}>
                    {Array.isArray(azimuthParameterValues) &&
                      azimuthParameterValues.map((param) => (
                        <Grid item xs={4} key={param.title}>
                          <Card
                            sx={{
                              boxShadow: 2,
                              borderRadius: 2,
                              padding: 1,
                              height: "100%",
                            }}
                          >
                            <CardContent>
                              <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: "bold", mb: 1,fontFamily:"'Times New Roman', serif" }}
                              >
                                {param.title}
                              </Typography>
                              <Typography
                                variant="h5"
                                sx={{ fontWeight: "bold", color: "green" ,fontFamily:"'Times New Roman', serif"}}
                              >
                                {param.value}
                              </Typography>
                            </CardContent>
                          </Card>
                        </Grid>
                      ))}
                  </Grid>
                </Box>
              </Grid>

              {/* Elevation Step Response */}
              <Grid item xs={12} md={6}>
                <Box
                  sx={{
                    backgroundColor: "#e9f2e9",
                    padding: 2,
                    borderRadius: 2,
                  }}
                >
                  <Typography variant="h6" sx={{ fontWeight: "bold", mb: 2 ,fontFamily:"'Times New Roman', serif"}}>
                    Elevation Step Response
                  </Typography>
                  <Grid container spacing={2}>
                    {Array.isArray(elevationParameterValues) &&
                      elevationParameterValues.map((param) => (
                        <Grid item xs={4} key={param.title}>
                          <Card
                            sx={{
                              boxShadow: 2,
                              borderRadius: 2,
                              padding: 1,
                              height: "100%",
                            }}
                          >
                            <CardContent>
                              <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: "bold", mb: 1 ,fontFamily:"'Times New Roman', serif"}}
                              >
                                {param.title}
                              </Typography>
                              <Typography
                                variant="h5"
                                sx={{ fontWeight: "bold", color: "green" ,fontFamily:"'Times New Roman', serif"}}
                              >
                                {param.value}
                              </Typography>
                            </CardContent>
                          </Card>
                        </Grid>
                      ))}
                  </Grid>
                </Box>
              </Grid>
            </Grid>

            {/* Bottom Section: Charts/Responses */}
            <Grid container spacing={2}>
              <Grid item xs={12}>
                {/* This is where you can add a chart or other visual components */}
              </Grid>
            </Grid>
          </Grid>
        )}

        <Snackbar
          open={warningOpen}
          autoHideDuration={6000}
          onClose={handleWarningClose}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          TransitionComponent={(props) => <Slide {...props} direction="down" />}
        >
          <Alert
            onClose={handleWarningClose}
            severity="warning"
            sx={{
              width: "100%",
              backgroundColor: "#ffcc00",
              color: "#1a1a1a",
              fontWeight: "bold",
              fontSize: "1.2rem",
              boxShadow: "0 4px 15px rgba(0, 0, 0, 0.5)",
              border: "2px solid #ff9800",
            }}
            icon={
              <WarningAmberIcon
                fontSize="large"
                sx={{ marginRight: 1, color: "#ff9800" }}
              />
            }
          >
            {warningMessage}
          </Alert>
        </Snackbar>
      </Grid>
    </Box>
  );
};

export default ServoResponse;
