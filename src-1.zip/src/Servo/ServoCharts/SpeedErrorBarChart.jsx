import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';

Chart.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const SpeedErrorBarChart = () => {
    // Generate random values for demonstration
    const commandSpeed = Math.floor(Math.random() * 100) + 1; // Random value between 1 and 100
    const measuredSpeed = Math.floor(Math.random() * 100) + 1; // Random value between 1 and 100
    const error = Math.abs(commandSpeed - measuredSpeed);

    const data = {
        labels: ['Command Speed', 'Running Speed', 'Speed Error'],
        datasets: [
            {
                label: 'Speed (rpm)',
                data: [commandSpeed, measuredSpeed, error],
                backgroundColor: ['#3498db', '#2ecc71', '#e74c3c'],
                borderRadius: 5,
            },
        ],
    };

    const options = {
        responsive: true,
        plugins: {
            legend: {
                display: false,
            },
        },
    };

    return (
        <div className="speed-error-bar-chart">
            <Bar data={data} options={options} />
        </div>
    );
};

export default SpeedErrorBarChart;
