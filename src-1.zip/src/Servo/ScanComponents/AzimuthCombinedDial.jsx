// import React, { useState, useEffect } from 'react';
// // import { CircularProgressbarWithChildren, buildStyles } from 'react-circular-progressbar';
// // import 'react-circular-progressbar/dist/styles.css';
// import './AzimuthCombinedDial.css'; // Add custom styles for the needle

// const AzimuthCombinedDial = ({ commandedAngle, maxAngle, error }) => {
//     const [delayedAngle, setDelayedAngle] = useState(0);

//     useEffect(() => {
//         const timer = setTimeout(() => {
//             setDelayedAngle(commandedAngle); // Set the angle after the delay
//         }, 2000); // 2-second delay

//         return () => clearTimeout(timer); // Clear timeout when the component is unmounted
//     }, [commandedAngle]); // Trigger effect when commandedAngle changes

//     const percentage = (delayedAngle / maxAngle) * 100;
//     const needleRotation = (delayedAngle / maxAngle) * 360; // Calculate the needle's angle (0° to 360°)

//     return (
//         <div className="azimuth-combined-dial">
//             <CircularProgressbarWithChildren
//                 value={percentage}
//                 styles={buildStyles({
//                     pathColor: percentage > 80 ? '#ff4d4d' : '#4caf50', // Red if over 80%, Green otherwise
//                     trailColor: '#333', // Dark trail color for contrast
//                     textColor: '#fff', // White text color
//                     strokeWidth: 12, // Increased stroke width for a better gauge appearance
//                     backgroundColor: '#1c1c1c', // Dark background for better contrast
//                 })}
//             >
//                 {/* Needle Effect */}
//                 <div
//                     className="needle"
//                     style={{
//                         transform: `rotate(${needleRotation - 90}deg)`, // Adjust the needle to match the gauge (rotate by 90°)
//                         transition: 'transform 2s ease', // Apply smooth transition for the needle movement
//                     }}
//                 ></div>

//                 {/* Inner Text for Commanded Angle */}
//                 <div className="dial-text">
//                     <strong>{commandedAngle}°</strong>
//                     <p></p>
//                 </div>

//                 {/* Error Display */}
//                 {/* <div className="error-overlay">
//                     <p>Error: <strong>{error}°</strong></p>
//                 </div> */}
//             </CircularProgressbarWithChildren>
//         </div>
//     );
// };

// export default AzimuthCombinedDial;
import React from 'react'

const AzimuthCombinedDial = () => {
  return (
    <div>
      
    </div>
  )
}

export default AzimuthCombinedDial
