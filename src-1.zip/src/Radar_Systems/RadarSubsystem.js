import React, { useState } from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';

const SubsystemCard = ({ name, color, children, onClick, pressed }) => {
    const handleClick = () => {
        onClick();
    };

    return (
        <Card
            className={`card ${pressed ? 'pressed' : ''}`}
            sx={{
                width: { xs: '100%', sm: 220 },
                maxWidth: 300,
                textAlign: 'center',
                boxShadow: 6,
                borderRadius: 3,
                background: `linear-gradient(145deg, ${color}22, ${color}44)`,
                color: color,
                cursor: 'pointer',
                m: { xs: 1, sm: 2 },
                transition: 'transform 0.15s ease-in-out',
                position: 'relative', // Needed for absolute positioning
            }}
            onClick={handleClick}
        >
            {/* Top-left name */}
            <Box
                sx={{
                    position: 'absolute',
                    top: 8,
                    left: 12,
                    textAlign: 'left',
                    zIndex: 1,
                }}
            >
                <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 600, color: color }}
                >
                    {name}
                </Typography>
            </Box>

            <CardContent sx={{ pt: 3 }}>
                <Box sx={{ height: 60, mb: 2 }}>
                    {children}
                </Box>
            </CardContent>
        </Card>
    );
};

export default SubsystemCard;
