import React, { useState } from 'react';
import {
    CssBaseline,
    ThemeProvider,
    createTheme,
    Box,
    Typography,
    IconButton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import MemoryIcon from '@mui/icons-material/Memory';
import WifiTetheringIcon from '@mui/icons-material/WifiTethering';
import SubsystemCard from './RadarSubsystem';
import './RadarSubsystem.css';
import General from '../Servo/Components/ServoDashboard';
import Rf from '../RfReceiver/Rf';

const theme = createTheme();

const renderSubsystemContent = (name) => {
    switch (name) {
        case 'Servo':
            return <General />;
        case 'Transmitter':
            return <General />;
        case 'Receiver':
            return <Rf />;
        case 'Signal Processing':
            return <General />;
        case 'Antenna':
            return <General />;
        default:
            return null;
    }
};

function SubsystemPage() {
    const [selectedSubsystem, setSelectedSubsystem] = useState('');
    const [pressedCard, setPressedCard] = useState('');
    const [animationKey, setAnimationKey] = useState(0); // To re-trigger animation

    const handleCardClick = (name) => {
        const audio = new Audio(`${process.env.PUBLIC_URL}/button-305770.mp3`);
        audio.play();

        setSelectedSubsystem(name);
        setPressedCard(name);
        setAnimationKey(prev => prev + 1); // Increment key to trigger re-animation
    };

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <Box sx={{ display: 'flex', height: '100vh', backgroundColor: '' }}>
                {/* Left: Subsystem Cards */}
                <Box className="card-container">
                    <SubsystemCard
                        name="Servo"
                        color="#3f51b5"
                        onClick={() => handleCardClick('Servo')}
                        pressed={pressedCard === 'Servo'}
                    >
                        <div className="rotating-antenna" />
                    </SubsystemCard>
                    <SubsystemCard
                        name="Transmitter"
                        color="#00bcd4"
                        onClick={() => handleCardClick('Transmitter')}
                        pressed={pressedCard === 'Transmitter'}
                    >
                        <div className="emitting-waves" />
                    </SubsystemCard>
                    <SubsystemCard
                        name="Receiver"
                        color="#f44336"
                        onClick={() => handleCardClick('Receiver')}
                        pressed={pressedCard === 'Receiver'}
                    >
                        <div className="radar-needle" />
                    </SubsystemCard>
                    <SubsystemCard
                        name="RSP"
                        color="#673ab7"
                        onClick={() => handleCardClick('Signal Processing')}
                        pressed={pressedCard === 'Signal Processing'}
                    >
                        <MemoryIcon sx={{ fontSize: 60 }} />
                    </SubsystemCard>
                    <SubsystemCard
                        name="Antenna"
                        color="#4caf50"
                        onClick={() => handleCardClick('Antenna')}
                        pressed={pressedCard === 'Antenna'}
                    >
                        <WifiTetheringIcon sx={{ fontSize: 60 }} />
                    </SubsystemCard>
                </Box>

                {/* Right: Animated Content */}
                {selectedSubsystem && (
                    <Box
                        key={animationKey} // Reset component to re-trigger animation
                        className="right-box"
                        sx={{
                            flexGrow: 1,
                            p: 2,
                            position: 'relative',
                            animation: 'fadeInRight 0.5s ease',
                        }}
                    >
                        <IconButton
                            onClick={() => {
                                setSelectedSubsystem('');
                                setPressedCard('');
                            }}
                            sx={{
                                position: 'absolute',
                                top: 8,
                                right: 8,
                                color: 'grey.700',
                                '&:hover': {
                                    color: 'grey.900',
                                },
                            }}
                        >
                            <CloseIcon />
                        </IconButton>
                        <Typography variant="h5" gutterBottom>
                            {selectedSubsystem || 'Subsystem Info'}
                        </Typography>
                        {renderSubsystemContent(selectedSubsystem)}
                    </Box>
                )}
            </Box>
        </ThemeProvider>
    );
}

export default SubsystemPage;
