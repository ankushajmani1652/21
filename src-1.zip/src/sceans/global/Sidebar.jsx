
import { useState, useEffect } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme, useMediaQuery, Button } from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { tokens } from "../../theme";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import PowerSettingsNewIcon from "@mui/icons-material/PowerSettingsNew";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import SettingsInputAntennaIcon from "@mui/icons-material/SettingsInputAntenna";
import EngineeringIcon from "@mui/icons-material/Engineering";
import { useSocket } from "../../SocketContext";
import {
  WbSunny as SunIcon,
  Settings as SettingsIcon,
  FindInPage as FindInPageIcon,
} from "@mui/icons-material";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import { Event } from "@mui/icons-material";
import { AdminPanelSettings } from "@mui/icons-material";
import { PhotoCamera } from "@mui/icons-material";
import ReportIcon from "@mui/icons-material/Report";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import CrisisAlertIcon from "@mui/icons-material/CrisisAlert";
import RadarIcon from "@mui/icons-material/Radar";
import HealthAndSafetyIcon from "@mui/icons-material/HealthAndSafety";

import { useAuth } from "../../UserRegistration/AuthContext";
import SubsystemPage from "../../Radar_Systems/SubsystemPage";

const Sidebar = ({ powerStatus, setPowerStatus }) => {
  const { user } = useAuth(); // Accessing user data from the context
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [selected, setSelected] = useState("Dashboard");
  const [isServoDropdownOpen, setIsServoDropdownOpen] = useState(false);
  const [isCalibrationOpen, setIsCalibrationOpen] = useState(false);

  const socket = useSocket();
  const navigate = useNavigate();

  const isMobile = useMediaQuery("(max-width:768px)");


  useEffect(() => {
    if (!socket) {
      console.error("Socket is not yet initialized.");
      return;
    }

    socket.on("powerToggleResponse", (data) => {
      console.log("Power toggle response received:", data);
      setPowerStatus(data === "on");
    });

    return () => {
      socket.off("powerToggleResponse");
    };
  }, [setPowerStatus, socket]);

  const handlePowerOnClick = () => {
    if (!socket) {
      console.error("Socket not initialized.");
      return;
    }

    const newPowerState = !powerStatus ? "on" : "off";
    socket.emit("powertoggle", newPowerState);
    console.log("Sending Power Toggle:", newPowerState);
  };

  const Item = ({ title, to, icon }) => {
    const isSelected = selected === title || (title === "Servo" && powerStatus);



    useEffect(() => {
      setIsCollapsed(isMobile);
    }, [isMobile]);


    return (
      <MenuItem
        active={isSelected}
        style={{
          color: colors.grey[100],
        }}
        onClick={() => setSelected(title)}
        icon={icon}
      >
        <Typography
          style={{
            textShadow: isSelected
              ? `0 0 10px ${colors.primary[500]}, 0 0 20px ${colors.primary[500]}`
              : "none",
            color: isSelected ? colors.blueAccent[500] : colors.grey[100],
            fontFamily: "'Times New Roman', serif",
          }}
        >
          {title}
        </Typography>
        <Link to={to} />
      </MenuItem>
    );
  };

  useEffect(() => {
    if (powerStatus) {
      setSelected("Servo");
    }
  }, [powerStatus]);

  return (
    <Box
      sx={{
        height: "auto",
        "& .pro-sidebar-inner": {
          // background: `${colors.primary[400]} !important`,
          backgroundColor: "transparent !important",

        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "5px 35px 5px 20px !important",
        },
        "& .pro-inner-item:hover": {
          color: "#868dfb !important",
        },
        "& .pro-menu-item.active": {
          color: "#6870fa !important",
        },
      }}
    >
      <ProSidebar collapsed={isCollapsed} sx={{ flexGrow: 1, overflow: "hidden" }}>
        <Menu iconShape="square">
          {/* LOGO AND MENU ICON */}
          <MenuItem
            onClick={() => setIsCollapsed(!isCollapsed)}
            icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
            style={{
              margin: "10px 0 20px 0",
              color: colors.grey[100],
            }}
          >
            {!isCollapsed && (
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
              >
                <Typography
                  variant="h3"
                  color={colors.grey[100]}
                  fontFamily="'Times New Roman', serif"
                >
                  {user?.role === "superuser"
                    ? "Super User"
                    : user?.role === "normaluser"
                      ? "Normal User"
                      : "User"}
                </Typography>
                <IconButton onClick={() => setIsCollapsed(!isCollapsed)}>
                  <MenuOutlinedIcon />
                </IconButton>
              </Box>
            )}
          </MenuItem>

          {!isCollapsed && (
            <Box mb="25px">
              <Box textAlign="center">
                <Typography
                  variant="h2"
                  color={colors.grey[100]}
                  fontWeight="bold"
                  sx={{ m: "10px 0 0 0" }}
                  fontFamily="'Times New Roman', serif"
                >
                  Cloud Radar
                </Typography>
              </Box>
            </Box>
          )}

          <Box paddingLeft={isCollapsed ? undefined : "10%"}>
            {/* General and Running Data are visible for all users */}
            <Item title="General" to="/general" icon={<HomeOutlinedIcon />} />
            <Item
              title="Running Data"
              to="/RadarRunningData"
              icon={<RadarIcon />}
            />

            <Item
              title="Subsystem"
              to="/SubsystemPage"
              icon={<RadarIcon />}
            />

            {/* Additional menu items based on user role */}
            {user?.role === "superuser" && (
              <>
                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Radar Configuration
                  </Typography>
                )}
                <Item
                  title="Task Creation"
                  to="/TaskCreator"
                  icon={<ContactsOutlinedIcon />}
                />
                <Item
                  title="Task Scheduler"
                  to="/TaskSchedular"
                  icon={<Event />}
                />
                <Item title="Load Task" to="/LoadSchedular" icon={<Event />} />

                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Mode
                  </Typography>
                )}

                <Item
                  title="Schedular Mode"
                  to="/Parameter"
                  icon={<FindInPageIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
                <Item
                  title="Maintenance Mode"
                  to="/DefaultParamerer"
                  icon={<EngineeringIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
                {/* Additional menu items for Calibration */}
                <MenuItem
                  onClick={() => setIsCalibrationOpen(!isCalibrationOpen)}
                  style={{
                    color: colors.grey[100],
                  }}
                  icon={<ReceiptOutlinedIcon />}
                >
                  <Typography
                    sx={{
                      color: "black",
                      fontFamily: "'Times New Roman', serif",
                    }}
                  >
                    Calibration
                  </Typography>
                </MenuItem>
                {isCalibrationOpen && !isCollapsed && (
                  <Box paddingLeft="20%">
                    <Item
                      title="Sun"
                      to="/SunCalibration"
                      icon={<SunIcon />}
                      selected={selected}
                      setSelected={setSelected}
                    />
                    <Item
                      title="Sphare"
                      to="/SphareCalibration"
                      icon={<SettingsIcon />}
                      selected={selected}
                      setSelected={setSelected}
                    />
                    {/* Add more Calibration items here */}
                  </Box>
                )}
                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                  >
                    Display Products{" "}
                  </Typography>
                )}
                <Item
                  title="Real Time  "
                  to="/Calibration/Option3"
                  icon={<FindInPageIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
                <Item
                  title="Near Real Time "
                  to="/Calibration/Option3"
                  icon={<FindInPageIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />

                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Status
                  </Typography>
                )}
                <Item
                  title="Health Status  "
                  to="/RadarHealthStatus"
                  icon={<HealthAndSafetyIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
              </>
            )}

            {user?.role === "normaluser" && (
              <>
                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Radar Configuration
                  </Typography>
                )}
                <Item
                  title="Task Creation"
                  to="/TaskCreator"
                  icon={<ContactsOutlinedIcon />}
                />
                <Item
                  title="Task Scheduler"
                  to="/TaskSchedular"
                  icon={<Event />}
                />
                {/* <Item title="Load Task" to="/LoadSchedular" icon={<Event />} /> */}
                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Status
                  </Typography>
                )}
                <Item
                  title="Health Status  "
                  to="/RadarHealthStatus"
                  icon={<HealthAndSafetyIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
              </>
            )}

            {user?.role === "user" && (
              <>
                {!isCollapsed && (
                  <Typography
                    variant="h6"
                    color={colors.grey[300]}
                    sx={{ m: "15px 0 5px 20px" }}
                    fontFamily="'Times New Roman', serif"
                  >
                    Status
                  </Typography>
                )}
                <Item
                  title="Health Status  "
                  to="/RadarHealthStatus"
                  icon={<HealthAndSafetyIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
              </>
            )}

            {/* Logout Button */}
            <Button
              variant="contained"
              color="secondary"
              fullWidth
              sx={{
                borderRadius: "8px",
                marginTop: "30px",
                marginLeft: "-8px",
                background: `radial-gradient(circle at center, ${colors.redAccent[400]} 50%, ${colors.redAccent[500]} 100%)`,
                "&:hover": {
                  background: `radial-gradient(circle at center, ${colors.greenAccent[400]} 50%, ${colors.greenAccent[500]} 100%)`,
                },
                fontFamily: "'Times New Roman', serif",
              }}
            >
              Logout
            </Button>
          </Box>
        </Menu>
      </ProSidebar>
    </Box>
  );
};

export default Sidebar;





// import { Box, IconButton, Typography, useTheme, useMediaQuery } from "@mui/material";
// import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
// import { useEffect, useState } from "react";
// import { tokens } from "../../theme";
// import "react-pro-sidebar/dist/css/styles.css";
// import { Link } from "react-router-dom";
// import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
// import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
// import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
// import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
// import FactoryIcon from '@mui/icons-material/Factory';
// import AssessmentIcon from '@mui/icons-material/Assessment';
// import CalibrationIcon from '@mui/icons-material/BuildCircle';
// import EngineeringIcon from '@mui/icons-material/Engineering';

// const Item = ({ title, to, icon, selected, setSelected }) => {
//   const theme = useTheme();
//   const colors = tokens(theme.palette.mode);
//   return (
//     <MenuItem
//       active={selected === title}
//       style={{ color: colors.grey[100] }}
//       onClick={() => setSelected(title)}
//       icon={icon}
//     >
//       <Typography>{title}</Typography>
//       <Link to={to} />
//     </MenuItem>
//   );
// };

// const Sidebar = () => {
//   const theme = useTheme();
//   const colors = tokens(theme.palette.mode);
//   const isMobile = useMediaQuery('(max-width: 768px)');

//   const [isCollapsed, setIsCollapsed] = useState(isMobile);
//   const [selected, setSelected] = useState("Dashboard");

//   useEffect(() => {
//     setIsCollapsed(isMobile);
//   }, [isMobile]);

//   // Fallback user info
//   const user = {
//     username: "User",
//     role: "Admin",
//   };

//   return (
//     <Box
//       sx={{
//         "& .pro-sidebar-inner": {
//           background: `${colors.primary[400]} !important`,
//         },
//         "& .pro-icon-wrapper": {
//           backgroundColor: "transparent !important",
//         },
//         "& .pro-inner-item": {
//           padding: "5px 35px 5px 20px !important",
//         },
//         "& .pro-inner-item:hover": {
//           color: "#868dfb !important",
//         },
//         "& .pro-menu-item.active": {
//           color: "#6870fa !important",
//         },
//       }}
//     >
//       <ProSidebar collapsed={isCollapsed}>
//         <Menu iconShape="square">
//           {/* Toggle Button */}
//           <MenuItem
//             onClick={() => setIsCollapsed(!isCollapsed)}
//             icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
//             style={{ margin: "10px 0 20px 0", color: colors.grey[100] }}
//           >
//             {!isCollapsed && (
//               <Box
//                 display="flex"
//                 justifyContent="space-between"
//                 alignItems="center"
//                 ml="15px"
//               >
//                 <Typography variant="h3" color={colors.grey[100]}>
//                   Admin Panel
//                 </Typography>
//                 <IconButton onClick={() => setIsCollapsed(!isCollapsed)}>
//                   <MenuOutlinedIcon />
//                 </IconButton>
//               </Box>
//             )}
//           </MenuItem>

//           {/* User Info */}
//           {!isCollapsed && (
//             <Box mb="25px">
//               <Box display="flex" justifyContent="center" alignItems="center">
//                 <img
//                   alt="profile-user"
//                   width="100px"
//                   height="100px"
//                   src={`https://via.placeholder.com/100`}
//                   style={{ cursor: "pointer", borderRadius: "50%" }}
//                 />
//               </Box>
//               <Box textAlign="center">
//                 <Typography
//                   variant="h2"
//                   color={colors.grey[100]}
//                   fontWeight="bold"
//                   sx={{ m: "10px 0 0 0" }}
//                 >
//                   {user.username}
//                 </Typography>
//                 <Typography variant="h5" color={colors.greenAccent[500]}>
//                   {user.role}
//                 </Typography>
//               </Box>
//             </Box>
//           )}

//           {/* Navigation Items */}
//           <Box paddingLeft={isCollapsed ? undefined : "10%"}>
//             <Item
//               title="Dashboard"
//               to="/dashboard"
//               icon={<HomeOutlinedIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="User Management"
//               to="/team"
//               icon={<PeopleOutlinedIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="Factory Monitoring"
//               to="/factory"
//               icon={<FactoryIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="Reports"
//               to="/reports"
//               icon={<AssessmentIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="Calibration"
//               to="/calibration"
//               icon={<CalibrationIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="Engineers"
//               to="/engineers"
//               icon={<EngineeringIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//             <Item
//               title="Contacts"
//               to="/contacts"
//               icon={<ContactsOutlinedIcon />}
//               selected={selected}
//               setSelected={setSelected}
//             />
//           </Box>
//         </Menu>
//       </ProSidebar>
//     </Box>
//   );
// };

// export default Sidebar;

