// import React, { useState } from 'react';
// import { TextField, Slider, Box, Checkbox, FormControlLabel, Grid, Typography, Button } from '@mui/material';

// const Waveform = () => {
//   const [formData, setFormData] = useState({
//     // Signal Generators (1, 2, 3)
//     sigGen1: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
//     sigGen2: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
//     sigGen3: { startAmp: '', stopAmp: '', stepAmp: '', startFreq: '', stopFreq: '', stepFreq: '', mod: false, trigger: false },
//     // Radar Constants
//     radarConstants: { IF1H: '', IF2H: '', IF3H: '', IF1V: '', IF2V: '', IF3V: '' },
//     rangeGates: { IF1Start: '', IF1Stop: '', IF2Start: '', IF2Stop: '', IF3Start: '', IF3Stop: '' },
//   });

//   // Handle input change
//   const handleInputChange = (event, section, key) => {
//     const value = event.target.value;
//     setFormData((prevState) => ({
//       ...prevState,
//       [section]: { ...prevState[section], [key]: value },
//     }));
//   };

//   // Handle checkbox change (for modulation and trigger)
//   const handleCheckboxChange = (event, section, key) => {
//     const checked = event.target.checked;
//     setFormData((prevState) => ({
//       ...prevState,
//       [section]: { ...prevState[section], [key]: checked },
//     }));
//   };

//   // Submit form data
//   const handleSubmit = () => {
//     console.log('Form Data Submitted:', formData);
//     // Handle form submission logic here
//   };

//   return (
//     <Box p={3} sx={{backgroundColor:"white", borderRadius:"20px"}}>
//       <Typography variant="h4" gutterBottom>
//         Radar Configuration
//       </Typography>
      
//       {/* Signal Generators Section */}
//       <Grid container spacing={3}>
//         {[1, 2, 3].map((index) => (
//           <Grid item xs={12} md={4} key={`sigGen${index}`}>
//             <Typography variant="h6" gutterBottom>
//               Signal Generator {index}
//             </Typography>

//             <TextField
//               fullWidth
//               label={`Pulsed / CW`}
//               value={formData[`sigGen${index}`].startAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
//               margin="normal"
//             />
//              <TextField
//               fullWidth
//               label={`Power Fixed/Sweep`}
//               value={formData[`sigGen${index}`].startAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
//               margin="normal"
//             />

// <TextField
//               fullWidth
//               label={`Frequency Fixed/Sweep`}
//               value={formData[`sigGen${index}`].startAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
//               margin="normal"
//             />
//              <TextField
//               fullWidth
//               label={`Power Inc/Dec`}
//               value={formData[`sigGen${index}`].startAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
//               margin="normal"
//             />

//             <TextField
//               fullWidth
//               label={`Start Amplitude ${index}`}
//               value={formData[`sigGen${index}`].startAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startAmp')}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label={`Stop Amplitude ${index}`}
//               value={formData[`sigGen${index}`].stopAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stopAmp')}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label={`Step Amplitude ${index}`}
//               value={formData[`sigGen${index}`].stepAmp}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stepAmp')}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label={`Start Frequency ${index}`}
//               value={formData[`sigGen${index}`].startFreq}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'startFreq')}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label={`Stop Frequency ${index}`}
//               value={formData[`sigGen${index}`].stopFreq}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stopFreq')}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label={`Step Frequency ${index}`}
//               value={formData[`sigGen${index}`].stepFreq}
//               onChange={(e) => handleInputChange(e, `sigGen${index}`, 'stepFreq')}
//               margin="normal"
//             />
//             <FormControlLabel
//               control={
//                 <Checkbox
//                   checked={formData[`sigGen${index}`].mod}
//                   onChange={(e) => handleCheckboxChange(e, `sigGen${index}`, 'mod')}
//                 />
//               }
//               label={`Modulation ${index}`}
//             />
//             <FormControlLabel
//               control={
//                 <Checkbox
//                   checked={formData[`sigGen${index}`].trigger}
//                   onChange={(e) => handleCheckboxChange(e, `sigGen${index}`, 'trigger')}
//                 />
//               }
//               label={`Trigger ${index}`}
//             />
//           </Grid>
//         ))}
//       </Grid>

//       {/* Radar Constants Section */}
//       <Typography variant="h6" gutterBottom>
//         Radar Constants
//       </Typography>
//       <Grid container spacing={3}>
//         {['IF1H', 'IF2H', 'IF3H', 'IF1V', 'IF2V', 'IF3V'].map((key) => (
//           <Grid item xs={12} md={4} key={key}>
//             <TextField
//               fullWidth
//               label={`Radar Constant ${key}`}
//               value={formData.radarConstants[key]}
//               onChange={(e) => handleInputChange(e, 'radarConstants', key)}
//               margin="normal"
//             />
//           </Grid>
//         ))}
//       </Grid>

//       {/* Range Gates Section */}
//       <Typography variant="h6" gutterBottom>
//         Range Gates
//       </Typography>
//       <Grid container spacing={3}>
//         {['IF1Start', 'IF1Stop', 'IF2Start', 'IF2Stop', 'IF3Start', 'IF3Stop'].map((key) => (
//           <Grid item xs={12} md={4} key={key}>
//             <TextField
//               fullWidth
//               label={`Range Gate ${key}`}
//               value={formData.rangeGates[key]}
//               onChange={(e) => handleInputChange(e, 'rangeGates', key)}
//               margin="normal"
//             />
//           </Grid>
//         ))}
//       </Grid>

//       {/* Submit Button */}
//       <Box mt={3}>
//         <Button variant="contained" color="primary" onClick={handleSubmit}>
//           Submit Configuration
//         </Button>
//       </Box>
//     </Box>
//   );
// };

// export default Waveform;

import React, { useState } from 'react';
import { TextField, Button, Checkbox, FormControlLabel, Slider, Select, MenuItem, InputLabel, FormControl, Grid } from '@mui/material';

const Waveform = () => {
  const [formData, setFormData] = useState({
    OperatingCenterFrequency: '',
    OperatingRF1Frequency: '',
    OperatingRF2Frequency: '',
    OperatingRF3Frequency: '',
    PulseWidthLong: '',
    PulseWidthMiddle: '',
    PulseWidthShort: '',
    RF1GuardDelay: '',
    RF1andRF2Delay: '',
    fRF2andRF3Delay: '',
    RF3GuardDelay: '',
    DecimationRate: '',
    AmbiguityResolverOnOff: false,
    PRF1: '',
    PRF2: '',
    PRFRatio: '',
    WaveformType: '',
    Pulse1WaveformType: '',
    Pulse2WaveformType: '',
    Pulse3WaveformType: '',
    SZCodeEnableDisable: false,
    SZCodePhaseRF1: '',
    SZCodePhaseRF2: '',
    SZCodePhaseRF3: '',
    NLFMWidthPulse1: '',
    NLFMWidthPulse2: '',
    NLFMWidthPulse3: '',
    Baud: '',
    BaudLength: '',
    ComplimentaryCodeA: Array(8).fill(''),
    ComplimentaryCodeAbar: Array(8).fill(''),
    ComplimentaryCodeB: Array(8).fill(''),
    ComplimentaryCodeBbar: Array(8).fill(''),
    StarttimePRF1CntlPulse: Array(20).fill(''),
    StoptimePRF1CntlPulse: Array(20).fill(''),
    StarttimePRF2CntlPulse: Array(20).fill(''),
    StoptimePRF2CntlPulse: Array(20).fill(''),
    DigitalCtnlOnOff: Array(10).fill(false),
    DOStartDeg: Array(10).fill(''),
    DOStoptDeg: Array(10).fill('')
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <Grid item xs={12} container spacing={2}>
          <Grid item xs={6}>
            <TextField
              label="Operating Center Frequency"
              variant="outlined"
              fullWidth
              name="m_fOperatingCenterFrequency"
              value={formData.OperatingCenterFrequency}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              label="Operating RF1 Frequency"
              variant="outlined"
              fullWidth
              name="m_fOperatingRF1Frequency"
              value={formData.OperatingRF1Frequency}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              label="Operating RF2 Frequency"
              variant="outlined"
              fullWidth
              name="m_fOperatingRF2Frequency"
              value={formData.OperatingRF2Frequency}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              label="Operating RF3 Frequency"
              variant="outlined"
              fullWidth
              name="OperatingRF3Frequency"
              value={formData.OperatingRF3Frequency}
              onChange={handleChange}
            />
          </Grid>
          {/* Repeat similar Grid/TextField components for the other fields */}
          <Grid item xs={6}>
            <TextField
              label="Pulse Width Long"
              variant="outlined"
              fullWidth
              name="PulseWidthLong"
              value={formData.PulseWidthLong}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              label="Pulse Width Middle"
              variant="outlined"
              fullWidth
              name="PulseWidthMiddle"
              value={formData.PulseWidthMiddle}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              label="Pulse Width Short"
              variant="outlined"
              fullWidth
              name="PulseWidthShort"
              value={formData.PulseWidthShort}
              onChange={handleChange}
            />
          </Grid>
          
          {/* Checkbox example for m_usAmbiguityResolverOnOff */}
          <Grid item xs={6}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={formData.AmbiguityResolverOnOff}
                  onChange={handleCheckboxChange}
                  name="m_usAmbiguityResolverOnOff"
                />
              }
              label="Ambiguity Resolver On/Off"
            />
          </Grid>

          {/* Dropdown example for m_ucWaveformType */}
          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Waveform Type</InputLabel>
              <Select
                name="m_ucWaveformType"
                value={formData.WaveformType}
                onChange={handleChange}
                label="Waveform Type"
              >
                <MenuItem value="1">Uncoded</MenuItem>
                <MenuItem value="2">NLFM</MenuItem>
                <MenuItem value="3">LFM</MenuItem>
                <MenuItem value="3">Complimentary code</MenuItem>
                <MenuItem value="3">Bi-phase code</MenuItem>
                <MenuItem value="3">User defined code</MenuItem>

              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Pulse 1 Waveform Type</InputLabel>
              <Select
                name="m_ucWaveformType"
                value={formData.WaveformType}
                onChange={handleChange}
                label="Waveform Type"
              >
                <MenuItem value="1">Uncoded</MenuItem>
                <MenuItem value="2">NLFM</MenuItem>
                <MenuItem value="3">LFM</MenuItem>
                <MenuItem value="3">Complimentary code</MenuItem>
                <MenuItem value="3">Bi-phase code</MenuItem>
                <MenuItem value="3">User defined code</MenuItem>

              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Pulse 2 Waveform Type</InputLabel>
              <Select
                name="m_ucWaveformType"
                value={formData.WaveformType}
                onChange={handleChange}
                label="Waveform Type"
              >
                <MenuItem value="1">Uncoded</MenuItem>
                <MenuItem value="2">NLFM</MenuItem>
                <MenuItem value="3">LFM</MenuItem>
                <MenuItem value="3">Complimentary code</MenuItem>
                <MenuItem value="3">Bi-phase code</MenuItem>
                <MenuItem value="3">User defined code</MenuItem>

              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Pulse 2 Waveform Type</InputLabel>
              <Select
                name="m_ucWaveformType"
                value={formData.WaveformType}
                onChange={handleChange}
                label="Waveform Type"
              >
                <MenuItem value="1">Uncoded</MenuItem>
                <MenuItem value="2">NLFM</MenuItem>
                <MenuItem value="3">LFM</MenuItem>
                <MenuItem value="3">Complimentary code</MenuItem>
                <MenuItem value="3">Bi-phase code</MenuItem>
                <MenuItem value="3">User defined code</MenuItem>

              </Select>
            </FormControl>
          </Grid>
          

          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary">Submit</Button>
          </Grid>
        </Grid>
      </form>
    </div>
  );
};

export default Waveform;


