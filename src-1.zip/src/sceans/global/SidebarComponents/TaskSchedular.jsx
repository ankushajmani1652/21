import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Typography,
  Grid,
  Card,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";

const TaskSchedular = () => {
  // State to hold the tasks
  const [tasks, setTasks] = useState([
    {
      id: 1,
      taskName: "Task 1",
      status: "scheduled",
    },
    {
      id: 2,
      taskName: "Task 2",
      status: "completed",
    },
    {
      id: 3,
      taskName: "Task 3",
      status: "scheduled",
    },
  ]);

  // State for the task creation form
  const [newTaskName, setNewTaskName] = useState("");
  const [newTaskStatus, setNewTaskStatus] = useState("scheduled");

  // State for opening/closing the Dialog
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);

  const [schedulerName, setSchedulerName] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);

  // State to hold the scheduled tasks
  const [scheduleList, setScheduleList] = useState([]);

  // Function to add a new task
  const handleAddTask = () => {
    if (newTaskName.trim()) {
      const newTask = {
        id: tasks.length + 1, // Generating a unique id
        taskName: newTaskName,
        status: newTaskStatus,
      };

      setTasks([...tasks, newTask]); // Add the new task to the list
      setNewTaskName(""); // Reset the input fields
      setNewTaskStatus("scheduled");
    } else {
      alert("Please enter a task name");
    }
  };

  // Function to update task status
  const updateTaskStatus = (taskId, status) => {
    setTasks(
      tasks.map((task) => (task.id === taskId ? { ...task, status } : task))
    );
  };

  // Function to delete a task
  const handleDeleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };

  // Function to handle opening the schedule popup (dialog)
  const handleScheduleClick = (task) => {
    setSelectedTask(task); // Set the selected task for scheduling
    setOpenDialog(true); // Open the dialog
  };

  // Function to close the dialog
  const handleCloseDialog = () => {
    setOpenDialog(false); // Close the dialog
    setSelectedTask(null); // Reset the selected task
  };

  // Function to add a scheduled task
  const handleAddSchedule = () => {
    if (schedulerName.trim() && selectedDate && selectedTime) {
      const newSchedule = {
        id: scheduleList.length + 1,
        taskName: selectedTask?.taskName,
        schedulerName,
        date: selectedDate,
        time: selectedTime,
      };

      setScheduleList([...scheduleList, newSchedule]); // Add to the schedule list
      setSchedulerName(""); // Reset input fields
      setSelectedDate(null); // Reset selected date
      setSelectedTime(null); // Reset selected time
      handleCloseDialog(); // Close the dialog after scheduling
    } else {
      alert("Please fill all the fields to schedule the task.");
    }
  };

  return (
    <Box sx={{ padding: 2 }}>
       <Typography variant="h3" gutterBottom>
        Task Scheduler
      </Typography>

      {/*<Box sx={{ marginBottom: 2 }}>
        <TextField
          label="Task Name"
          variant="outlined"
          fullWidth
          value={newTaskName}
          onChange={(e) => setNewTaskName(e.target.value)}
        />
        <Button
          variant="contained"
          color="primary"
          sx={{ marginTop: 2 }}
          onClick={handleAddTask}
        >
          Add Task
        </Button>
      </Box> */}

      {/* Main Grid Layout */}
      <Grid container spacing={2}>
        {/* Task List Section */}
        <Grid item xs={12} md={6}>
          <Card sx={{ padding: 3 }}>
            <Typography variant="h6" gutterBottom>
              Task List
            </Typography>
            <Grid container spacing={2}>
              {tasks.map((task) => (
                <Grid item xs={12} key={task.id}>
                  <Card
                    variant="outlined"
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: 2,
                      backgroundColor:
                        task.status === "completed"
                          ? "#e8f5e9"
                          : task.status === "scheduled"
                          ? "#fffde7"
                          : "#ffebee",
                      borderLeft: `4px solid ${
                        task.status === "completed"
                          ? "#66bb6a"
                          : task.status === "scheduled"
                          ? "#fbc02d"
                          : "#d32f2f"
                      }`,
                    }}
                  >
                    <div>
                      <Typography variant="h6" color="black" fontWeight="bold">
                        {task.taskName}
                      </Typography>
                      <Typography variant="body2" color="black">
                        {new Date().toLocaleDateString()}{" "}
                        {new Date().toLocaleTimeString()}
                      </Typography>
                      <Typography
                        variant="body2"
                        sx={{ fontWeight: "bold", color: "#616161" }}
                      >
                        Status:{" "}
                        <span
                          style={{
                            color:
                              task.status === "completed"
                                ? "#388e3c"
                                : task.status === "scheduled"
                                ? "#fbc02d"
                                : "#d32f2f",
                          }}
                        >
                          {task.status}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Button
                        size="small"
                        variant="contained"
                        color="primary"
                        sx={{ marginRight: 1 }}
                        onClick={() => handleScheduleClick(task)} // Pass dynamic task to open dialog
                      >
                        Schedule
                      </Button>

                      <Button
                        size="small"
                        variant="contained"
                        color="secondary"
                        sx={{ marginRight: 1 }}
                        onClick={() => updateTaskStatus(task.id, "completed")}
                      >
                        Complete
                      </Button>

                      {/* Delete Icon */}
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => handleDeleteTask(task.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </div>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Card>
        </Grid>

        {/* Schedule List Section */}
        <Grid item xs={12} md={6}>
  <Card sx={{ padding: 3, boxShadow: 3 }}>
    <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
      Schedule List
    </Typography>
    <Grid container spacing={2}>
      {scheduleList.map((schedule) => (
        <Grid item xs={12} key={schedule.id}>
          <Card
            variant="outlined"
            sx={{
              padding: 2,
              borderRadius: 2,
              boxShadow: 1,
              transition: 'transform 0.3s ease-in-out',
              '&:hover': {
                // transform: 'scale(1.03)', // Hover effect for interactive feel
                boxShadow: 3,
              },
              backgroundColor: '#f9f9f9', // Light background
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#333' }}>
              {schedule.taskName}
            </Typography>
            <Typography variant="body2" sx={{ color: '#555' }}>
              <strong>Scheduled by:</strong> {schedule.schedulerName}
            </Typography>
            <Typography variant="body2" sx={{ color: '#555' }}>
              <strong>Date:</strong> {schedule.date.toLocaleDateString()} |{' '}
              <strong>Time:</strong> {schedule.time.toLocaleTimeString()}
            </Typography>
          </Card>
        </Grid>
      ))}
    </Grid>
  </Card>
</Grid>

      </Grid>

      {/* Scheduler Dialog Popup */}
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Schedule Task</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Do you want to schedule "{selectedTask?.taskName}" task now?
          </Typography>

          <TextField
            label="Scheduler Name"
            variant="outlined"
            fullWidth
            value={schedulerName}
            onChange={(e) => setSchedulerName(e.target.value)}
            sx={{ marginTop: 2 }}
          />

          {/* Add Date and Time pickers */}
          <TextField
            label=""
            type="date"
            fullWidth
            value={selectedDate ? selectedDate.toISOString().split("T")[0] : ""}
            onChange={(e) => setSelectedDate(new Date(e.target.value))}
            sx={{ marginTop: 2 }}
          />

          <TextField
            label=""
            type="time"
            fullWidth
            value={
              selectedTime
                ? selectedTime.toISOString().split("T")[1].slice(0, 5)
                : ""
            }
            onChange={(e) =>
              setSelectedTime(new Date(`1970-01-01T${e.target.value}:00`))
            }
            sx={{ marginTop: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Cancel
          </Button>
          <Button onClick={handleAddSchedule} color="primary">
            Schedule
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TaskSchedular;
