import React, { useState, useEffect, useContext } from "react";
import {
  Box,
  Button,
  Typography,
  Menu,
  MenuItem,
  IconButton,
  Popover,
  Divider,
  List, ListItem, ListItemText,
  useTheme,
  Avatar
} from "@mui/material";
import { styled } from "@mui/system";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { tokens } from "../../theme"; // Ensure you import the tokens
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import SearchIcon from "@mui/icons-material/Search";
import { ColorModeContext } from "../../theme";




const NavbarContainer = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
  padding: "10px 20px",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  borderRadius: "8px",
  zIndex: 1, // Ensure it stays above other components
}));

const Logo = styled("img")({
  height: "40px", // Adjust the height of the logo as necessary
  width: "auto", // Maintain aspect ratio
  display: "block", // Ensure the logo is block-level for better alignment
});

// const Topbar = () => {
//   const theme = useTheme();
//   const colors = tokens(theme.palette.mode); // Define colors using tokens
//   const colorMode = useContext(ColorModeContext);

//   // State to handle dialog open/close
//   const [openDialog, setOpenDialog] = useState(null);

//   // State for toggling power button
//   const [isPowerOn, setIsPowerOn] = useState(true);

//   // State for current time
//   const [currentTime, setCurrentTime] = useState("");

//   // State for managing mode dropdown
//   const [anchorEl, setAnchorEl] = useState(null);
//   const [selectedMode, setSelectedMode] = useState("Real-Time"); // Default mode
//   const [isNotificationOpen, setIsNotificationOpen] = useState(false);
//   const [notifications] = useState([
//       { type: "info", message: "All Subsystem Started" },
//       { type: "warning", message: "Servo Stop Working" },
//       { type: "success", message: "System update completed" },
//   ]);

//   useEffect(() => {
//     const updateTime = () => {
//       const date = new Date();
//       const formattedTime = date.toLocaleTimeString([], {
//         hour: "2-digit",
//         minute: "2-digit",
//         second: "2-digit",
//       });
//       const formattedDate = date.toLocaleDateString([], {
//         weekday: "long",
//         year: "numeric",
//         month: "long",
//         day: "numeric",
//       });
//       setCurrentTime(`${formattedDate} | ${formattedTime}`);
//     };

//     // Update the time every second
//     const intervalId = setInterval(updateTime, 1000);

//     // Clean up the interval on component unmount
//     return () => clearInterval(intervalId);
//   }, []);

//   const handleOpenDialog = (dialogType) => {
//     setOpenDialog(dialogType);
//   };

//   const handleCloseDialog = () => {
//     setOpenDialog(null);
//   };

//   const handlePowerToggle = () => {
//     setIsPowerOn((prev) => !prev);
//   };

//   const handleModeClick = (event) => {
//     setAnchorEl(event.currentTarget); // Open dropdown when button is clicked
//   };

//   const handleModeClose = (mode) => {
//     setSelectedMode(mode);
//     setAnchorEl(null); // Close dropdown after selecting mode
//   };

//   const handleNotificationClick = (event) => {
//     setAnchorEl(event.currentTarget);
//     setIsNotificationOpen(true);
// };

// const handleNotificationClose = () => {
//     setIsNotificationOpen(false);
// };

// const getIconForType = (type) => {
//     switch (type) {
//         case "info":
//             return <CheckCircleOutlineIcon style={{ color: "#4caf50" }} />;
//         case "warning":
//             return <WarningAmberIcon style={{ color: "#ff9800" }} />;
//         case "error":
//             return <ErrorOutlineIcon style={{ color: "#f44336" }} />;
//         default:
//             return <CheckCircleOutlineIcon style={{ color: "#4caf50" }} />;
//     }
// };


//   return (
//     <Box>
//       <NavbarContainer>
//         {/* Left Logo */}
//         <Box display="flex" alignItems="center">
//           <Logo src="/isro.png" alt="Left Logo" />
//         </Box>

//         {/* Time and Date */}
//         <Box display="flex" alignItems="center">
//           <Typography variant="h6" sx={{ color: "#f47216", fontWeight: "bold" ,}}>
//             {currentTime}
//           </Typography>
//         </Box>
        
       

      

//         <Box display="flex" justifyContent="space-between" p={2}>
            

//             {/* ICONS AND ADMIN CONTROLS */}
//             <Box display="flex" alignItems="center">
//                 {/* Dark Mode Toggle */}
//                 {/* <IconButton onClick={colorMode.toggleColorMode}>
//                     {theme.palette.mode === "dark" ? <DarkModeOutlinedIcon /> : <LightModeOutlinedIcon />}
//                 </IconButton> */}

//                 {/* Notification Button */}
               

//                 {/* Notification Popover */}
//                 {/* <Popover
//                     open={isNotificationOpen}
//                     anchorEl={anchorEl}
//                     onClose={handleNotificationClose}
//                     anchorOrigin={{
//                         vertical: "bottom",
//                         horizontal: "center",
//                     }}
//                     transformOrigin={{
//                         vertical: "top",
//                         horizontal: "center",
//                     }}
//                 >
//                     <Box sx={{ width: 300, p: 2, borderRadius: 2, boxShadow: 3, backgroundColor: theme.palette.background.paper }}>
//                         <Typography variant="h6" sx={{ mb: 1, fontWeight: 600, color: theme.palette.text.primary }}>
//                             Notifications
//                         </Typography>
//                         <Divider sx={{ mb: 1 }} />
//                         {notifications.length > 0 ? (
//                             <List sx={{ maxHeight: 300, overflowY: "auto" }}>
//                                 {notifications.map((notification, index) => (
//                                     <ListItem
//                                         key={index}
//                                         sx={{
//                                             padding: "10px",
//                                             borderRadius: "8px",
//                                             "&:hover": { backgroundColor: "#8c8b8b" },
//                                         }}
//                                     >
//                                         <Avatar sx={{ mr: 1 }}>{getIconForType(notification.type)}</Avatar>
//                                         <ListItemText
//                                             primary={notification.message}
//                                             primaryTypographyProps={{
//                                                 style: {
//                                                     color: theme.palette.text.primary, // Ensures text color is visible
//                                                 },
//                                             }}
//                                         />
//                                     </ListItem>
//                                 ))}
//                             </List>
//                         ) : (
//                             <Typography color={theme.palette.text.primary}>No new notifications</Typography>
//                         )}
//                     </Box>
//                 </Popover> */}

//                 {/* Admin Controls */}
//                 {/* <IconButton>
//                     <SettingsOutlinedIcon />
//                 </IconButton>
//                 <IconButton>
//                     <PersonOutlinedIcon />
//                 </IconButton> */}


//             </Box>
//         </Box>

//   {/* Right Logo */}
//   <Box display="flex" alignItems="center">
//           <Logo src="ampl.png" alt="Right Logo" />
//         </Box>
//       </NavbarContainer>

//       {/* Dialogs for each Navbar option */}
//     </Box>
//   );
// };


const Topbar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);
  
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const date = new Date();
      const formattedTime = date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
      const formattedDate = date.toLocaleDateString([], {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });
      setCurrentTime(`${formattedDate} | ${formattedTime}`);
    };

    const intervalId = setInterval(updateTime, 1000);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <Box>
      <NavbarContainer>


      <Box display="flex" alignItems="center">
          <Logo src="/isro.png" alt="Left Logo" />
         </Box>

         {/* Time and Date */}
         <Box display="flex" alignItems="center">
          <Typography variant="h6" sx={{ color: "#f47216", fontWeight: "bold" ,}}>
            {currentTime}
          </Typography>
        </Box>
        {/* Logo Section */}
        <Box display="flex" alignItems="center" gap={2}>
          {/* <Logo src="/isro.png" alt="Left Logo" /> */}


          {/* Vertical Line */}
          {/* <Box sx={{
            width: "2px", 
            height: "25px", 
            backgroundColor: "#888", 
            borderRadius: "1px"
          }} /> */}
          <Logo src="/ampl.png" alt="Right Logo" />
        </Box>

        {/* Time and Date */}
        
      </NavbarContainer>
    </Box>
  );
};


export default Topbar;
