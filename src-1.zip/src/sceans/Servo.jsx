import React, { useState } from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Logo from "@mui/icons-material/AccountCircle";
import { useNavigate } from "react-router-dom";
import PowerButton from "../subsystem/ServoSubsystem/powerButton";
import RadarLoader from "../subsystem/RadarLoader/RadarLoader";
import RadarScanCarousel from "../ServoInformation/Servocarousel/RadarScanPage";
import RadarBox from "../ServoInformation/Servocarousel/RadarModeBox";
import RadarCameraView from "../subsystem/Camera/RadarCameraView";
import ServoResponse from "../ServoInformation/ServoResponse/ServoResponse";
import Appp from "../subsystem/ServoSubsystem/RadarScanPage";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";
import BuildIcon from "@mui/icons-material/Build";
import { keyframes, styled } from "@mui/system";
import SettingsInputComponentIcon from "@mui/icons-material/SettingsInputComponent";
import CameraIcon from "@mui/icons-material/Camera";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import StopCircleIcon from "@mui/icons-material/StopCircle";
import SettingsBackupRestoreIcon from "@mui/icons-material/SettingsBackupRestore";
import Bias_Factory_Setting from "../ServoInformation/Bias_Factory_Setting/Bias_Factory_Setting";
// Component for each box
const DataBox = ({ shape, title, color, content, children, onClick }) => {
  return (
    <Paper
      elevation={3}
      sx={{
        padding: 2,
        borderRadius: 2,
        textAlign: "center",
        backgroundImage: color?.includes("gradient") ? color : undefined, // Apply gradient
        backgroundColor: color?.includes("gradient")
          ? undefined
          : color || "#f9f9f9",
        width: "100%",
        height: shape === "square" ? "350px" : "auto",
        minHeight: shape === "square" ? "350px" : "auto",
        maxWidth: shape === "rectangle" ? "600px" : "auto",
        minHeight: shape === "rectangle" ? "300px" : "auto",
        maxHeight: shape === "rectangle" ? "300px" : "auto",

        overflow: "hidden",
        cursor: onClick ? "pointer" : "default", // Pointer cursor if onClick is provided
      }}
      onClick={onClick}
    >
      <Typography variant="h4" color="black" sx={{ fontWeight: "bold" }}>
        {title}
      </Typography>
      <Typography
        variant="body1"
        color="blue"
        sx={{
          animation: "fadeIn 2s ease-in-out", // Add animation here
          "@keyframes fadeIn": {
            "0%": { opacity: 0 },
            "100%": { opacity: 1 },
          },
        }}
      >
        {content}
      </Typography>

      {/* If there are children (nested boxes), render them */}
      {children}
    </Paper>
  );
};

const Servo = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  // Handle dialog open and close
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedData, setSelectedData] = useState("");

  const [openDialog, setOpenDialog] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [openDialogBias, setOpenDialogBias] = useState(false);

  const handleOpenDialogBias = () => {
    setOpenDialogBias(true);
  };

  const handleCloseDialogBias = () => {
    setOpenDialogBias(false);
  };

  const handleScanClick = (scanType) => {
    if (scanType === "volume-azimuth") {
      navigate("/Volume_AzimuthScan");
    } else if (scanType === "elevation") {
      navigate("/ElevationScan");
    } else if (scanType === "zenith") {
      navigate("/ZenithScan");
    }
  };

  const handleModeClick = (modeType) => {
    if (modeType === "scheduler") {
      navigate("/SchedulerMode");
    } else if (modeType === "calibration") {
      navigate("/CalibrationMode");
    }
  };

  const handleClick = () => {
    setIsAnimating(true);
    // After the animation finishes, open the dialog
    setTimeout(() => {
      setIsAnimating(false);
      setOpenDialog(true);
    }, 1000); // Adjust time to match the animation duration
  };

  const [openCylinderPopup, setOpenCylinderPopup] = useState(false);

  const handleOpenCylinderPopup = () => setOpenCylinderPopup(true);
  const handleCloseCylinderPopup = () => setOpenCylinderPopup(false);

  const [isDialogOpen, setDialogOpen] = useState(false);
  const handleDialogOpen = () => {
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
  };

  const handleModeSelection = (mode) => {
    console.log(`Selected mode: ${mode}`);
    setDialogOpen(false);
  };
  const bounce = keyframes`
  0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-10px); }
  60% { transform: translateY(-5px); }
`;
  const AnimatedBox = styled(Box)`
    &:hover {
      animation: ${bounce} 1s;
    }
  `;
  const handleOpenn = (dataType) => {
    setSelectedData(dataType); // Set the type of data to display (Azimuth or Elevation)
    setOpen(true); // Open the dialog
  };

  return (
    <div>
      {/* Top Row: AppBar with logo and Power ON/OFF button */}
      <AppBar
        position="static"
        sx={{
          backgroundImage:
            "linear-gradient(135deg,rgb(14, 30, 56) 30%, #2A5298 50%,rgb(124, 144, 182) 80%)",
        }}
      >
        <Toolbar>
          {/* Logo on the left */}
          <Logo sx={{ fontSize: 40, marginRight: 2 }} />
          <Typography variant="h3" sx={{ flexGrow: 1, fontWeight: "bold" }}>
            Servo Dashboard
          </Typography>
          {/* Power ON/OFF button on the right */}
          <Button
            variant="contained"
            color="white"
            sx={{ backgroundColor: "#6200ea", fontWeight: "bold" }}
          >
            <PowerButton />
          </Button>
        </Toolbar>
      </AppBar>

      {/* Main Content Section */}
      <Box
        sx={{
          padding: 3,
          minHeight: "86vh",
          backgroundImage:
            "linear-gradient(135deg,rgb(14, 30, 56) 20%, #2A5298 50%,rgb(124, 144, 182) 80%)",
          backgroundSize: "cover",
        }}
      >
        {/* Second Row: Three components */}
        <Grid container spacing={2} sx={{ marginBottom: 3 }}>
          <Grid item xs={12} sm={3}>
            <Appp />
            {/* <DataBox
              shape="square"
              title="Servo Command Center"
              content={""}
              color="linear-gradient(135deg,rgb(124, 144, 182) 20%, #2A5298 50%,rgb(124, 144, 182) 80%)"
            /> */}
          </Grid>

          <Grid item xs={12} sm={6}>
            <DataBox
              shape="square"
              title="Servo "
              content=""
              sx={{ marginBottom: "40px", padding: "30px" }} // Increase marginBottom here
              color="#babad9"
            >
              {/* Grid Layout for Left and Right Side */}
              <Grid container spacing={2} sx={{ marginTop: "20px" }}>
                {" "}
                {/* Add marginTop to move the boxes down */}
                {/* Left Side: Square Box */}
                <Grid item xs={12} sm={6}>
                  <Box
                    sx={{
                      width: "100%", // 100% of the available space
                      height: "220px", // Height of the square
                      backgroundImage:
                        "linear-gradient(135deg, #474545 20%, #474545 50%, #474545 80%)",

                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      borderRadius: 2,
                      marginBottom: "20px", // Space between the square and rectangles
                    }}
                  >
                    <Typography variant="h6">Servo</Typography>
                  </Box>
                </Grid>
                {/* Right Side: Four Rectangle Boxes */}
                <Grid item xs={12} sm={6}>
                  <Grid container spacing={2}>
                    {/* Rectangle Box 1 */}
                    <Grid item xs={12} sm={6}>
                      <Grid container spacing={2}>
                        {/* Rectangle Box 1 */}
                        <Grid item xs={6} sm={12}>
                          <Box
                            onClick={handleOpenCylinderPopup}
                            sx={{
                              height: "100px",
                              backgroundImage:
                                "linear-gradient(135deg, #474545 20%, #474545 50%, #474545 80%)",

                              borderRadius: 2,
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              overflow: "hidden",

                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: "#872955",
                                opacity: 0.9,
                              },
                            }}
                          >
                            Servo
                          </Box>
                        </Grid>
                      </Grid>
                    </Grid>
                    {/* Rectangle Box 2 */}
                    <Grid item xs={6}>
                      <Box
                        sx={{
                          height: "100px",
                          backgroundImage:
                            "linear-gradient(135deg, #474545 20%, #474545 50%, #474545 80%)",
                          borderRadius: 2,
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                        onClick={() => handleOpenn("Azimuth")}
                      >
                        <Typography variant="body1">
                          Azimuth Datalog Enable
                        </Typography>
                      </Box>
                    </Grid>

                    {/* Elevation Datalog Enable Box */}
                    <Grid item xs={6}>
                      <Box
                        sx={{
                          height: "100px",
                          backgroundImage:
                            "linear-gradient(135deg, #474545 20%, #474545 50%, #474545 80%)",
                          borderRadius: 2,
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                        onClick={() => handleOpenn("Elevation")}
                      >
                        <Typography variant="body1">
                          Elevation Datalog Enable
                        </Typography>
                      </Box>
                    </Grid>

                    <Dialog
                      open={open}
                      onClose={handleClose}
                      maxWidth="lg"
                      fullWidth
                      sx={{ width: "100%" }} // Reduce the width to 50% of the parent container
                    >
                      <DialogTitle
                        sx={{
                          fontSize: "1.5rem",
                          fontWeight: "bold",
                          color: "white",
                          right: "10%",
                        }}
                      >
                        {selectedData} Data
                      </DialogTitle>
                      <DialogContent>
                        {selectedData === "Azimuth" ? (
                          <>
                            <Typography variant="h6">
                              Azimuth Encoder Data
                            </Typography>
                            <Typography>Azimuth Commanded Angle</Typography>
                            <Typography>Azimuth Angle Error</Typography>
                            <Typography>Azimuth Running Speed</Typography>
                            <Typography>Azimuth Command Speed</Typography>
                            <Typography>Azimuth Speed Error</Typography>
                            <Typography>Azimuth Running Current</Typography>
                            <Typography>Azimuth Rise Time (secs)</Typography>
                            <Typography>
                              Azimuth Settling Time (secs)
                            </Typography>
                            <Typography>Azimuth Overshoot (%)</Typography>
                            <Typography>Azimuth Bandwidth</Typography>
                            <Typography>
                              Azimuth Measured Max Velocity (rpm)
                            </Typography>
                            <Typography>
                              Azimuth Measured Max Acceleration (Deg/sec2)
                            </Typography>
                          </>
                        ) : (
                          <>
                            <Typography variant="h6">
                              Elevation Encoder Data
                            </Typography>
                            <Typography>Elevation Commanded Angle</Typography>
                            <Typography>Elevation Angle Error</Typography>
                            <Typography>Elevation Running Speed</Typography>
                            <Typography>Elevation Command Speed</Typography>
                            <Typography>Elevation Speed Error</Typography>
                            <Typography>Elevation Running Current</Typography>
                            <Typography>Elevation Rise Time (secs)</Typography>
                            <Typography>
                              Elevation Settling Time (secs)
                            </Typography>
                            <Typography>Elevation Overshoot (%)</Typography>
                            <Typography>Elevation Bandwidth</Typography>
                            <Typography>
                              Elevation Measured Max Velocity
                            </Typography>
                            <Typography>
                              Elevation Measured Max Acceleration
                            </Typography>
                          </>
                        )}
                      </DialogContent>
                      <DialogActions>
                        <Button onClick={handleClose} color="primary">
                          Close
                        </Button>
                      </DialogActions>
                    </Dialog>

                    {/* Rectangle Box 4 */}
                    <Grid item xs={6}>
                      <Box
                        sx={{
                          height: "100px",
                          backgroundImage:
                            "linear-gradient(135deg, #474545 20%, #474545 50%, #474545 80%)",

                          borderRadius: 2,
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Typography variant="body1">
                          Process Completed
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </DataBox>
          </Grid>

          <Grid item xs={6} sm={3}>
            <DataBox shape="square" title="" content="" color="#babad9">
              {/* Nested Grid for additional boxes */}
              <Grid container spacing={2}>
                <Grid item xs={6} sm={4}>
                  <DataBox
                    shape="rectangle"
                    color="#e0f7fa"
                    onClick={() => navigate("/HealthStatus")}
                  >
                    <Typography
                      variant="h5"
                      sx={{
                        fontSize: {
                          xs: "0.5rem", // 16px for small screens
                          sm: "1rem", // 20px for medium screens and above
                          md: "1rem", // 24px for large screens
                        },
                        fontWeight: "bold",
                        textAlign: "center",
                        color: "black",
                      }}
                    >
                      Health Status
                    </Typography>
                  </DataBox>
                </Grid>

                <Grid item xs={6} sm={4}>
                  <DataBox
                    shape="rectangle"
                    color="#fbe9e7"
                    onClick={() => navigate("/RunningData")}
                  >
                    <Typography
                      variant="h5"
                      sx={{
                        fontSize: {
                          xs: "0.5rem", // 16px for small screens
                          sm: "1rem", // 20px for medium screens and above
                          md: "1rem", // 24px for large screens
                        },
                        fontWeight: "bold",
                        textAlign: "center",
                        color: "black",
                      }}
                    >
                      Running Data
                    </Typography>
                  </DataBox>
                  
                </Grid>
                <Grid item xs={6} sm={4}>
                  <DataBox
                    shape="rectangle"
                    color="#ecdefa"
                    // onClick={() => navigate("/RunningData")}
                  >
                    <Typography
                      variant="h5"
                      sx={{
                        fontSize: {
                          xs: "0.5rem", // 16px for small screens
                          sm: "1rem", // 20px for medium screens and above
                          md: "1rem", // 24px for large screens
                        },
                        fontWeight: "bold",
                        textAlign: "center",
                        color: "black",
                      }}
                    >
                      System Parameter
                    </Typography>
                  </DataBox>
                </Grid>
              </Grid>
            </DataBox>
          </Grid>
        </Grid>

        {/* Third Row: Two components */}
        <Grid container spacing={3}>
          <Grid item xs={12} sm={3}>
            <DataBox shape="square" title="" content="" color="#babad9">
              {/* Nested Grid for additional boxes */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={12}>
                  <DataBox shape="rectangle" title="" content="">
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Box
                          onClick={handleClick}
                          sx={{
                            height: "60px",
                            backgroundImage:
                              "linear-gradient(135deg,rgb(10, 10, 10) 20%,rgb(7, 6, 6) 50%, #474545 80%)",
                            borderRadius: 3,
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            padding: "0 20px",
                            boxShadow: "0px 6px 10px rgba(0, 0, 0, 0.15)",
                            transition: "all 0.3s ease", // Quick transition for hover effects
                            transform: isAnimating ? "scale(1.1)" : "scale(1)",
                            "&:hover": {
                              backgroundImage:
                                "linear-gradient(135deg,rgb(12, 12, 12) 20%,rgb(5, 5, 5) 50%, #5e5e5e 80%)", // Hover effect
                              boxShadow: "0px 8px 12px rgba(0, 0, 0, 0.2)", // Slightly deeper shadow on hover
                            },
                          }}
                        >
                          <CameraIcon
                            sx={{
                              color: "white",
                              marginRight: 2,
                              fontSize: "30px",
                            }}
                          />
                          <Typography
                            variant="body1"
                            sx={{
                              color: "white",
                              fontWeight: "600",
                              fontSize: "16px",
                            }}
                          >
                            Camera
                          </Typography>
                        </Box>
                      </Grid>

                      {/* Dialog (Popup) with square camera lens opening animation */}
                      <Dialog
                        open={openDialog}
                        onClose={() => setOpenDialog(false)}
                        sx={{
                          "& .MuiDialog-paper": {
                            borderRadius: "8px", // Keep it square with sharp edges
                            width: "80%",
                            maxWidth: "420px",
                            margin: "auto",
                            animation: "zoomIn 1s ease-out", // Square zoom effect
                            boxShadow: "0px 12px 24px rgba(0, 0, 0, 0.2)", // Soft shadow for depth
                            background:
                              "linear-gradient(135deg, #303030, #474747)", // Elegant gradient background
                          },
                        }}
                      >
                        <DialogContent sx={{ padding: "20px" }}>
                          <Typography
                            variant="h6"
                            sx={{
                              color: "#fff",
                              fontWeight: 600,
                              marginBottom: "10px",
                            }}
                          >
                            Camera
                          </Typography>
                          {/* Indoor and Outdoor Camera Buttons */}
                          <Box
                            sx={{
                              display: "flex",
                              flexDirection: "column",
                              gap: 2,
                            }}
                          >
                            <Button
                              sx={{
                                background:
                                  "linear-gradient(135deg, #ff5c8d, #ff4d4d)",
                                color: "white",
                                fontWeight: 600,
                                padding: "12px 20px",
                                borderRadius: "8px",
                                transition: "all 0.3s ease",
                                "&:hover": {
                                  background:
                                    "linear-gradient(135deg, #ff4d4d, #ff5c8d)",
                                  boxShadow: "0px 8px 12px rgba(0, 0, 0, 0.2)",
                                },
                              }}
                            >
                              Indoor Camera
                            </Button>
                            <Button
                              sx={{
                                background:
                                  "linear-gradient(135deg, #4e8eff, #1e63ff)",
                                color: "white",
                                fontWeight: 600,
                                padding: "12px 20px",
                                borderRadius: "8px",
                                transition: "all 0.3s ease",
                                "&:hover": {
                                  background:
                                    "linear-gradient(135deg, #1e63ff, #4e8eff)",
                                  boxShadow: "0px 8px 12px rgba(0, 0, 0, 0.2)",
                                },
                              }}
                            >
                              Outdoor Camera
                            </Button>
                          </Box>
                        </DialogContent>
                        <DialogActions>
                          <Button
                            onClick={() => setOpenDialog(false)}
                            color="primary"
                            sx={{ fontWeight: 500 }}
                          >
                            Close
                          </Button>
                        </DialogActions>
                      </Dialog>

                      {/* CSS Animation for Square Camera Lens Effect */}
                      <style jsx>{`
                        @keyframes zoomIn {
                          0% {
                            transform: scale(0);
                            opacity: 0;
                          }
                          100% {
                            transform: scale(1);
                            opacity: 1;
                          }
                        }
                      `}</style>

                      <Grid item xs={12}>
                        <Box
                          sx={{
                            height: "55px",
                            backgroundImage:
                              "linear-gradient(135deg,rgb(17, 11, 11) 20%, #474545 50%, #474545 80%)",
                            borderRadius: 2,
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            padding: "0 16px",
                            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                          }}
                        >
                          <AdminPanelSettingsIcon
                            sx={{ color: "white", marginRight: 2 }}
                          />
                          <Typography
                            variant="body1"
                            sx={{ color: "white", fontWeight: "bold",fontFamily: "'Times New Roman', serif",
                            }}
                            
                          >
                            Set Master Admin Parameter
                          </Typography>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box
                          sx={{
                            height: "55px",
                            backgroundImage:
                              "linear-gradient(135deg,rgb(12, 5, 5) 20%, #474545 50%, #474545 80%)",
                            borderRadius: 2,
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            padding: "0 16px",
                            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                          }}
                        >
                          <StopCircleIcon
                            sx={{ color: "white", marginRight: 2 }}
                          />
                          <Typography
                            variant="body1"
                            sx={{ color: "white", fontWeight: "bold" }}
                          >
                            Start Stop Scan ErrReset
                          </Typography>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box
                          sx={{
                            height: "55px",
                            backgroundImage:
                              "linear-gradient(135deg,rgb(20, 18, 18) 20%,rgb(19, 12, 12) 50%, #474545 80%)",
                            borderRadius: 2,
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            padding: "0 16px",
                            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                            cursor: "pointer", // Add cursor pointer to indicate it's clickable
                          }}
                          onClick={handleOpenDialogBias} // Trigger dialog when clicked
                        >
                          <SettingsBackupRestoreIcon
                            sx={{ color: "white", marginRight: 2 }}
                          />
                          <Typography
                            variant="body1"
                            sx={{ color: "white", fontWeight: "bold" }}
                          >
                            Bias and Factory Setting
                          </Typography>
                        </Box>
                      </Grid>

                      {/* Dialog for Bias and Factory Setting */}
                      <Dialog
                        open={openDialogBias}
                        onClose={handleCloseDialogBias}
                      >
                        <DialogTitle>
                          {" "}
                          <Typography variant="h6" sx={{ color: "white" }}>
                            Bias and Factory Settings
                          </Typography>
                        </DialogTitle>
                        <DialogContent>
                          <Bias_Factory_Setting />{" "}
                          {/* This is the component inside the dialog */}
                        </DialogContent>
                        <DialogActions>
                          <Button
                            onClick={handleCloseDialogBias}
                            color="primary"
                          >
                            <Typography variant="h6" sx={{ color: "red" }}>
                              Close
                            </Typography>
                          </Button>
                        </DialogActions>
                      </Dialog>
                    </Grid>
                  </DataBox>
                </Grid>
              </Grid>
            </DataBox>
          </Grid>

          <Grid item xs={12} sm={9}>
            <DataBox shape="square" title="" content="" color="#babad9">
              {/* Nested grid for three boxes inside Scan, RHI, Mode */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <DataBox shape="rectangle" title="Scan" content="">
                    <RadarScanCarousel />
                  </DataBox>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <DataBox
                    shape="rectangle"
                    title="Mode"
                    content={
                      <Box
                        sx={{
                          position: "relative",
                          width: "100%",
                          backgroundColor: "", // Background color for the box
                          padding: 2,
                          borderRadius: "8px",
                          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                        }}
                      >
                        <Typography variant="subtitle2"></Typography>
                        <AnimatedBox
                          onClick={() => navigate("/SchedularMode")}
                          sx={{
                            backgroundColor: "#1a1a1a",
                            borderRadius: 2,
                            padding: 1,
                            textAlign: "center",
                            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.4)",
                            transition: "transform 0.3s ease",
                            mt: 1,
                            width: "100%",
                            cursor: "pointer",
                          }}
                        >
                          <EventAvailableIcon
                            sx={{ fontSize: 30, color: "#fff" }}
                          />
                          <Typography
                            variant="subtitle2"
                            style={{ color: "white", fontWeight: "bold" }}
                          >
                            Scheduler Mode
                          </Typography>
                        </AnimatedBox>

                        <AnimatedBox
                          onClick={() => navigate("/MaintenanceMode")}
                          sx={{
                            backgroundColor: "#1a1a1a",
                            borderRadius: 2,
                            padding: 1,
                            textAlign: "center",
                            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.4)",
                            transition: "transform 0.3s ease",
                            mt: 1,
                            width: "100%",
                            cursor: "pointer",
                          }}
                        >
                          <BuildIcon sx={{ fontSize: 30, color: "#fff" }} />
                          <Typography
                            variant="subtitle2"
                            style={{ color: "white", fontWeight: "bold" }}
                          >
                            Maintenance Mode
                          </Typography>{" "}
                        </AnimatedBox>

                        <AnimatedBox
                          onClick={() => navigate("/CalibrationMode")}
                          sx={{
                            backgroundColor: "#1a1a1a",
                            borderRadius: 2,
                            padding: 0.3,
                            textAlign: "center",
                            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.4)",
                            transition: "transform 0.3s ease",
                            cursor: "pointer",
                            mt: 1,
                            width: "100%",
                          }}
                        >
                          <SettingsInputComponentIcon
                            sx={{ fontSize: 30, color: "#fff" }}
                          />
                          <Typography
                            variant="subtitle2"
                            style={{ color: "white", fontWeight: "bold" }}
                          >
                            Calibration Mode
                          </Typography>{" "}
                        </AnimatedBox>
                      </Box>
                    }
                    // content={

                    //   <Grid container spacing={2}>
                    //     <Grid item xs={12} sm={6}>
                    //       <RadarBox
                    //         title="Scheduler Mode"
                    //         modeType="scheduler" // Pass the modeType to the RadarBox
                    //         onClick={() => handleModeClick("scheduler")} // Call the handleModeClick function with "scheduler"
                    //       />
                    //     </Grid>
                    //     <Grid item xs={12} sm={6}>
                    //       <RadarBox
                    //         title="Calibration Mode"
                    //         modeType="calibration" // Pass the modeType to the RadarBox
                    //         onClick={() => handleModeClick("calibration")} // Call the handleModeClick function with "calibration"
                    //       />
                    //     </Grid>
                    //   </Grid>
                    // }
                  />
                </Grid>
              </Grid>
            </DataBox>
            <Dialog open={isDialogOpen} onClose={handleDialogClose}>
              <DialogTitle>
                <Typography
                  variant="h4"
                  align="center"
                  sx={{ fontWeight: "bold", color: "white" }}
                >
                  Select Mode
                </Typography>
              </DialogTitle>
            </Dialog>
          </Grid>
        </Grid>
      </Box>

      {/* Dialog for Scan */}
      <Dialog open={""} onClose={handleClose} fullWidth maxWidth="md">
        <DialogTitle>
          Scan
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{ position: "absolute", right: 8, top: 8 }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
      </Dialog>
    </div>
  );
};

export default Servo;
