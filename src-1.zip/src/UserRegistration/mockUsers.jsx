// mockUsers.js
export const users = [
    { username: "super", password: "123", role: "superuser" },
    { username: "normal", password: "123", role: "normaluser" },
    { username: "user", password: "123", role: "user" },
  ];
  