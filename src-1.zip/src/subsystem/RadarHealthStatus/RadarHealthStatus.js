// import React, { useState, useEffect } from 'react';
// import './RadarHealthStatus.css';

// const RadarHealthStatus = () => {
//   const [status, setStatus] = useState('Good');

//   useEffect(() => {
//     const interval = setInterval(() => {
//       // Randomly change health status for demonstration
//       setStatus((prev) => (prev === 'Good' ? 'Critical' : 'Good'));
//     }, 5000); // Change status every 5 seconds

//     return () => clearInterval(interval); // Cleanup on component unmount
//   }, []);

//   return (
//     <div className="radarHealth-container">
//       {/* Add the "critical" class dynamically based on the health status */}
//       <div className={`radarHealth ${status === 'Critical' ? 'critical' : ''}`}>
//         <div className={`radarHealth-sweep ${status === 'Critical' ? 'critical' : ''}`}></div>
//         <div className={`radarHealth-blip ${status === 'Critical' ? 'critical' : ''}`}></div>
//       </div>
//       {/* Add the "critical" class dynamically to the health status text */}
//       <div className={`status ${status === 'Critical' ? 'critical' : ''}`}>
//         <span>Health Status: <strong>{status}</strong></span>
//       </div>
//     </div>
//   );
// }

// export default RadarHealthStatus;



import React, { useState, useEffect } from 'react';
import './RadarHealthStatus.css';
import { useHealthStatusListener, useHealthStore } from "../../store";


const RadarHealthStatus = () => {
  const [status, setStatus] = useState('Good');
  const [color, setColor] = useState('green'); // Default to green

  // Simulating health status from the store
  const healthStatus = useHealthStore((state) => state.healthStatus); 
  useHealthStatusListener();

  const [responseValues, setResponseValues] = useState({
    timeStamp: {
      timeMilliSec: null,
      time: null,
    },
    systemEMMStatus: {
      radomeEStopSwitch1: false,
      radomeDoorSwitch: false,
      radomeEStopSwitch2: false,
      servoPanelEStop: false,
      azDriveError: false,
      elDriveError: false,
      systemReady: false,
      systemEnabled: false,
    },
    systemOperationParameters: {
      mode: false,
      localModeOperating: false,
      remoteModeOperating: false,
      manualMode: false,
      designateMode: false,
      volumeScan: false,
      azSectorScan: false,
      elSectorScan: false,
    },
    systemSyncSignalStatus: null,
    servoPanelIncomePowerSupplyStatus: null,
    spareModificationUsed: {
      highWindSpeed: false,
      frontDoorInterlock: false,
      backDoorInterlock: false,
      internalVibrationMonitor: false,
      antennaCoolingUnit: false,
      stowLockEnable: false,
    },
    azimuthStatus: {
      auxPower: false,
      busVoltage: null,
      heatSinkTemp: null,
      brakeCurrent: null,
      driveError: false,
      driveErrorID1: null,
      driveErrorID2: null,
      driveErrorID3: null,
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
        microswitchHandCranking: false,
        azimuthStowLock: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        azimuthPowerOn: false,
        azimuthEnable: false,
        azimuthSTO: false,
      },
    },
    elevationStatus: {
      auxPower: false,
      busVoltage: null,
      heatSinkTemp: null,
      brakeCurrent: null,
      driveError: false,
      driveErrorID1: null,
      driveErrorID2: null,
      driveErrorID3: null,
      limitsStatus: {
        elevationUpDirSoftLimit: false,
        elevationUpDirPreLimit: false,
        elevationUpDirFinalLimit: false,
        elevationDnDirSoftLimit: false,
        elevationDnDirPreLimit: false,
        elevationDnDirFinalLimit: false,
      },
      runningStatus: {
        motorRunning: false,
        motorDirectionCW: false,
        motorDirectionCCW: false,
        encoderStatus: false,
        driveErrorStop: false,
        drivePowerStatus: false,
        microswitchHandCranking: false,
        elevationStowLock: false,
      },
      digitalInputs: {
        controlInhibit: false,
        driveSTO1Status: false,
      },
      digitalOutputs: {
        elevationPowerOn: false,
        elevationEnable: false,
        elevationSTO: false,
      },
    },
  });

  useEffect(() => {
    if (healthStatus) {
      setResponseValues(healthStatus); // Update state with health status from the store
    }
  }, [healthStatus]);

  // Function to check if all the values are below 15
  const checkHealthStatus = () => {
    const allBelow15 =
      Object.values(responseValues.azimuthStatus).every((value) => value < 15) &&
      Object.values(responseValues.elevationStatus).every((value) => value < 15);

    if (allBelow15) {
      setStatus('Good');
      setColor('green');
    } else {
      setStatus('Critical');
      setColor('red');
    }
  };

  useEffect(() => {
    checkHealthStatus(); // Check health status whenever responseValues change
  }, [responseValues]);

  return (
    <div className="radarHealth-container">
      {/* Add the dynamic "critical" or "good" class */}
      <div className={`radarHealth ${color === 'red' ? 'critical' : 'good'}`}>
        <div className={`radarHealth-sweep ${color === 'red' ? 'critical' : 'good'}`}></div>
        <div className={`radarHealth-blip ${color === 'red' ? 'critical' : 'good'}`}></div>
      </div>
      {/* Health status text */}
      <div className={`status ${color === 'red' ? 'critical' : 'good'}`}>
      <span style={{ fontFamily: "'Times Square Roman', serif" }}>
  Health Status: <strong>{status}</strong>
</span>
</div>

    </div>
  );
};

export default RadarHealthStatus;

