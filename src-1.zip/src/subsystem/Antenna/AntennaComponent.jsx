import React, { useState, useEffect } from "react";
import "./AntennaComponent.css";

const AntennaComponent = () => {
    const [signalState, setSignalState] = useState("receiving"); // "idle", "sending", or "receiving"

    useEffect(() => {
        // Set the initial signal state to "receiving" when the component mounts.
        setSignalState("receiving");
    }, []);

    return (
        <div className="antenna-container">
            <div className="antenna">
                <div className="antenna-head"></div>

                {/* Conditionally render signals based on state */}
                {signalState === "sending" && <div className="signal sending"></div>}
                {signalState === "receiving" && (
                    <>
                        <div className="signal sending"></div>
                        <div className="signal receiving"></div>
                    </>
                )}
            </div>

            {/* The controls have been removed as per your requirement */}
        </div>
    );
};

export default AntennaComponent;
