// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   ToggleButton,
//   ToggleButtonGroup,
//   Switch,
//   FormControlLabel,
// } from "@mui/material";
// import { Socket } from "socket.io-client";
// import { useSocket } from "../../SocketContext";

// const RadarCameraView = () => {
//   const [isIndoorOpen, setIsIndoorOpen] = useState(false);
//   const [isOutdoorOpen, setIsOutdoorOpen] = useState(false);
//   const [activeCamera, setActiveCamera] = useState("camera");

//   // State for camera and video recorder toggles
//   const [indoorCameraOn, setIndoorCameraOn] = useState(true);
//   const [indoorRecorderOn, setIndoorRecorderOn] = useState(false);
//   const [outdoorCameraOn, setOutdoorCameraOn] = useState(true);
//   const [outdoorRecorderOn, setOutdoorRecorderOn] = useState(false);

//   const handleIndoorCameraOpen = () => {
//     setIsIndoorOpen(true); // Opens the indoor camera pop-up
//     setActiveCamera("indoor");
//   };

//   const handleOutdoorCameraOpen = () => {
//     setIsOutdoorOpen(true); // Opens the outdoor camera pop-up
//     setActiveCamera("outdoor");
//   };

//   // Separate handlers for closing pop-ups
//   const handleCloseIndoorPopUp = () => {
//     setIsIndoorOpen(false); // Close only indoor camera pop-up
//     setActiveCamera("camera"); // Reset active camera
//   };

//   const handleCloseOutdoorPopUp = () => {
//     setIsOutdoorOpen(false); // Close only outdoor camera pop-up
//     setActiveCamera("camera"); // Reset active camera
//   };

//   const socket=useSocket();
//   return (
//     <Box sx={{ position: "relative", minHeight: "100vh", bgcolor: "#121212" }}>
//       {/* Camera Selection Toggle Button */}
//       <Box
//         sx={{
//           position: "absolute",
//           top: "48%",
//           left: "50%",
//           transform: "translate(-50%, -50%)",
//           textAlign: "center",
//         }}
//       >
//         <Typography sx={{ color: "#fff", marginBottom: 2, fontSize: "18px" }}>
//           {activeCamera === "indoor"
//             ? ""
//             : activeCamera === "outdoor"
//             ? ""
//             : ""}
//         </Typography>

//         {/* Camera Toggle Button */}
//         <ToggleButtonGroup
//           value={activeCamera}
//           exclusive
//           onChange={(event, newCamera) => setActiveCamera(newCamera)}
//           sx={{
//             width: "100%", // Make the width 100% for better flexibility
//             backgroundColor: "#333",
//             borderRadius: "8px",
//             padding: "2px",
//             display: "flex",
//             justifyContent: "space-between",
//             boxShadow: "0 8px 16px rgba(0, 0, 0, 0.3)",
//             // Apply responsiveness
//             flexDirection: {
//               xs: "column", // Stack buttons vertically on small screens
//               sm: "row", // Align them horizontally on screens >=600px
//             },
//             "& .MuiToggleButton-root": {
//               width: {
//                 xs: "100%", // Each button takes full width on small screens
//                 sm: "33%", // Each button takes 33% width on larger screens
//               },
//             },
//           }}
//         >
//           <ToggleButton
//             value="indoor"
//             onClick={handleIndoorCameraOpen}
//             sx={{
//               color: "#fff",
//               background: "linear-gradient(145deg, #2e7d32, #66bb6a)",
//               boxShadow:
//                 "4px 4px 6px rgba(0, 0, 0, 0.2), -4px -4px 6px rgba(255, 255, 255, 0.1)",
//               borderRadius: "8px",
//               "&:hover": { transform: "scale(1.05)" },
//               "&.Mui-selected": {
//                 boxShadow: "4px 4px 10px rgba(0, 0, 0, 0.3)",
//               },
//               transition: "all 0.3s ease",
//             }}
//           >
//             Indoor
//           </ToggleButton>
//           <ToggleButton
//             value="camera"
//             sx={{
//               color: "#fff",
//               background: "linear-gradient(145deg, #616161, #757575)",
//               borderRadius: "8px",
//               "&:hover": { transform: "scale(1.05)" },
//               "&.Mui-selected": {
//                 boxShadow: "4px 4px 10px rgba(0, 0, 0, 0.3)",
//               },
//             }}
//           >
//             Camera
//           </ToggleButton>
//           <ToggleButton
//             value="outdoor"
//             onClick={handleOutdoorCameraOpen}
//             sx={{
//               color: "#fff",
//               background: "linear-gradient(145deg, #d32f2f, #ef5350)",
//               borderRadius: "8px",
//               "&:hover": { transform: "scale(1.05)" },
//               "&.Mui-selected": {
//                 boxShadow: "4px 4px 10px rgba(0, 0, 0, 0.3)",
//               },
//             }}
//           >
//             Outdoor
//           </ToggleButton>
//         </ToggleButtonGroup>
//       </Box>

//       {/* Indoor Camera Pop-up */}
//     {/* Indoor Camera Pop-up */}
// {isIndoorOpen && (
//   <Box
//     sx={{
//       position: "fixed",
//       top: -400,
//       left: 0,
//       width: "100%",
//       height: "100%",
//       backgroundColor: "",
//       display: "flex",
//       justifyContent: "center",
//       alignItems: "center",
//       zIndex: 9999,
//     }}
//   >
//     <Box
//       sx={{
//         position: "relative",
//         width: "400px",
//         height: "400px",
//         borderRadius: "10px",
//         boxShadow: "0 0 15px rgba(0, 0, 0, 0.8)",
//         overflow: "hidden",
//         background: "#e1edf2",
//         padding: "20px",
//       }}
//     >
//       {/* On/Off Toggles */}
//       <Typography sx={{ color: "black", marginBottom: 2 }}>
//         Indoor Camera Options
//       </Typography>
//       <FormControlLabel
//         control={
//           <Switch
//             checked={indoorCameraOn}
//             onChange={(e) => setIndoorCameraOn(e.target.checked)}

//             color="primary"
//             sx={{
//               "& .MuiSwitch-track": {
//                 backgroundColor: indoorCameraOn ? "#4caf50" : "#f44336", // Green when on, Red when off
//               },
//               "& .MuiSwitch-thumb": {
//                 backgroundColor: indoorCameraOn ? "#ffffff" : "#ffffff", // White thumb in both states
//               },
//               "& .Mui-checked + .MuiSwitch-track": {
//                 backgroundColor: "#4caf50", // Green when checked
//               },
//               "& .MuiSwitch-switchBase.Mui-checked": {
//                 color: "#4caf50", // Green switch handle color when checked
//               },
//             }}
//           />
//         }
//         label="Camera On/Off"
//       />
//       <FormControlLabel
//         control={
//           <Switch
//             checked={indoorRecorderOn}
//             onChange={(e) => setIndoorRecorderOn(e.target.checked)}
//             color="secondary"
//             sx={{
//               "& .MuiSwitch-track": {
//                 backgroundColor: indoorRecorderOn ? "#4caf50" : "#f44336", // Green when on, Red when off
//               },
//               "& .MuiSwitch-thumb": {
//                 backgroundColor: indoorRecorderOn ? "#ffffff" : "#ffffff", // White thumb in both states
//               },
//               "& .Mui-checked + .MuiSwitch-track": {
//                 backgroundColor: "#4caf50", // Green when checked
//               },
//               "& .MuiSwitch-switchBase.Mui-checked": {
//                 color: "#4caf50", // Green switch handle color when checked
//               },
//             }}
//           />
//         }
//         label="Video Recorder On/Off"
//       />

//       {/* Camera Footage: Conditionally render the video when camera is on */}
//       {indoorCameraOn && (
//         <Box sx={{ marginTop: 2, display: "flex", justifyContent: "center" }}>
//           <video
//             autoPlay
//             muted
//             loop
//             sx={{
//               width: "100%",
//               height: "auto",
//               borderRadius: "8px",
//             }}
//           >
//             {/* For example, you can replace the src with a camera feed URL */}
//             <source
//               src="http://your-camera-feed-url-or-local-video.mp4"
//               type="video/mp4"
//             />
//             Your browser does not support the video tag.
//           </video>
//         </Box>

//       )}

//       {/* Close Button */}
//       <Box
//         onClick={handleCloseIndoorPopUp}
//         sx={{
//           position: "absolute",
//           top: "10px",
//           right: "10px",
//           backgroundColor: "#f44336",
//           color: "#fff",
//           borderRadius: "50%",
//           padding: "10px",
//           fontSize: "20px",
//           cursor: "pointer",
//           "&:hover": { backgroundColor: "#e57373" },
//         }}
//       >
//         X
//       </Box>
//     </Box>
//   </Box>
// )}

//       {/* Outdoor Camera Pop-up */}
//       {isOutdoorOpen && (
//         <Box
//           sx={{
//             position: "fixed",
//             top: -400,
//             left: 410,
//             width: "100%",
//             height: "100%",
//             backgroundColor: "",
//             display: "flex",
//             justifyContent: "center",
//             alignItems: "center",
//             zIndex: 9999,
//           }}
//         >
//           <Box
//             sx={{
//               position: "relative",
//               width: "400px",
//               height: "400px",
//               borderRadius: "10px",
//               boxShadow: "0 0 15px rgba(0, 0, 0, 0.8)",
//               overflow: "hidden",
//               background: "#e1edf2",
//               padding: "20px",
//             }}
//           >
//             {/* On/Off Toggles */}
//             <Typography sx={{ color: "black", marginBottom: 2 }}>
//               Outdoor Camera Options
//             </Typography>
//             <FormControlLabel
//               control={
//                 <Switch
//                   checked={outdoorCameraOn}
//                   onChange={(e) =>{
//                      setOutdoorCameraOn(e.target.checked)

//                     }}

//                   color="primary"
//                   sx={{
//                     "& .MuiSwitch-track": {
//                       backgroundColor: outdoorCameraOn ? "#4caf50" : "#f44336", // Green when on, Red when off
//                     },
//                     "& .MuiSwitch-thumb": {
//                       backgroundColor: outdoorCameraOn ? "#ffffff" : "#ffffff", // White thumb in both states
//                     },
//                     "& .Mui-checked + .MuiSwitch-track": {
//                       backgroundColor: "#4caf50", // Green when checked
//                     },
//                     "& .MuiSwitch-switchBase.Mui-checked": {
//                       color: "#4caf50", // Green switch handle color when checked
//                     },
//                   }}
//                 />
//               }
//               label="Camera On/Off"
//             />
//             <FormControlLabel
//               control={
//                 <Switch
//                   checked={outdoorRecorderOn}
//                   onChange={(e) => setOutdoorRecorderOn(e.target.checked)}
//                   color="secondary"
//                   sx={{
//                     "& .MuiSwitch-track": {
//                       backgroundColor: outdoorRecorderOn
//                         ? "#4caf50"
//                         : "#f44336", // Green when on, Red when off
//                     },
//                     "& .MuiSwitch-thumb": {
//                       backgroundColor: outdoorRecorderOn
//                         ? "#ffffff"
//                         : "#ffffff", // White thumb in both states
//                     },
//                     "& .Mui-checked + .MuiSwitch-track": {
//                       backgroundColor: "#4caf50", // Green when checked
//                     },
//                     "& .MuiSwitch-switchBase.Mui-checked": {
//                       color: "#4caf50", // Green switch handle color when checked
//                     },
//                   }}
//                 />
//               }
//               label="Video Recorder On/Off"
//             />
//             {/* Close Button */}
//             <Box
//               onClick={handleCloseOutdoorPopUp}
//               sx={{
//                 position: "absolute",
//                 top: "10px",
//                 right: "10px",
//                 backgroundColor: "#f44336",
//                 color: "#fff",
//                 borderRadius: "50%",
//                 padding: "10px",
//                 fontSize: "20px",
//                 cursor: "pointer",
//                 "&:hover": { backgroundColor: "#e57373" },
//               }}
//             >
//               X
//             </Box>
//           </Box>
//         </Box>
//       )}
//     </Box>
//   );
// };

// export default RadarCameraView;

import React, { useEffect, useRef, useState } from "react";
import { Box, Button, Typography, Card, Tab, Tabs, Grid } from "@mui/material";

function RadarCameraView() {
  const videoRefs = useRef([null, null, null]); // For 3 cameras: 2 indoor and 1 outdoor
  const streamRefs = useRef([null, null, null]); // For managing 3 media streams
  const mediaRecorderRefs = useRef([null, null, null]); // For MediaRecorder instances
  const [isRecording, setIsRecording] = useState([false, false, false]); // Record states for each camera
  const [isPlaying, setIsPlaying] = useState([true, true, true]); // To track if camera is playing
  const [currentCamera, setCurrentCamera] = useState(0); // Track which camera is currently active
  const [selectedTab, setSelectedTab] = useState(0); // For MUI Tabs component
  const [recordedChunks, setRecordedChunks] = useState([[], [], []]); // Store recorded chunks for each camera

  // Function to start the camera stream
  const getCameraStream = async (index) => {
    try {
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRefs.current[index]) {
        videoRefs.current[index].srcObject = stream;
      }
      streamRefs.current[index] = stream;

      // Initialize MediaRecorder for this stream
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRefs.current[index] = mediaRecorder;

      // Event listener to collect the recorded chunks
      mediaRecorder.ondataavailable = (event) => {
        setRecordedChunks((prev) => {
          const newChunks = [...prev];
          newChunks[index].push(event.data);
          return newChunks;
        });
      };
    } catch (err) {
      console.error("Error accessing the camera", err);
    }
  };

  // Function to start/stop recording
  const toggleRecording = (index) => {
    setIsRecording((prev) => {
      const newState = [...prev];
      newState[index] = !newState[index];
      return newState;
    });

    if (isRecording[index]) {
      // Stop recording
      mediaRecorderRefs.current[index].stop();
      console.log(`Stopped recording camera ${index + 1}`);
    } else {
      // Start recording
      mediaRecorderRefs.current[index].start();
      console.log(`Started recording camera ${index + 1}`);
    }
  };

  // Function to save the recording as a file
  const saveRecording = (index) => {
    const recordedBlob = new Blob(recordedChunks[index], {
      type: "video/webm",
    });
    const url = URL.createObjectURL(recordedBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `camera_${index + 1}_recording.webm`; // Save with a unique name
    link.click();
    setRecordedChunks((prev) => {
      const newChunks = [...prev];
      newChunks[index] = []; // Clear the chunks after saving
      return newChunks;
    });
  };

  // Tab change handler to switch between cameras
  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
    setCurrentCamera(newValue);
    if (!isPlaying[newValue]) {
      getCameraStream(newValue); // Start the stream for the selected camera if it's not playing
      setIsPlaying((prev) => {
        const newState = [...prev];
        newState[newValue] = true;
        return newState;
      });
    }
  };

  // Initialize camera streams
  useEffect(() => {
    for (let i = 0; i < 3; i++) {
      getCameraStream(i);
    }
  }, []);

  // Cleanup: stop all streams when the component unmounts
  useEffect(() => {
    return () => {
      streamRefs.current.forEach((stream) => {
        if (stream) {
          const tracks = stream.getTracks();
          tracks.forEach((track) => track.stop()); // Stop all tracks
        }
      });
    };
  }, []);

  return (
    <Box sx={{ padding: 2, backgroundColor: "#f0f4f8", minHeight: "100vh" }}>
      <Typography
        variant="h3"
        align="center"
        gutterBottom
        fontFamily="'Times New Roman', serif"
      >
        Live Camera Feed
      </Typography>

      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        centered
        variant="fullWidth"
        sx={{ marginBottom: 2 }}
      >
        <Tab
          label="Indoor Cameras"
          sx={{
            fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the tab label
            fontWeight: "bold", // Optional: You can make it bold if needed
          }}
        />
        <Tab
          label="Outdoor Camera"
          sx={{
            fontFamily: "'Times New Roman', serif", // Apply Times New Roman to the tab label
            fontWeight: "bold", // Optional: You can make it bold if needed
          }}
        />
      </Tabs>

      {/* Indoor Cameras Tab */}
      {selectedTab === 0 && (
        <Grid container spacing={4} sx={{ marginBottom: 2 }}>
          {/* Indoor Camera 1 */}
          <Grid item xs={12} sm={6}>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                padding: 1,
                boxShadow: 3,
                height: "700px",
                maxWidth: "100%",
                width: "100%",
              }}
            >
              <Typography
                variant="h6"
                sx={{ marginBottom: 2, fontFamily: "'Times New Roman', serif" }}
              >
                Indoor Camera 1
              </Typography>
              <video
                ref={(el) => (videoRefs.current[0] = el)}
                autoPlay
                playsInline
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: "8px",
                  border: "2px solid #ddd",
                }}
              />
              <Button
                variant="contained"
                color={isRecording[0] ? "error" : "success"}
                sx={{ padding: "10px 20px", fontSize: "16px"   ,               fontFamily: "'Times New Roman', serif",
                }}
                onClick={() => toggleRecording(0)}
              >
                {isRecording[0] ? "Stop Recording" : "Start Recording"}
              </Button>
              <Button
                variant="contained"
                color="primary"
                sx={{
                  padding: "10px 20px",
                  fontSize: "16px",
                  marginTop: "10px",
                  fontFamily: "'Times New Roman', serif",

                }}
                onClick={() => saveRecording(0)}
              >
                Save Recording
              </Button>
            </Card>
          </Grid>

          {/* Indoor Camera 2 */}
          <Grid item xs={12} sm={6}>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                padding: 1,
                boxShadow: 3,
                height: "700px",
                maxWidth: "100%",
                width: "100%",
              }}
            >
              <Typography
                variant="h6"
                sx={{ marginBottom: 2, fontFamily: "'Times New Roman', serif" }}
              >
                Indoor Camera 2
              </Typography>
              <video
                ref={(el) => (videoRefs.current[1] = el)}
                autoPlay
                playsInline
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: "8px",
                  border: "2px solid #ddd",
                }}
              />
              <Button
                variant="contained"
                color={isRecording[1] ? "error" : "success"}
                sx={{ padding: "10px 20px", fontSize: "16px",fontFamily: "'Times New Roman', serif" }}
                onClick={() => toggleRecording(1)}
              >
                {isRecording[1] ? "Stop Recording" : "Start Recording"}
              </Button>
              <Button
                variant="contained"
                color="primary"
                sx={{
                  padding: "10px 20px",
                  fontSize: "16px",
                  marginTop: "10px",
                  fontFamily: "'Times New Roman', serif",

                }}
                onClick={() => saveRecording(1)}
              >
                Save Recording
              </Button>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Outdoor Camera Tab */}
      {selectedTab === 1 && (
        <Grid container spacing={4} sx={{ marginBottom: 2 }}>
          <Grid item xs={12}>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                padding: 1,
                boxShadow: 3,
                height: "700px",
                maxWidth: "100%",
                width: "100%",
              }}
            >
              <Typography
                variant="h6"
                sx={{ marginBottom: 2, fontFamily: "'Times New Roman', serif" }}
              >
                Outdoor Camera
              </Typography>
              <video
                ref={(el) => (videoRefs.current[2] = el)}
                autoPlay
                playsInline
                style={{
                  width: "100%",
                  height: "80%",
                  borderRadius: "8px",
                  border: "2px solid #ddd",
                  fontFamily: "'Times New Roman', serif",
                }}
              />
              <Button
                variant="contained"
                color={isRecording[2] ? "error" : "success"}
                sx={{
                  padding: "10px 20px",
                  fontSize: "16px",
                  fontFamily: "'Times New Roman', serif",
                }}
                onClick={() => toggleRecording(2)}
              >
                {isRecording[2] ? "Stop Recording" : "Start Recording"}
              </Button>
              <Button
                variant="contained"
                color="primary"
                sx={{
                  padding: "10px 20px",
                  fontSize: "16px",
                  marginTop: "10px",
                  fontFamily: "'Times New Roman', serif",
                }}
                onClick={() => saveRecording(2)}
              >
                Save Recording
              </Button>
            </Card>
          </Grid>
        </Grid>
      )}
    </Box>
  );
}

export default RadarCameraView;
