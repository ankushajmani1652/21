import React, { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars } from "@react-three/drei";

const RadarDish = ({ rotationSpeed }) => {
    const dishRef = useRef();
    const servoRef = useRef();

    useFrame(({ clock }) => {
        const elapsedTime = clock.getElapsedTime();

        // Simulate azimuthal (horizontal) scanning
        if (servoRef.current) {
            servoRef.current.rotation.y = Math.sin(elapsedTime * rotationSpeed) * Math.PI * 0.25; // ±45° sweep
        }

        // Simulate elevation (vertical) scanning
        if (dishRef.current) {
            dishRef.current.rotation.x = Math.sin(elapsedTime * rotationSpeed * 0.5) * Math.PI * 0.1; // ±18° tilt
        }
    });

    return (
        <group ref={servoRef}>
            {/* Dish (Increased size by adjusting the radius) */}
            <mesh ref={dishRef} position={[0, 1, 0]}>
                <sphereGeometry args={[1.5, 32, 32]} /> {/* Increased radius from 0.5 to 1.5 */}
                <meshStandardMaterial
                    color="lightgray"
                    metalness={4}
                    roughness={0.2}
                    emissive="white"
                    emissiveIntensity={0.5}
                />
            </mesh>

            {/* Mount for the dish */}
            <mesh position={[0, 0.5, 0]}>
                <cylinderGeometry args={[0.1, 0.1, 1, 32]} />
                <meshStandardMaterial color="black" />
            </mesh>
        </group>
    );
};

const RadarBase = () => {
    return (
        <group>
            {/* Base Stand */}
            <mesh position={[0, -1, 0]}>
                <cylinderGeometry args={[0.2, 0.2, 2, 32]} />
                <meshStandardMaterial color="black" />
            </mesh>

            {/* Base Plate */}
            <mesh position={[0, -2, 0]}>
                <cylinderGeometry args={[0.5, 0.5, 0.2, 32]} />
                <meshStandardMaterial color="darkgray" />
            </mesh>
        </group>
    );
};

const Clouds = () => {
    const cloudRef = useRef();

    useFrame(({ clock }) => {
        if (cloudRef.current) {
            const elapsedTime = clock.getElapsedTime();
            cloudRef.current.position.x = Math.sin(elapsedTime) * 4; // Move horizontally
            cloudRef.current.position.z = Math.cos(elapsedTime) * 3; // Circular motion
        }
    });

    return (
        <group ref={cloudRef}>
            <mesh position={[0, 2, 0]}>
                <sphereGeometry args={[0.8, 16, 16]} />
                <meshStandardMaterial
                    color="white"
                    opacity={0.6}
                    transparent
                    roughness={0.4}
                    emissive="#ffffff"
                />
            </mesh>
        </group>
    );
};

const MovingStars = () => {
    const starsRef = useRef();

    useFrame(({ clock }) => {
        if (starsRef.current) {
            const elapsedTime = clock.getElapsedTime();
            // Slowly move stars in a circular motion in the X and Z axes (no twinkling)
            starsRef.current.position.x = Math.sin(elapsedTime * 0.3) * 100; // Circular motion along X-axis
            starsRef.current.position.z = Math.cos(elapsedTime * 0.3) * 100; // Circular motion along Z-axis
        }
    });

    return (
        <Stars
            ref={starsRef}
            radius={300}
            depth={60}
            count={5000}
            factor={4}
            saturation={0.8}
            fade={false} // Disable twinkling effect
        />
    );
};

const Appp = () => {
    return (
        <div style={{ height: "40vh" }}>
            <Canvas camera={{ position: [5, 5, 5], fov: 50 }}>
                <ambientLight intensity={0.3} />
                <pointLight position={[10, 10, 10]} intensity={1.5} color="#ffffff" />
                <RadarBase />
                <RadarDish rotationSpeed={0.5} />
                <Clouds />
                <MovingStars /> {/* Use MovingStars component here */}
                <OrbitControls />
            </Canvas>
        </div>
    );
};

export default Appp;
