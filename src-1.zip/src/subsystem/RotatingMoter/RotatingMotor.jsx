// import { Card, Typography, Grid } from "@mui/material";
// import { motion } from "framer-motion";
// import { useState, useEffect } from "react";
// import SettingsIcon from "@mui/icons-material/Settings"; // Represents the motor

// const RotatingMotor = ({runningStatus}) => {
//   // const [direction, setDirection] = useState(1); // 1 for clockwise, -1 for anti-clockwise
//   // const [motorStatus, setMotorStatus] = useState(0); // 0 for stopped, 1 for rotating
//   const [color, setColor] = useState("blue"); // Default color is blue

//   // useEffect(() => {
//   //   // Simulating server response (replace with actual fetch if needed)
//   //   const fetchServerData = () => {
//   //     // Simulate a server response with a random value (1 or 0)
//   //     const response = Math.random() > 0.5 ? 1 : 0;
//   //     setMotorStatus(response);

//   //     // Set the color based on the response
//   //     if (response === 1) {
//   //       setColor("blue");
//   //     } else {
//   //       setColor("gray");
//   //     }
//   //   };

//   //   // Call the function once when the component mounts (or periodically if needed)
//   //   fetchServerData();

//   //   // Optionally, you could set an interval to simulate periodic server checks:
//   //   const interval = setInterval(fetchServerData, 5000); // Every 5 seconds

//   //   return () => clearInterval(interval);
//   // }, []);

//   return (
//     <Grid item xs={12} sm={6} md={12}>
//       <Card
//         sx={{
//           boxShadow: 0,
//           borderRadius: 2,
//           height: "95%",
//           marginTop: "5%",
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           padding: 0,
//         }}
//       >
//         <Typography
//           variant="h5" // Increased size
//           sx={{ fontWeight: "bold", marginBottom: 2 }}
//           gutterBottom
//         >
//           {/* Motor Running & Motor Direction */}
//         </Typography>

//         {/* Animated Motor Icon */}
//         <motion.div
//           animate={motorStatus === 1 ? { rotate: direction === 1 ? -360 : 360 } : { rotate: 0 }}
//           transition={motorStatus === 1 ? { repeat: Infinity, duration: 5, ease: "linear" } : {}}
//         >
//           <SettingsIcon sx={{ fontSize: 100, color: color }} /> {/* Change color based on server response */}
//         </motion.div>

//         {/* Text Displaying Rotation Direction */}
//         {motorStatus === 1 && (
//           <Typography
//             variant="h5" // Increased size
//             sx={{ fontWeight: "bold", marginTop: 3, color: "green" }}
//           >
//             {direction === 0 ? "Clockwise" : "Counter-Clockwise"}
//           </Typography>
//         )}
//         {motorStatus === 0 && (
//           <Typography
//             variant="h5" // Increased size
//             sx={{ fontWeight: "bold", marginTop: 3, color: "red" }}
//           >
//             Motor Stopped
//           </Typography>
//         )}
//       </Card>
//     </Grid>
//   );
// };

// export default RotatingMotor;






import React, { useEffect } from 'react';
import { Grid, Card, Typography } from '@mui/material';
import { motion } from 'framer-motion';
import SettingsIcon from '@mui/icons-material/Settings';

const RotatingMotor = ({ runningStatus }) => {
  useEffect(() => {
    console.log("Running Status:", runningStatus);
  }, [runningStatus]); // Logs when runningStatus changes

  if (!runningStatus) {
    return <div>Loading...</div>; // Handle undefined case
  }

  // Default values in case runningStatus is missing some properties
  const motorRunning = runningStatus?.motorRunning ?? false;
  const motorDirectionCW = runningStatus?.motorDirectionCW ?? true;

  const motorColor = motorRunning ? "blue" : "gray";
  const rotationDirection = motorDirectionCW ? "Clockwise" : "Counter-Clockwise";

  return (
    <Grid item xs={12} sm={6} md={12}>
      <Card
        sx={{
          boxShadow: 0,
          borderRadius: 2,
          height: "95%",
          marginTop: "5%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: 0,
        }}
      >
        {/* Animated Motor Icon */}
        <motion.div
          animate={motorRunning ? { rotate: motorDirectionCW ? 360 : -360 } : { rotate: 0 }}
          transition={motorRunning ? { repeat: Infinity, duration: 5, ease: "linear" } : {}}
        >
          <SettingsIcon sx={{ fontSize: 100, color: motorColor }} />
        </motion.div>

        {/* Text Displaying Rotation Direction */}
        <Typography
          variant="h5"
          sx={{
            fontWeight: "bold",
            marginTop: 3,
            color: motorRunning ? "green" : "red",
            fontFamily: "'Times New Roman', serif" 
          }}
        >
          {motorRunning ? rotationDirection : "Motor Stopped"}
        </Typography>
      </Card>
    </Grid>
  );
};

export default RotatingMotor;
