import React, { useState, useEffect, useRef } from "react";
import { Line } from "react-chartjs-2";
import { Box, Typography, Button } from "@mui/material";
import { Chart as ChartJS, LineElement, CategoryScale, LinearScale, Title, Tooltip, Legend, PointElement } from "chart.js";

// Register necessary components for Chart.js
ChartJS.register(LineElement, CategoryScale, LinearScale, Title, Tooltip, Legend, PointElement);

const LiveLineChart = () => {
    const [chartData, setChartData] = useState({
        labels: [],  // x-axis labels (time)
        datasets: [
            {
                label: "Live Data",
                data: [],
                borderColor: "rgba(75, 192, 192, 1)",
                backgroundColor: "rgba(75, 192, 192, 0.2)",
                fill: true,
                tension: 0.1,
            },
        ],
    });

    const chartRef = useRef(null); // Use a ref to access the chart instance

    // Simulate live data by adding new points to the chart
    useEffect(() => {
        const interval = setInterval(() => {
            const currentTime = new Date().toLocaleTimeString(); // Get current time as label
            const newDataPoint = Math.floor(Math.random() * 100); // Random data point

            setChartData((prevData) => {
                const newLabels = [...prevData.labels, currentTime].slice(-1000);
                const newData = [...prevData.datasets[0].data, newDataPoint].slice(-1000);

                return {
                    labels: newLabels,
                    datasets: [
                        {
                            ...prevData.datasets[0],
                            data: newData,
                        },
                    ],
                };
            });

            // Destroy previous chart if it exists before rendering a new one
            if (chartRef.current && chartRef.current.chartInstance) {
                chartRef.current.chartInstance.destroy(); // Destroy the old chart instance
            }
        }, 2000); // Update every 2 seconds

        // Cleanup on component unmount
        return () => clearInterval(interval);
    }, []);

    return (
        <Box sx={{ width: "80%", margin: "auto", textAlign: "center" }}>
            <Typography variant="h4" gutterBottom>
                Live Doppler Weather Radar Status
            </Typography>
            <Line ref={chartRef} data={chartData} /> {/* Pass the ref to the chart */}
            <Button
                variant="contained"
                color="primary"
                sx={{ marginTop: "20px" }}
                onClick={() => setChartData({ ...chartData, labels: [], datasets: [{ ...chartData.datasets[0], data: [] }] })}
            >
                Reset Data
            </Button>
        </Box>
    );
};

export default LiveLineChart;
