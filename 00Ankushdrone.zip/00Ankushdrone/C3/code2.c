#include <stdio.h>
#include <math.h>  // Include math.h for sqrt function

// Documentation
// Function: calculate_points
// Author: 
// Description: This function calculates intermediate 3D points between two given points using double precision.
// Inputs: 
//   - x1, y1, z1: Coordinates of the first point (starting point).
//   - x2, y2, z2: Coordinates of the second point (ending point).
//   - num_points: The number of intermediate points to calculate (including start and end points).
// Output: Prints the 3D coordinates for the start point, intermediate points, and the end point.

void calculate_points(double x1, double y1, double z1, double x2, double y2, double z2, int num_points) {
    // Calculate step sizes for interpolation in each coordinate
    double step_x = (x2 - x1) / (num_points - 1);
    double step_y = (y2 - y1) / (num_points - 1);
    double step_z = (z2 - z1) / (num_points - 1);

    // Print the points
    int i;
    for (i = 0; i < num_points; i++) {
        double x = x1 + i * step_x;
        double y = y1 + i * step_y;
        double z = z1 + i * step_z;
        printf("%.4f %.4f %.4f\n", x, y, z);
    }
}

// Define a struct to hold point coordinates
struct Point {
    double x, y, z;
};

int main() {
    // Hard-coded array of 10 predefined points
    struct Point points[12] = {
        // {0.0, 0.0, 0.0},   // Point 1
        // {1.0, 2.0, 3.0},   // Point 2
        // {2.0, 3.0, 4.0},   // Point 3
        // {3.0, 4.0, 5.0},   // Point 4
        // {4.0, 5.0, 6.0},   // Point 5
        // {5.0, 6.0, 7.0},   // Point 6
        // {6.0, 7.0, 8.0},   // Point 7
        // {7.0, 8.0, 9.0},   // Point 8
        // {8.0, 9.0, 10.0},  // Point 9
        // {9.0, 10.0, 11.0}  // Point 10
        {0.0 ,0.0 ,0.0 },
        {2.0 ,0.0 ,0.0 },
        {2.0 ,0.0 ,1.0 },
        {2.0 ,0.0 ,3.0 },
        {2.5 ,0.0 ,3.0 },
        {2.5 ,0.0 ,1.0 },
        {3.0 ,0.0 ,1.0 },
        {3.0 ,0.0 ,3.0 },
        {3.5 ,0.0 ,3.0 },
        {3.5 ,0.0 ,1.0 },
        {4.0 ,0.0 ,1.0 },
        {4.0 ,0.0 ,3.0 }

    };

    int num_intermediate_points;  // Number of intermediate points

    // Display the hard-coded points
    printf("Predefined Points:\n");
    for (int i = 0; i < 10; i++) {
        printf("Point %d: %.4f %.4f %.4f\n", i + 1, points[i].x, points[i].y, points[i].z);
    }

    // Ask the user for the number of intermediate points to calculate
    printf("\nEnter the number of intermediate points to calculate between consecutive points: ");
    scanf("%d", &num_intermediate_points);

    // Call calculate_points function for each pair of consecutive points
    for (int i = 0; i < 9; i++) {  // Iterate for pairs of points (10 points = 9 pairs)
        // Calculate and print the distance between the points
        double distance = sqrt(pow(points[i+1].x - points[i].x, 2) + 
                               pow(points[i+1].y - points[i].y, 2) + 
                               pow(points[i+1].z - points[i].z, 2));
        printf("\nDistance between point %d and point %d: %.4f\n", i + 1, i + 2, distance);
        
        // Call the function to calculate intermediate points
        printf("Intermediate points between point %d and point %d:\n", i + 1, i + 2);
        calculate_points(points[i].x, points[i].y, points[i].z, points[i+1].x, points[i+1].y, points[i+1].z, num_intermediate_points);
    }

    return 0;
}
