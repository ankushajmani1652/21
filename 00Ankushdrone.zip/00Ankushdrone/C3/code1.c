#include <stdio.h>
#include <math.h>

// Define M_PI if not defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Convert degrees to radians
#define DEG_TO_RAD(angle) ((angle) * M_PI / 180.0)

// Struct to represent 3D coordinates
typedef struct {
    double x;
    double y;
    double z;
} Coordinate;

// Function to calculate the next 3D coordinate
void cal_coordinates(Coordinate start, double azimuth_deg, double elevation_deg, double distance, Coordinate *next) {
    // Convert angles to radians
    double azimuth_rad = DEG_TO_RAD(azimuth_deg);
    double elevation_rad = DEG_TO_RAD(elevation_deg);

    // Calculate new coordinates
    next->x = start.x + distance * cos(elevation_rad) * cos(azimuth_rad);
    next->y = start.y + distance * cos(elevation_rad) * sin(azimuth_rad);
    next->z = start.z + distance * sin(elevation_rad);
}

int main() {
    Coordinate current, next;
    double azimuth_deg, elevation_deg;
    double distance;
    char continue_calculation;
    
    // Define a maximum number of coordinates to store
    int max_coordinates = 100;
    Coordinate coordinates[max_coordinates];
    int count = 0; // Keeps track of how many coordinates have been stored

    // Input initial position
    printf("Enter initial coordinates (x0 y0 z0): ");
    scanf("%lf %lf %lf", &current.x, &current.y, &current.z);

    // Save the initial coordinates in the array
    coordinates[count++] = current;

    // Input azimuthal angle (only once, locked)
    printf("Enter azimuthal angle (degrees): ");
    scanf("%lf", &azimuth_deg);

    do {
        // Input elevation angle and distance
        printf("Enter elevation angle (degrees): ");
        scanf("%lf", &elevation_deg);

        printf("Enter distance to move: ");
        scanf("%lf", &distance);

        // Call the function to calculate the next coordinates
        cal_coordinates(current, azimuth_deg, elevation_deg, distance, &next);

        // Output result
        printf("Next coordinates: (%.3f, %.3f, %.3f)\n", next.x, next.y, next.z);

        // Save the calculated coordinates in the array
        if (count < max_coordinates) {
            coordinates[count++] = next;
        } else {
            printf("Coordinate array is full!\n");
            break;
        }

        // Update the current coordinates to the new ones
        current = next;

        // Ask user if they want to calculate the next coordinates
        printf("Do you want to calculate the next coordinates? (y/n): ");
        scanf(" %c", &continue_calculation);  // Space before %c to handle any extra newlines

    } while (continue_calculation == 'y' || continue_calculation == 'Y');

    // Output all stored coordinates
    printf("\nAll calculated coordinates:\n");
    for (int i = 0; i < count; i++) {
        printf("Coordinate %d: (%.3f, %.3f, %.3f)\n", i + 1, coordinates[i].x, coordinates[i].y, coordinates[i].z);
    }

    printf("Program ended.\n");

    return 0;
}
