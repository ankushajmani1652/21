#include <stdio.h>
#include <math.h>

// Documentation
// Function: calculate_points_by_interval
// Author: 
// Description: This function calculates intermediate 3D points between two given points based on velocity and time interval input.
// Inputs:
//   - x1, y1, z1: Coordinates of the first point (starting point).
//   - x2, y2, z2: Coordinates of the second point (ending point).
//   - velocity: The velocity of the object (in units per second).
//   - time_interval: The time interval in seconds after which the points should be calculated.
// Output: Prints the 3D coordinates for the start point, intermediate points, and the end point.

void calculate_points_by_interval(double x1, double y1, double z1,
                                  double x2, double y2, double z2,
                                  double velocity, double time_interval) {
    // Compute total distance between the two points
    double dx = x2 - x1;
    double dy = y2 - y1;
    double dz = z2 - z1;
    double distance = sqrt(dx*dx + dy*dy + dz*dz);

    // Calculate total time of travel
    double total_time = distance / velocity;

    // Calculate the number of points based on time interval
    int num_points = (int)(total_time / time_interval) + 1;

    // Steps
    double step_x = dx / (num_points - 1);
    double step_y = dy / (num_points - 1);
    double step_z = dz / (num_points - 1);

    // Print the points
    for (int i = 0; i < num_points; i++) {
        double x = x1 + i * step_x;
        double y = y1 + i * step_y;
        double z = z1 + i * step_z;

        // Calculate the time at which each point occurs
        double time_at_point = i * time_interval;

        // Print the 3D point and the time
        printf("Point %.2f: %.2f %.2f %.2f at time %.2f seconds\n", (double)i + 1, x, y, z, time_at_point);
    }
}

int main() {
    double x1, y1, z1, x2, y2, z2, velocity, time_interval;

    // Ask the user for the coordinates of the first and second points
    printf("Enter the coordinates of the first point (x1 y1 z1): ");
    scanf("%lf %lf %lf", &x1, &y1, &z1);

    printf("Enter the coordinates of the second point (x2 y2 z2): ");
    scanf("%lf %lf %lf", &x2, &y2, &z2);

    // Ask the user for the velocity and time interval
    printf("Enter the velocity of the object (units per second): ");
    scanf("%lf", &velocity);

    printf("Enter the time interval (in seconds) to calculate points: ");
    scanf("%lf", &time_interval);

    // Call the function to calculate the points
    calculate_points_by_interval(x1, y1, z1, x2, y2, z2, velocity, time_interval);

    return 0;
}
