/**
 * @brief Calculate azimuthal angle, elevation angle, and distance for a set of 3D points.
 * @author 
 */

 #include <stdio.h>
 #include <math.h>
 
 #define PI 3.14159265358979323846
 
 // Define a structure to represent a 3D point
 struct Point {
     double x;
     double y;
     double z;
 };
 
 // Function to calculate azimuthal, elevation angles, and distance
 void calculateAnglesAndDistance(struct Point p) {
     // Calculate azimuthal angle (in radians)
     double azimuthal = atan2(p.y, p.x);
 
     // Calculate elevation angle (in radians)
     double distanceXY = sqrt(p.x * p.x + p.y * p.y);
     double elevation = atan2(p.z, distanceXY);
 
     // Calculate distance from origin
     double distance = sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
 
     // Convert angles from radians to degrees
     azimuthal = azimuthal * (180.0 / PI);
     elevation = elevation * (180.0 / PI);
 
     // Output the results
     printf("Point (%.2f, %.2f, %.2f):\n", p.x, p.y, p.z);
     printf("  Azimuthal angle: %.2f degrees\n", azimuthal);
     printf("  Elevation angle: %.2f degrees\n", elevation);
     printf("  Distance from origin: %.2f units\n\n", distance);
 }
 
 int main() {
     // Array of predefined points
     struct Point points[12] = {
         {0.0 ,0.0 ,0.0 },
         {2.0 ,0.0 ,0.0 },
         {2.0 ,0.0 ,1.0 },
         {2.0 ,0.0 ,3.0 },
         {2.5 ,0.0 ,3.0 },
         {2.5 ,0.0 ,1.0 },
         {3.0 ,0.0 ,1.0 },
         {3.0 ,0.0 ,3.0 },
         {3.5 ,0.0 ,3.0 },
         {3.5 ,0.0 ,1.0 },
         {4.0 ,0.0 ,1.0 },
         {4.0 ,0.0 ,3.0 }
     };
 
     // Loop through all points and calculate angles and distance
     for (int i = 0; i < 12; i++) {
         calculateAnglesAndDistance(points[i]);
     }
 
     return 0;

 }
 