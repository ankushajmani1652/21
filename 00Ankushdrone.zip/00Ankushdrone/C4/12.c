#include <stdio.h>
#include <math.h>

/* Struct to represent a 3D point */
typedef struct {
    double x;
    double y;
    double z;
    double Dist;
    double ;
} structpoint;

structpoint drone_point[2] = {
    {0.0, 0.0, 0.0,0},  // Point 1
    {10.0, 0.0, 0.0,0},  // Point 2
};

/* Function to calculate and print positions at each time interval */
void calculateMotion(structpoint* drone_point) {

    double velocity, timeInterval;
    // Get velocity and time interval from the user
    printf("Enter the velocity (in m/s): ");
    scanf("%lf", &velocity);

    printf("Enter the time interval (in seconds): ");
    scanf("%lf", &timeInterval);

    // Calculate the total displacement vector
    double dx = drone_point[1].x - drone_point[0].x;
    double dy = drone_point[1].y - drone_point[0].y;
    double dz = drone_point[1].z - drone_point[0].z;
    drone_point[1].Dist = sqrt(dx * dx 
        + dy * dy + dz * dz);

    // Calculate the total time to travel the distance
    double totalTime = drone_point[1].Dist / velocity;

    printf("Total distance: %lf\n", drone_point[1].Dist);
    printf("Total time: %lf\n", totalTime);

    // Print the total number of steps
    printf("Total timeInterval: %lf\n", timeInterval);
    // Calculate the number of steps based on total time and time interval
    double totalSteps = (totalTime / timeInterval);

    printf("Total totalSteps: %lf\n", totalSteps);
    // Step size based on velocity and time interval
    double stepSize = drone_point[1].Dist * totalSteps;
    printf("\n--- Position at each time interval ---\n");

    // Interpolated positions using 't' and step size
    double x = drone_point[0].x; 
    double y = drone_point[0].y;
    double z = drone_point[0].z;
    double stepsize_x = dx / totalSteps;
    double stepsize_y = dy / totalSteps;
    double stepsize_z = dz / totalSteps;

    for (int i = 1; i <= (int) (totalSteps); ++i) {
        //Position based on step size
        x += stepsize_x;
        y += stepsize_y;
        z += stepsize_z;
        
        // Calculate the current time
        double currentTime = i * timeInterval;
        printf("Step: %d, Time: %.6lf s -> ,Step-based Position: (%.6lf, %.6lf, %.6lf)\n",
                i, currentTime, x, y, z);
    }

    printf("Total distance: %lf\n", drone_point[1].Dist);
    // Print the total number of steps
    // printf("Total steps: %lf\n", Steps);
    // Print the total number of steps
    printf("Total time: %lf\n", totalTime);
    // Print the total number of steps
    printf("Total timeInterval: %lf\n", timeInterval);

    printf("Total totalSteps: %lf\n", totalSteps);

    // Print final destination point using interpolation
    printf("Final Position: (%.6lf, %.6lf, %.6lf) at Time: %.6lf s\n", drone_point[1].x, drone_point[1].y, drone_point[1].z, totalTime);
}

int main() {
    // Call the motion calculation function with velocity and time interval as parameters
    calculateMotion(drone_point);

    return 0;
}
