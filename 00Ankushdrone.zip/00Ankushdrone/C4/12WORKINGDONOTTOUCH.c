#include <stdio.h>
#include <math.h>

/* Struct to represent a 3D point */
typedef struct {
    double x;
    double y;
    double z;
    double totalDist;
} Point;

Point points[2] = {
    {0.0, 0.0, 0.0,0},  // Point 1
    {10.0, 0.0, 0.0,0},  // Point 2
};

/* Function to calculate and print positions at each time interval */
void calculateMotion(Point points[], double velocity, double timeInterval) {
    // Calculate the total displacement vector
    double dx = points[1].x - points[0].x;
    double dy = points[1].y - points[0].y;
    double dz = points[1].z - points[0].z;
    points[1].totalDist = sqrt(dx * dx + dy * dy + dz * dz);

    // Calculate the total time to travel the distance
    double totalTime = points[1].totalDist / velocity;

    // Calculate the number of steps based on total time and time interval
    int totalSteps = (int)(totalTime / timeInterval);

    // Print the total number of steps
    printf("Total steps: %d\n", totalSteps);

    // Step size based on velocity and time interval
    double stepSize = velocity * timeInterval;

    printf("\n--- Position at each time interval ---\n");

    // Interpolated positions using 't' and step size
    double x = points[0].x; 
    double y = points[0].y;
    double z = points[0].z;

    int i;
    for (i = 1; i <= totalSteps; ++i) {
        double t = (double)i / totalSteps;  // Interpolation factor (0 to 1)

        // // Interpolated position using t
        // double interpolatedX = points[0].x + t * (points[1].x - points[0].x);
        // double interpolatedY = points[0].y + t * (points[1].y - points[0].y);
        // double interpolatedZ = points[0].z + t * (points[1].z - points[0].z);

        // Position based on step size
        x += dx / totalSteps;
        y += dy / totalSteps;
        z += dz / totalSteps;

        // Calculate the current time
        double currentTime = i * timeInterval;

        // printf("Step: %d, Time: %.4lf s -> Interpolated Position: (%.4lf, %.4lf, %.4lf), Step-based Position: (%.4lf, %.4lf, %.4lf)\n",
        //        i, currentTime, interpolatedX, interpolatedY, interpolatedZ, x, y, z);

        printf("Step: %d, Time: %.4lf s -> ,Step-based Position: (%.4lf, %.4lf, %.4lf)\n",
                i, currentTime, x, y, z);



    }

    // Print final destination point using interpolation
    printf("Final Position: (%.4lf, %.4lf, %.4lf) at Time: %.4lf s\n", points[1].x, points[1].y, points[1].z, totalTime);
}

int main() {
    double velocity, timeInterval;

    // Get velocity and time interval from the user
    printf("Enter the velocity (in m/s): ");
    scanf("%lf", &velocity);

    printf("Enter the time interval (in seconds): ");
    scanf("%lf", &timeInterval);

    // Call the motion calculation function with velocity and time interval as parameters
    calculateMotion(points, velocity, timeInterval);

    return 0;
}
