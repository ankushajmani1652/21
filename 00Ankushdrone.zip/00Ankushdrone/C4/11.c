#include <stdio.h>
#include <math.h>

// Documentation:
// This program simulates 3D drone movement based on user inputs for base, height,
// and repeated vertical/horizontal path segments. It calculates total distance traveled.
// Author: 

// Define M_PI if not defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define MAX_STEPS 1000
#define DEG_TO_RAD(angle_in_degrees) ((angle_in_degrees) * M_PI / 180.0)

typedef struct {
    double x;
    double y;
    double z;
    double distance;
    double weight;
} structpoint;

structpoint point[MAX_STEPS];

double azimuthal_deg;

void initialize_point(structpoint* point, double x, double y, double z) {
    point->x = x;
    point->y = y;
    point->z = z;
    point->distance = 0.0;
    point->weight = 0.0;
}

void travel(structpoint* point, double azimuthal_deg, double elevation_deg, double distance) {
    double azimuthal_rad = DEG_TO_RAD(azimuthal_deg);
    double elevation_rad = DEG_TO_RAD(elevation_deg);

    point->x += distance * cos(elevation_rad) * cos(azimuthal_rad);
    point->y += distance * cos(elevation_rad) * sin(azimuthal_rad);
    point->z += distance * sin(elevation_rad);
}

void start_position(structpoint* point, int* step) {
    double base, height;
    
    printf("Enter the base: ");
    scanf("%lf", &base);

    printf("Enter the height: ");
    scanf("%lf", &height);

    point[*step] = point[*step - 1];
    travel(&point[*step], azimuthal_deg, 0, base);
    (*step)++;

    printf("Step %d: (%.4f, %.4f, %.4f)\n", *step - 1, point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);

    point[*step] = point[*step - 1];
    travel(&point[*step], azimuthal_deg, 90, height);
    (*step)++;

    printf("Step %d: (%.4f, %.4f, %.4f)\n", *step - 1, point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);
}

void Path2(structpoint* point, float azimuthal_deg, int *step) {
    double vm, hm;
    printf("Enter the distance of vertical movement: ");
    scanf("%lf",&vm);
    printf("Enter the distance of horizontal movement: ");
    scanf("%lf",&hm);   
    
    int lap=5;
    for (int i = 0; i < lap; i++) {
        point[*step] = point[*step - 1];
        int vertical_angle = (i % 2 == 0) ? 90 : -90;
        travel(&point[*step], azimuthal_deg, vertical_angle, vm);
        (*step)++;
        printf("Current position: (%.4f, %.4f, %.4f)\n", 
            point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);
            if(i!=(lap-1)){
                point[*step] = point[*step - 1];
                travel(&point[*step], azimuthal_deg, 0, hm);
                (*step)++;
                printf("Current position: (%.4f, %.4f, %.4f)\n", 
                    point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);
            }
        }
    }

double calculator(structpoint* point, int* step) {
    double total = 0;
    for (int i = 1; i < *step; i++) {
        point[i].distance = sqrt(pow(point[i].x - point[i - 1].x, 2) +
                                 pow(point[i].y - point[i - 1].y, 2) +
                                 pow(point[i].z - point[i - 1].z, 2));
        total += point[i].distance;
    }
    return total;
}

int main() {
    int step = 0;

    initialize_point(&point[step], 0.0, 0.0, 0.0);
    printf("Starting at the origin (0, 0, 0)\n");
    step++;

    // printf("Enter fixed azimuthal angle (in degrees): ");
    // scanf("%lf", &azimuthal_deg);
    // printf("Enter the base: ");
    // scanf("%lf", &base);
    // printf("Enter the height: ");
    // scanf("%lf", &height);

    printf("Enter fixed azimuthal angle (in degrees): ");
    scanf("%lf", &azimuthal_deg);

    start_position(point, &step);    // first two moves

    Path2(point, azimuthal_deg, &step);                // repeating up/down path

    double totaldistance = calculator(point, &step);

    printf("\n--- Path Traveled ---\n");
    for (int i = 2; i < step; i++) {
        printf("Step %d: (%.4f, %.4f, %.4f), Distance: %.4f\n", i, point[i].x, point[i].y, point[i].z, point[i].distance);
    }

    printf("Total steps: %d\n", step);
    printf("Total distance: %.4lf\n", totaldistance);

    return 0;
}
