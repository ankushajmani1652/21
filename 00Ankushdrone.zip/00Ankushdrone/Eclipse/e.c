/*
 * Program to generate an upright ellipse in the XZ plane
 * 
 * Author:
 * Date: 17-Apr-2025
 * Description:
 *   - Major axis lies in the XY base (specifically X direction)
 *   - Minor axis is vertical along Z
 *   - Y coordinate stays constant (no tilt)
 *   - Output written to 'ellipse_points.csv'
 */

 #include <stdio.h>
 #include <math.h>
 
 #define PI 3.14159265
 #define TOTAL_POINTS 1000
 
 int main() {
     // Ellipse parameters
     double a = 3.0;   // Major axis in X direction
     double b = 1.0;   // Minor axis in Z direction
     double h = 2.5;   // Center X
     double k = 2.5;   // Center Y (fixed)
     double l = 2.0;   // Center Z
 
     FILE *fp = fopen("ellipse_points.csv", "w");
     if (fp == NULL) {
         printf("Error: Cannot create file.\n");
         return 1;
     }
 
     fprintf(fp, "X,Y,Z\n");
 
     for (int i = 0; i < TOTAL_POINTS; i++) {
         double theta = (2 * PI * i) / TOTAL_POINTS;
 
         double x = h + a * cos(theta);  // Horizontal span (major axis)
         double y = k;                   // Fixed Y → upright in XZ
         double z = l + b * sin(theta);  // Vertical variation (minor axis)
 
         fprintf(fp, "%lf,%lf,%lf\n", x, y, z);
     }
 
     fclose(fp);
     printf("Upright ellipse (XZ plane) saved to 'ellipse_points.csv'\n");
 
     return 0;
 }
 