#include <stdio.h>
#include <math.h>

// Define M_PI if not defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define MAX_STEPS 1000
#define DEG_TO_RAD(angle_in_degrees) ((angle_in_degrees) * M_PI / 180.0)

// Define a structure to store a point in 3D space
typedef struct {
    double x;
    double y;
    double z;
    double distance;
    double weight;
} structpoint;

// Function to move in a fixed azimuthal direction
void travel(structpoint* point, double azimuthal_deg, double elevation_deg, double distance) {
    double azimuthal_rad = DEG_TO_RAD(azimuthal_deg);
    double elevation_rad = DEG_TO_RAD(elevation_deg);

    point->x += distance * cos(elevation_rad) * cos(azimuthal_rad);
    point->y += distance * cos(elevation_rad) * sin(azimuthal_rad);
    point->z += distance * sin(elevation_rad);
}

structpoint point[MAX_STEPS];  // Array of point to store the path

void Path2(structpoint* point, float azimuthal_deg, float vm, float hm, int *step) {
    int lap=5;
    for (int i = 0; i < lap; i++) {
        point[*step] = point[*step - 1];
        int vertical_angle = (i % 2 == 0) ? 90 : -90;
        travel(&point[*step], azimuthal_deg, vertical_angle, vm);
        // point[*step].distance = sqrt(pow((point[*step].x - point[*step-1].x),2)
        //                         +   pow((point[*step].y - point[*step-1].y),2)
        //                         +   pow((point[*step].z - point[*step-1].z),2));

        (*step)++;
        printf("Current position: (%.4f, %.4f, %.4f)\n", 
            point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);

        if(i!=(lap-1)){
            // printf("Ankush %d\n",i);
            point[*step] = point[*step - 1];
            travel(&point[*step], azimuthal_deg, 0, hm);
            // point[*step].distance = sqrt(pow((point[*step].x - point[*step-1].x),2)
            //                     +   pow((point[*step].y - point[*step-1].y),2)
            //                     +   pow((point[*step].z - point[*step-1].z),2));
            (*step)++;
            printf("Current position: (%.4f, %.4f, %.4f)\n", 
                point[*step - 1].x, point[*step - 1].y, point[*step - 1].z);
        }
    }
}

double calculator(structpoint* point, int *step){
    double td=0;
    for(int i=1; i< *step ;i++){
        point[i].distance = sqrt(pow((point[i].x - point[i-1].x),2)
                                +   pow((point[i].y - point[i-1].y),2)
                                +   pow((point[i].z - point[i-1].z),2));           
        td += point[i].distance;
    }
    return td;    
}

double totaldistance=0;

int main() {
    double azimuthal_deg, elevation_deg, distance;
    int step = 0;
    

    // Start at the origin (0, 0, 0)
    point[step].x = 0.0;
    point[step].y = 0.0;
    point[step].z = 0.0;
    step++;

    printf("Starting at the origin (0, 0, 0)\n");
    printf("Enter fixed azimuthal angle (in degrees): ");
    scanf("%lf", &azimuthal_deg);

    double base, height, vm, hm;
    printf("Enter the base: ");
    scanf("%lf",&base);
    // Movement along base
    point[step] = point[step - 1];
    travel(&point[step], azimuthal_deg, 0, base);
    step++;
    printf("Current position: (%.4f, %.4f, %.4f)\n", point[step - 1].x, point[step - 1].y, point[step - 1].z);


    printf("Enter the height: ");
    scanf("%lf",&height);
    // Movement along height
    point[step] = point[step - 1];
    travel(&point[step], azimuthal_deg, 90, height);
    step++;
    printf("Current position: (%.4f, %.4f, %.4f)\n", point[step - 1].x, point[step - 1].y, point[step - 1].z);
   
    printf("Enter the distance of vertical movement: ");
    scanf("%lf",&vm);

    printf("Enter the distance of horizontal movement: ");
    scanf("%lf",&hm);

    Path2(point, azimuthal_deg, vm, hm, &step);
    totaldistance = calculator(point, &step);

    // Print the full path
    printf("\n--- Path Traveled ---\n");
    for (int i = 0; i < step; i++) {
        printf("Step %d: (%.4f, %.4f, %.4f), Distance: %.4f\n", i, point[i].x, point[i].y, point[i].z, point[i].distance) ;
    }
    printf("Total steps: %d\n", step);
    printf("Total distance: %.4lf\n", totaldistance);
    return 0;

}
