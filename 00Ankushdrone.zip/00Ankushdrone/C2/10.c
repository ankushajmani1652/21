#include <stdio.h>
#include <math.h>

#define MAX_STEPS 1000
#define DEG_TO_RAD(angle_in_degrees) ((angle_in_degrees) * M_PI / 180.0)

// Define a structure to store a point in 3D space
typedef struct {
    double x;
    double y;
    double z;
} Point;

// Function to move in a fixed azimuthal direction
void travel(Point* point, double azimuthal_deg, double elevation_deg, double distance) {
    double azimuthal_rad = DEG_TO_RAD(azimuthal_deg);
    double elevation_rad = DEG_TO_RAD(elevation_deg);

    point->x += distance * cos(elevation_rad) * cos(azimuthal_rad);
    point->y += distance * cos(elevation_rad) * sin(azimuthal_rad);
    point->z += distance * sin(elevation_rad);
}

int main() {
    Point points[MAX_STEPS];  // Array of points to store the path
    double azimuthal_deg, elevation_deg, distance;
    char choice;
    int step = 0;

    // Start at the origin (0, 0, 0)
    points[step].x = 0.0;
    points[step].y = 0.0;
    points[step].z = 0.0;
    step++;

    printf("Starting at the origin (0, 0, 0)\n");
    printf("Enter fixed azimuthal angle (in degrees): ");
    scanf("%lf", &azimuthal_deg);

    do {
        printf("\nEnter elevation angle (degrees): ");
        scanf("%lf", &elevation_deg);

        printf("Enter distance to travel: ");
        scanf("%lf", &distance);

        // Travel to the new point
        travel(&points[step - 1], azimuthal_deg, elevation_deg, distance);

        if (step < MAX_STEPS) {
            points[step] = points[step - 1];  // Store the new point
            step++;
        } else {
            printf("Maximum path steps reached!\n");
            break;
        }

        printf("Current position: (%.2f, %.2f, %.2f)\n", points[step - 1].x, points[step - 1].y, points[step - 1].z);
        printf("Continue traveling? (y/n): ");
        scanf(" %c", &choice);

    } while ((choice == 'y' || choice == 'Y') && step < MAX_STEPS);

    // Print the full path
    printf("\n--- Path Traveled ---\n");
    for (int i = 0; i < step; i++) {
        printf("Step %d: (%.2f, %.2f, %.2f)\n", i, points[i].x, points[i].y, points[i].z);
    }

    printf("Final position: (%.2f, %.2f, %.2f)\n", points[step - 1].x, points[step - 1].y, points[step - 1].z);
    printf("Total steps: %d\n", step);

    return 0;
}
