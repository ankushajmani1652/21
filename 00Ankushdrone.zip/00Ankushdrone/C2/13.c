#include <stdio.h>
#include <math.h>

/* Struct to represent a 3D point */
typedef struct {
    float x;
    float y;
    float z;
} Point;

/* Function to get two 3D points from the user */
void get3DPoints(Point points[]) {
    for (int i = 0; i < 2; ++i) {
        printf("Enter coordinates for Point %d (x y z): ", i + 1);
        scanf("%f %f %f", &points[i].x, &points[i].y, &points[i].z);
    }
}

/* Function to calculate and print points at each interval */
void calculateMotion(Point points[], float velocity, float timeInterval) {
    // Calculate distance between points[0] and points[1]
    float dx = points[1].x - points[0].x;
    float dy = points[1].y - points[0].y;
    float dz = points[1].z - points[0].z;
    float distance = sqrt(dx*dx + dy*dy + dz*dz);

    // Calculate total time to travel the distance
    float totalTime = distance / velocity;

    // Calculate the number of points based on total time and time interval
    int totalPoints = (int)(totalTime / timeInterval);

    























    // Normalize the direction vector
    float ux = dx / distance;
    float uy = dy / distance;
    float uz = dz / distance;

    printf("\n--- Position at each time interval ---\n");
    for (int i = 1; i <= totalPoints; ++i) {
        float t = i * timeInterval;
        float displacement = velocity * t;

        float x = points[0].x + ux * displacement;
        float y = points[0].y + uy * displacement;
        float z = points[0].z + uz * displacement;

        printf("Time: %.4f s -> Position: (%.4f, %.4f, %.4f)\n", t, x, y, z);
    }

    // Print final destination point
    printf("Final Position Reached: (%.4f, %.4f, %.4f) at Time: %.4f s\n",
           points[1].x, points[1].y, points[1].z, totalTime);
}

int main() {
    Point points[2];
    float velocity, timeInterval;

    // Get the two points from the user
    get3DPoints(points);

    // Get velocity and time interval from the user
    printf("Enter the velocity (in m/s): ");
    scanf("%f", &velocity);

    printf("Enter the time interval (in seconds): ");
    scanf("%f", &timeInterval);

    // Call the motion calculation function with velocity and time interval as parameters
    calculateMotion(points, velocity, timeInterval);

    return 0;
}
