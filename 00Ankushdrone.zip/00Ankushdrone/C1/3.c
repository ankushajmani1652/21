/*
 * File: interpolate_points.c
 * ---------------------------
 * Description:
 *   This program asks the user for the total number of points, including
 *   the start and end points. It calculates the required number of 
 *   intermediate points and prints all the points.
 *
 *   The total number of points will be distributed between the start and 
 *   end points, and the intermediate points will be calculated using 
 *   linear interpolation.
 *
 * Author: [Your Name]
 * Date: [Insert Date]
 */

 #include <stdio.h>

 /*
  * Define a struct for a 3D point
  */
 typedef struct {
     float x, y, z;
 } Point3D;
 
 /*
  * Function: calculateIntermediatePoints
  * -------------------------------------
  * Calculates the intermediate points between two 3D points, including the 
  * start and end points.
  *
  * Parameters:
  *   - endpoints: An array containing the start and end Point3D.
  *   - totalPoints: Total number of points (including start and end).
  *   - result: An array where the computed points will be stored.
  */
 void calculateIntermediatePoints(Point3D endpoints[2], int totalPoints, Point3D result[]) {
     for (int i = 0; i < totalPoints; i++) {
         float t = (float)i / (totalPoints - 1);  // t goes from 0 to 1
         result[i].x = endpoints[0].x + t * (endpoints[1].x - endpoints[0].x);
         result[i].y = endpoints[0].y + t * (endpoints[1].y - endpoints[0].y);
         result[i].z = endpoints[0].z + t * (endpoints[1].z - endpoints[0].z);
     }
 }
 
 int main() {
     Point3D endpoints[2];  // [0] is start, [1] is end
     int totalPoints;
 
     // Input for start point
     printf("Enter Start Point (x y z): ");
     scanf("%f %f %f", &endpoints[0].x, &endpoints[0].y, &endpoints[0].z);
 
     // Input for end point
     printf("Enter End Point (x y z): ");
     scanf("%f %f %f", &endpoints[1].x, &endpoints[1].y, &endpoints[1].z);
 
     // Ask the user for the total number of points
     printf("Enter the total number of points (including start and end): ");
     scanf("%d", &totalPoints);
 
     // Ensure there are at least 2 points
     if (totalPoints < 2) {
         printf("Error: The number of points must be at least 2 (including start and end).\n");
         return 1;
     }
 
     // Array to hold the computed points
     Point3D result[totalPoints];
 
     // Calculate the interpolated points
     calculateIntermediatePoints(endpoints, totalPoints, result);
 
     // Print the result
     printf("\nGenerated Points:\n");
     for (int i = 0; i < totalPoints; i++) {
         printf("Point %2d: (%.4f, %.4f, %.4f)\n", i + 1, result[i].x, result[i].y, result[i].z);
     }
 
     return 0;
 }
 
