Point 1:
  Coordinates: (1.00, 2.00, 3.00)
  Distance from origin: 3.74
  Azimuth: 1.11 radians (63.43 degrees)
  Elevation: 0.93 radians (53.13 degrees)

Point 2:
  Coordinates: (4.00, 5.00, 6.00)
  Distance from origin: 8.77
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.73 radians (41.80 degrees)

Point 3:
  Coordinates: (7.00, 8.00, 9.00)
  Distance from origin: 12.21
  Azimuth: 0.83 radians (47.69 degrees)
  Elevation: 0.69 radians (39.78 degrees)

Point 4:
  Coordinates: (10.00, 11.00, 12.00)
  Distance from origin: 18.44
  Azimuth: 0.83 radians (47.69 degrees)
  Elevation: 0.61 radians (35.11 degrees)

Point 5:
  Coordinates: (13.00, 14.00, 15.00)
  Distance from origin: 22.91
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.56 radians (32.09 degrees)

Point 6:
  Coordinates: (16.00, 17.00, 18.00)
  Distance from origin: 26.83
  Azimuth: 0.78 radians (44.72 degrees)
  Elevation: 0.52 radians (29.94 degrees)

Point 7:
  Coordinates: (19.00, 20.00, 21.00)
  Distance from origin: 30.88
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.49 radians (28.16 degrees)

Point 8:
  Coordinates: (22.00, 23.00, 24.00)
  Distance from origin: 34.94
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.47 radians (26.84 degrees)

Point 9:
  Coordinates: (25.00, 26.00, 27.00)
  Distance from origin: 39.05
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.45 radians (25.78 degrees)

Point 10:
  Coordinates: (28.00, 29.00, 30.00)
  Distance from origin: 43.18
  Azimuth: 0.79 radians (45.57 degrees)
  Elevation: 0.43 radians (24.66 degrees)

