#include <stdio.h>
#include <math.h>

// Define M_PI if not defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define MAX_POINTS 100  // Maximum number of points to store

// Structure to store a 3D point
typedef struct {
    double x, y, z;
} Point;

// Function to update a point using azimuthal and elevation angles, and distance
void calculate_final_point(Point *point, double azimuthal_angle, double elevation_angle, double distance) {
    // Convert angles from degrees to radians
    azimuthal_angle = azimuthal_angle * M_PI / 180.0;
    elevation_angle = elevation_angle * M_PI / 180.0;

    // Update the point based on spherical coordinates conversion
    point->x += distance * cos(elevation_angle) * cos(azimuthal_angle);
    point->y += distance * cos(elevation_angle) * sin(azimuthal_angle);
    point->z += distance * sin(elevation_angle);
}

// Function to print all stored points
void print_all_points(Point points[], int num_points) {
    printf("\nStored Points:\n");
    for (int i = 0; i < num_points; i++) {
        printf("Point %d: (%.2lf, %.2lf, %.2lf)\n", i + 1, points[i].x, points[i].y, points[i].z);
    }
}

int main() {
    double azimuthal_angle, elevation_angle, distance;
    Point points[MAX_POINTS];  // Array to store all points
    int num_points = 0;

    // Set the origin as the starting point
    points[0].x = 0.0;
    points[0].y = 0.0;
    points[0].z = 0.0;
    num_points = 1;

    // Ask for azimuthal angle (fixed for all steps)
    printf("Enter the azimuthal angle (in degrees): ");
    scanf("%lf", &azimuthal_angle);

    // Loop to calculate and store subsequent points
    while (1) {
        printf("\nEnter the elevation angle (in degrees): ");
        scanf("%lf", &elevation_angle);

        printf("Enter the distance to travel: ");
        scanf("%lf", &distance);

        if (num_points >= MAX_POINTS) {
            printf("Maximum number of points reached.\n");
            break;
        }

        // Copy previous point to the next slot before updating
        points[num_points] = points[num_points - 1];

        // Update the new point using the fixed azimuthal angle
        calculate_final_point(&points[num_points], azimuthal_angle, elevation_angle, distance);

        // Print the new point
        printf("The new point after traveling is: (%.2lf, %.2lf, %.2lf)\n",
               points[num_points].x, points[num_points].y, points[num_points].z);

        num_points++;

        // Ask if user wants to continue
        char cont;
        printf("Do you want to calculate another point? (y/n): ");
        scanf(" %c", &cont);

        if (cont != 'y' && cont != 'Y') {
            break;
        }
    }

    // Print all stored points
    print_all_points(points, num_points);

    return 0;
}

