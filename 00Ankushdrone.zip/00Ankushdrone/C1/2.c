#include <stdio.h>
#include <math.h>

#define MAX_POINTS 100        // Maximum number of movement steps
#define MAX_PATH_POINTS 100   // Maximum number of marked drone path points

// Structure to store a 3D point
typedef struct {
    double x, y, z;
} Point;

// Function to update a point using azimuthal and elevation angles, and distance
void calculate_final_point(Point *point, double azimuthal_angle, double elevation_angle, double distance) {
    // Convert angles from degrees to radians
    azimuthal_angle = azimuthal_angle * M_PI / 180.0;
    elevation_angle = elevation_angle * M_PI / 180.0;

    // Update the point based on spherical coordinates
    point->x += distance * cos(elevation_angle) * cos(azimuthal_angle);
    point->y += distance * cos(elevation_angle) * sin(azimuthal_angle);
    point->z += distance * sin(elevation_angle);
}

// Function to print all stored movement steps
void print_all_movement_points(Point points[], int num_points) {
    printf("\nAll Movement Points:\n");
    for (int i = 0; i < num_points; i++) {
        printf("Step %d: (%.2lf, %.2lf, %.2lf)\n", i + 1, points[i].x, points[i].y, points[i].z);
    }
}

// Function to print marked drone path points
void print_drone_path_points(Point path_points[], int num_path_points) {
    printf("\nDrone Path Points (Marked Locations):\n");
    for (int i = 0; i < num_path_points; i++) {
        printf("Path Point %d: (%.2lf, %.2lf, %.2lf)\n", i + 1, path_points[i].x, path_points[i].y, path_points[i].z);
    }
}

int main() {
    double azimuthal_angle, elevation_angle, distance;
    Point points[MAX_POINTS];       // Stores every movement step
    Point path_points[MAX_PATH_POINTS]; // Stores only marked path points
    int num_points = 0;
    int num_path_points = 0;

    // Set the origin as the starting point
    points[0].x = 0.0;
    points[0].y = 0.0;
    points[0].z = 0.0;
    num_points = 1;

    // Ask for fixed azimuthal angle once
    printf("Enter the azimuthal angle (in degrees): ");
    scanf("%lf", &azimuthal_angle);
    getchar();  // Clear newline character left by scanf

    // Flag to track if the user has marked a drone path point
    int marking_path_points = 0;

    // Start the movement loop
    while (1) {
        char cont;

        // Ask user for the next movement (elevation angle and distance)
        printf("\nEnter the elevation angle (in degrees): ");
        scanf("%lf", &elevation_angle);
        getchar();  // Clear newline character

        printf("Enter the distance to travel: ");
        scanf("%lf", &distance);
        getchar();  // Clear newline character

        if (num_points >= MAX_POINTS) {
            printf("Maximum number of movement steps reached.\n");
            break;
        }

        // Copy the previous point and update to the new position
        points[num_points] = points[num_points - 1];
        calculate_final_point(&points[num_points], azimuthal_angle, elevation_angle, distance);

        // Show the new point
        printf("New location after movement: (%.2lf, %.2lf, %.2lf)\n",
               points[num_points].x, points[num_points].y, points[num_points].z);

        num_points++;

        // If the user has already started marking drone path points, we automatically mark this one
        if (marking_path_points) {
            path_points[num_path_points] = points[num_points - 1];
            num_path_points++;
            printf("✅ Automatically marked as Drone Path Point %d.\n", num_path_points);
        } else {
            // Ask if user wants to mark this as a Drone Path Point
            char mark_point;
            printf("Mark this location as a Drone Path Point? (y/n): ");
            scanf(" %c", &mark_point);  // Space before %c to handle the buffer properly

            if ((mark_point == 'y' || mark_point == 'Y') && num_path_points < MAX_PATH_POINTS) {
                path_points[num_path_points] = points[num_points - 1];
                num_path_points++;
                marking_path_points = 1;  // Start automatically marking further points
                printf("✅ Marked as Drone Path Point %d.\n", num_path_points);
            }
        }

        // Ask if the user wants to continue moving or stop
        printf("Do you want to continue moving? (y/n): ");
        scanf(" %c", &cont);  // Space before %c to clear any leftover newline

        if (cont != 'y' && cont != 'Y') {
            break;
        }
    }

    // Print all data
    print_all_movement_points(points, num_points);
    print_drone_path_points(path_points, num_path_points);

    return 0;
}

